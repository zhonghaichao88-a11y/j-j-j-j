# 《别信弹幕：第十七天的他和我》— 其它资产清单（other）

来源：剧本 `script.md` 全25场 + `characters.md`，对照总表 `/workspace/bie-xin-danmu/assets_bible/assets.json`（31 UI / 16 motifs / 13 signage / 8 vehicles / 2 animals / 13 extras / 16 weather_vFX）。
本目录不重复场景、手持道具、主演服装（海生号见 `props/P05_haishenghao.png`）。

## 风格约定
- 只对齐人物参考 `/workspace/bie-xin-danmu/batch/refs/ref_xiazhiyao.png` 的**画法**：细线描、轻赛璐珞、软现代动漫。
- **颜色跟条目自身的气氛走**，不强制粉彩。
- 出图不写字：界面文字、招牌、徽章、碗底「砚」、刺绣「遥」、LIVE/观看人数等一律后期加。猜的部分标 `[设计补充]`。
- 物体 / 载具 / 路人：360° 八视角（正、背、左、右、四斜）；UI：正面屏；VFX / 母题 / 招牌：参考拼贴。

## 生成文件一览
目录：`/workspace/bie-xin-danmu/assets_bible/other/`

独立出图：56 张唯一图像（另有 19 个官方 ID / O* 同字节别名，目录内共 75 个 jpg）。O01–O18 与对应 U/P/EX/A 为同图别名。末轮已补 EX04/EX05 姿势表、EX09 渔民/街坊变体、A01 湿毛/窗台、U07 房间淹没、W11 浪高、G06 粉紫灯管，并重绘 EX08 黄衣、U02 半透明错落弹幕、女同学 45°、少年霸凌变体；P99 左侧角度仍未齐，记入 qc/post_fix_list.md。

## UI 界面（31）

### U01　弹幕A（知遥所见，视频A评论）
- **场次**：第1场, 第5场, 第6场, 第7场, 第8场, 第10场, 第11场, 第12场, 第15场, 第17场, 第18场
- **说明**：半透明白字（透明度20%→80%），字体圆润，从画面右侧飘入向左移动，带轻微RGB色散；高情绪弹幕变红、变大、抖动；“前方高能”类横贯全屏。
- **剧本依据**：七、1. 弹幕是从画面右侧飘入的半透明白字，字体圆润。高情绪弹幕变红、变大、抖动。
- **状态**：已出图
- **文件**：U01_danmaku_A.jpg (alias O01_ui_danmaku_A.jpg)
- **提示词要点**：16:9 overlay mockup, blank rounded danmaku bars with RGB fringe, cold-gray card upper-left, view-count pills upper-right, 2D anime dusk harbor, no typography
- **检查**：Pass. Layout matches 七、1 and 第5场. No text.

### U02　弹幕B（周砚所见，视频B评论）
- **场次**：第5场, 第12场, 第20场, 第21场, 第22场, 第23场
- **说明**：样式同U01；在第21–22场越来越密，第22场21:46全部变红横贯视野；第23场最后变成慢速白字后熄灭。
- **剧本依据**：22场：周砚的弹幕B突然全部变成红色，横贯整个视野
- **状态**：已出图（末轮再绘）
- **文件**：U02_danmaku_B.jpg (alias O02_ui_danmaku_B.jpg)
- **提示词要点**：16:9 overlay, warm-yellow card upper-right, semi-transparent white bars with RGB fringe, 2D anime sunset harbor, no typography
- **检查**：Pass. Sunset harbor shows through 25–40% frosted-white bars; bars are staggered in length and position across the whole frame with RGB fringe, not a solid right-hand stack. Warm-yellow card remains upper-right. Empty of type.

### U03　视频A字幕卡（左上角冷灰色小框）
- **场次**：第5场, 第7场, 第8场, 第10场, 第11场, 第12场, 第17场, 第18场
- **说明**：左上角冷灰色圆角小框，内含“第N天｜日期｜描述”（文字后期）。
- **剧本依据**：视频 A 的字幕卡是左上角的冷灰色小框。
- **状态**：在拼贴图中
- **文件**：U01_danmaku_A.jpg (upper-left card)
- **提示词要点**：cold-gray rounded subtitle card, empty placeholder bars, no type
- **检查**：Covered on U01 sheet.

### U04　视频B字幕卡（右上角暖黄色）
- **场次**：第5场, 第12场, 第20场, 第23场
- **说明**：右上角偏暖黄色框；第5场只闪0.5秒看不清；标题在第20场、第23场两次重组。
- **剧本依据**：视频 B 的字幕卡在右上角，偏暖黄色。
- **状态**：在拼贴图中
- **文件**：U02_danmaku_B.jpg (upper-right card)
- **提示词要点**：warm-yellow subtitle card, empty bars
- **检查**：Covered on U02 sheet.

### U05　观看人数角标（右上角）
- **场次**：第5场, 第7场, 第11场, 第13场, 第20场, 第23场
- **说明**：右上角小字“观看 X亿”，数字会跳变（3.1亿→3.0→2.8→2.5→2.1→1.2亿→消失）。[设计补充] 视频B同为右上角时，观看人数放在字幕卡下方。
- **剧本依据**：右上角是一行小字：“观看 3.1亿”。
- **状态**：在拼贴图中
- **文件**：U01_danmaku_A.jpg / U02_danmaku_B.jpg (upper-right pills)
- **提示词要点**：two empty pills as view-count cluster, no digits
- **检查**：Covered. Digits to be added in post.

### U06　弹幕重组特效（像素碎裂+“嘶”电流声）
- **场次**：第7场, 第11场, 第17场, 第20场, 第23场
- **说明**：文字先碎成像素再拼回，闪烁、乱码。
- **剧本依据**：弹幕重组时，文字先碎成像素，再拼回去，配“嘶”的电流声。
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 8)
- **提示词要点**：blank bars shatter into square pixels with RGB fringe, then grain
- **检查**：Pixel shatter and chromatic fringe present; 'reassemble' and electric hiss are implied, not fully storyboarded.

### U07　弹幕淹没房间（全CG文字粒子）与退潮
- **场次**：第18场
- **说明**：弹幕从墙、天花板、地板涌出淹没房间；“闭嘴”后从中间裂开、像灰被吹散、像水汽消失。
- **剧本依据**：卧室里弹幕淹没房间用全 CG 的文字粒子
- **状态**：已出图
- **文件**：U07_room_flood.jpg（三格：淹没 / 从中裂开 / 灰雾退潮）；W_vfx_sheet.jpg (panel 8) 仍作粒子特写
- **提示词要点**：danmaku as particle/ash field, empty bars only, three-panel flood then tide-out
- **检查**：Pass. Empty white bars and particles flood the bedroom, split down the middle, then blow away as ash/mist. Panel index numbers were cropped off. No typography.

### U08　弹幕熄灭（萤火虫式粒子消散）
- **场次**：第23场
- **说明**：弹幕一颗颗熄灭，像萤火虫飞向夜空。
- **剧本依据**：弹幕熄灭用粒子消散，像萤火虫飞向夜空。
- **状态**：在拼贴图中
- **文件**：U09_endcard.jpg + W_vfx_sheet.jpg
- **提示词要点**：white bars fading into firefly dots over a rainy night sea
- **检查**：Firefly extinguish is clear on the endcard. Pass.

### U09　“直播已结束｜感谢观看”字幕卡
- **场次**：第23场
- **说明**：视频B字幕卡最终形态，小字。
- **剧本依据**：字幕卡最后变成一行小字：“直播已结束｜感谢观看”。
- **状态**：已出图
- **文件**：U09_endcard.jpg (alias O06_ui_endcard.jpg)
- **提示词要点**：16:9 2D anime rainy sea, centered empty end-card with two placeholder bars, firefly-like fading bars, no view-count, no type
- **检查**：Pass. Layout only; wording 直播已结束｜感谢观看 is for post.

### U10　周砚视野右上角红色倒计时（21:41）
- **场次**：第22场, 第23场
- **说明**：红色数字时钟，跳动。
- **剧本依据**：右上角一个红色数字在跳——21:41。
- **状态**：已出图
- **文件**：U10_countdown.jpg
- **提示词要点**：red digital clock cluster in upper-right of Zhou Yan POV, empty digit blocks, no readable numbers
- **检查**：Pass with note. First version had readable “C:30” and was discarded. Kept regen uses unlit 7-segment chassis that still read as “888”. Digits (21:41) are for post.

### U11　柯一鸣竖屏直播画框（LIVE红点+账号名）
- **场次**：第1场, 第16场, 第22场
- **说明**：手机竖屏画框，左上角红点闪“LIVE”，账号名，剧烈晃动；第22场为车顶高处背后视角。
- **剧本依据**：左上角红点闪着“LIVE”，账号名是“一鸣惊瓜”。
- **状态**：已出图
- **文件**：U11_live_yiming.jpg (alias O03_ui_live_yiming.jpg)
- **提示词要点**：9:16 2D anime phone livestream, red live-dot + empty red pill, empty name plate, stormy cel-shaded sea, abstract icons, no type
- **检查**：Pass. No LIVE letters, as required.

### U12　柯一鸣直播间评论区
- **场次**：第22场
- **说明**：直播间评论刷屏（？？？、小孩说是救人、快看另一个直播间）。
- **剧本依据**：柯一鸣的直播间里，评论区瞬间刷满
- **状态**：已出图
- **文件**：U12_live_comments.jpg
- **提示词要点**：vertical live comment ticker of empty rounded bars over a shaky night-sea frame
- **检查**：Pass. Van-roof night sea, red live pill, empty comment bars, no typography.

### U13　9秒打人视频（竖屏小框，画质粗糙，水印）
- **场次**：第3场, 第16场
- **说明**：模糊走廊竖屏视频，标题条+账号水印，刻意粗糙。
- **剧本依据**：手机屏幕上的 9 秒视频用竖屏小框插入，画质刻意做得粗糙。
- **状态**：已出图
- **文件**：U13_9s_video.jpg (alias O07_ui_9s_video.jpg)
- **提示词要点**：9:16 grainy anime hallway punch clip, empty title bar, abstract diamond watermark, progress bar, no type
- **检查**：Pass. Style is 2D anime. Victim/aggressor are generic schoolboys.

### U14　“潮声”App（热搜榜/视频/评论区/播放量）
- **场次**：第16场, 第18场, 第20场
- **说明**：虚构短视频App界面：热搜榜、视频流、评论区上刷；第20场词条翻动。
- **剧本依据**：她打开“潮声”App，热搜第三条
- **状态**：已出图
- **文件**：U14_chaosheng_app.jpg (alias O04_ui_chaosheng_app.jpg)
- **提示词要点**：9:16 fictional app, abstract wave/crescent mark, empty search and hot-list bars, 2D anime rainy street player, comment bars, no type
- **检查**：Pass after style regen. Not a real-world app clone.

### U15　手机推送通知（台风路径）
- **场次**：第3场, 第19场
- **说明**：系统推送横幅。
- **剧本依据**：知遥的手机推送弹出：“台风‘青鸾’路径更新……”
- **状态**：已出图
- **文件**：U15_push.jpg
- **提示词要点**：system notification banner, empty rounded bar at top of a phone lock screen, no type
- **检查**：Pass. Empty push banner; “台风‘青鸾’路径更新” wording is post only.

### U16　知遥直播界面（账号“镜头外”，在线人数，浸水黑屏）
- **场次**：第22场
- **说明**：胸前视角直播，正面剧烈晃动；结尾屏幕全黑只剩右上角在线人数“1.2万”往上跳。
- **剧本依据**：只剩下直播间右上角的在线人数，从“1.2万”一路往上跳。
- **状态**：已出图
- **文件**：U16_jingtouwai_live.jpg (alias O05_ui_jingtouwai_live.jpg)
- **提示词要点**：9:16 chest-pouch livestream, 2D anime typhoon breakwater + lighthouse beam, red live pill, empty viewer pill, comment bars, abstract eye mark, no type
- **检查**：Pass. Waterproof bag is [设计补充] visible around the phone.

### U17　视频发布界面《我看清了：完整版》/许小满《一年前那三分钟》03:12
- **场次**：第19场, 第20场
- **说明**：发布按钮、标题、时长03:12特写。
- **剧本依据**：视频时长“03:12”用特写。
- **状态**：已出图
- **文件**：U17_publish.jpg
- **提示词要点**：publish screen with empty title bar, big send button, and a 03:12 duration chip left blank
- **检查**：Pass. Girl in the preview is short brown hair, not Zhiyao. Title/03:12 type is post.

### U18　聊天消息界面（周砚↔知遥）
- **场次**：第17场, 第20场
- **说明**：即时消息气泡。
- **剧本依据**：是周砚发来的消息
- **状态**：已出图
- **文件**：U18_chat.jpg
- **提示词要点**：IM bubble thread, empty bubbles only
- **检查**：Pass. Empty chat bubbles, no typography.

### U19　班级群界面（宋佳怡发视频）
- **场次**：第20场
- **说明**：群聊+视频气泡。
- **剧本依据**：宋佳怡在班级群里发了一段
- **状态**：已出图
- **文件**：U19_class_group.jpg
- **提示词要点**：class group chat + video bubble, empty bars
- **检查**：Pass. Empty group-chat and video bubble, no typography.

### U20　前置摄像头自拍录像界面（红点）
- **场次**：第18场, 第20场
- **说明**：录像红点、自拍画面。
- **剧本依据**：手机的前置摄像头还开着，红点亮着
- **状态**：已出图
- **文件**：U20_front_camera.jpg
- **提示词要点**：front-camera record UI with a red dot and empty frame
- **检查**：Pass. Ponytail + blazer student, no red bow / cream cardigan. Red record dot, no type.

### U21　视频连线界面（笔记本）
- **场次**：第17场
- **说明**：笔记本屏幕里的视频通话。
- **剧本依据**：屏幕里是柯一鸣的视频连线
- **状态**：已出图（完结补图重绘一次）
- **文件**：U21_video_call.jpg
- **提示词要点**：laptop video-call window, empty participant frame, no neon lettering (G06 neon shape can sit behind)
- **检查**：Pass with notes. First version had a letter-like “M” neon and a younger face; regen uses abstract tube/blob neon and a 20s man with stubble in a black hoodie. Residual: QWERTY letters remain on the keycaps; one purple neon still slightly “A”-shaped. Call chrome is icon-only.

### U22　电视画面：台风橙色预警/本地新闻
- **场次**：第21场, 第24场
- **说明**：电视新闻图文。
- **剧本依据**：电视里在播台风橙色预警
- **状态**：已出图
- **文件**：U22_tv_news.jpg
- **提示词要点**：TV news / typhoon-orange-alert graphic, empty typography blocks
- **检查**：Pass. Living-room TV, orange empty alert bar, empty lower-third, cloud icon, storm coast, no typography.

### U23　监控画面（黑白俯拍）
- **场次**：第8场
- **说明**：粗颗粒黑白监控视角，带时间码[设计补充]。
- **剧本依据**：监控的俯拍黑白画面里，男生显得粗暴
- **状态**：已出图（完结补图重绘一次）
- **文件**：U23_cctv.jpg
- **提示词要点**：grainy B&W overhead CCTV frame, empty timecode bar [设计补充]
- **检查**：Pass after one regen. First version leaked Zhiyao (long hair, bow, cream cardigan) and had poster glyphs. Kept version: B&W alley, navy-jacket boy leading a ponytail classmate in a dark blazer (no bow/cardigan) past a scooter, empty black timecode box, blank walls. Slightly less overhead/fisheye than a true CCTV mount; action is “leading away” more than “yanking off the bike.”

### U24　柯一鸣手机镜头仰拍画面
- **场次**：第16场
- **说明**：稳定器摔地后朝上拍到周砚“居高临下”的脸。
- **剧本依据**：同时插入他手机镜头里的仰拍画面
- **状态**：已出图
- **文件**：U24_upangle.jpg
- **提示词要点**：ground-level stabilizer up-angle, 2D anime, no type
- **检查**：Pass with note. Fisheye up-angle, navy jacket + white T at a school gate, 2D anime, no text. More sunny afternoon than “just after a fall,” and the boy looks slightly aside rather than fully down the lens.

### U25　分屏：视频A（冷灰）/视频B（暖黄）对撞合成“双双身亡”
- **场次**：第12场
- **说明**：左右分屏冷暖对撞，中间竖线合拢。
- **剧本依据**：分屏是全片最重要的视觉设计
- **状态**：在拼贴图中
- **文件**：U_composites.jpg (left panel)
- **提示词要点**：left-right split, cold-gray vs warm-yellow grades, empty subtitle cards, empty danmaku bars, no type, no lead-character likeness
- **检查**：Pass after one regen (first attempt copied the heroine and was discarded).

### U26　三屏并列（柯一鸣直播/知遥直播/真实画面）
- **场次**：第22场
- **说明**：同一瞬间三种角度。
- **剧本依据**：三屏并列是全片第二个关键视觉设计
- **状态**：在拼贴图中
- **文件**：U_composites.jpg (top-right triple)
- **提示词要点**：three angles of the same stormy pier instant: behind, frontal-ish, wide reality
- **检查**：Approximate: not literally Ke-live / chest-live / film-frame, but a usable triple-angle layout.

### U27　漫画分格分屏蒙太奇
- **场次**：第13场
- **说明**：分格漫画式，最后一格两人的“耶”合成一画。
- **剧本依据**：喜剧蒙太奇用分格漫画式的分屏
- **状态**：在拼贴图中
- **文件**：U_composites.jpg (bottom-left)
- **提示词要点**：comic-panel school montage ending in peace-sign hands, unnamed students
- **检查**：Pass.

### U28　片中字幕/片名/手写字幕/演职员表
- **场次**：第1场, 第6场, 第24场, 第25场
- **说明**：“17天前”黑底白字；片名浮现；晚霞上白色手写字幕；演职员表滚动。
- **剧本依据**：00:55 字幕：黑底白字——“17天前。”
- **状态**：已出图
- **文件**：U28_titles.jpg
- **提示词要点**：title/end-title layouts: black plate + empty white bars; handwritten bar over a dusk sky; credit roll as empty lines
- **检查**：Pass with style note. Three panels: black plate with two empty white bars; dusk lighthouse + a blank handwritten stroke; credit-roll empty lines. Middle panel is slightly more painterly than the character-cel ref. 17天前 / 片名 wording is post only.

### U29　外婆的弹幕“外婆yyds”
- **场次**：第25场
- **说明**：单条半透明白字，无字幕卡[设计补充]，被外婆一挥散开。
- **剧本依据**：外婆头顶上方，飘过一行半透明的白字
- **状态**：已出图（完结补图重绘一次）
- **文件**：U29_grandma_danmaku.jpg
- **提示词要点**：a single floating translucent white rounded bar, no subtitle card, then dispersing
- **检查**：Pass with note. First version had readable Chinese on a wall paper and was discarded. Kept regen: navy-blouse grandmother, kitchen, one white bar dispersing into particles, blank calendar grid, blank jars. Residual: the wall clock has numerals 1–12. Gesture is a friendly wave rather than a sharp brush-away.

### U30　“镜头外”画面规则
- **场次**：第9场, 第12场, 第13场, 第14场, 第15场
- **说明**：无弹幕时去掉画面边框的轻微暗角，色温变暖。
- **剧本依据**：“镜头外”的时刻会把画面边框的轻微暗角去掉，色温变暖
- **状态**：在拼贴图中
- **文件**：U_composites.jpg (bottom-right)
- **提示词要点**：same back-view couple, vignette+cool vs no-vignette+warm
- **检查**：Pass as a grade comparison.

### U31　柯一鸣电脑满屏差评
- **场次**：第20场
- **说明**：电脑屏幕满屏“摆拍”“道歉”“举报”。
- **剧本依据**：他对着电脑屏幕上满屏的“摆拍”“道歉”“举报”
- **状态**：已出图
- **文件**：U31_hate_comments.jpg
- **提示词要点**：desktop screen tiled with empty hate-comment bars, no glyphs
- **检查**：Pass. Dim messy studio, monitor tiled with empty red/gray cards, down-arrow and warning-triangle icons only, frustrated man visible through the glass, no typography. “摆拍 / 道歉 / 举报” wording is post.

## 母题 Motifs（16）

### M01　红蝴蝶结（顺从→自我→救命）
- **场次**：第1场, 第2场, 第3场, 第7场, 第15场, 第16场, 第18场, 第20场, 第23场, 第24场, 第25场
- **说明**：六、1.
- **剧本依据**：六、1.
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 1); bow prop itself is P01, not duplicated as a prop
- **提示词要点**：red bow on black water / tight vs self-tied vs lifesaving
- **检查**：Visual motif panel only. Full turnaround lives with props.

### M02　蜡烛被吹灭的“噗”声（首尾闭环）
- **场次**：第1场, 第4场, 第21场, 第25场
- **说明**：和第1场结尾的那一声完全相同
- **剧本依据**：和第1场结尾的那一声完全相同
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 2)
- **提示词要点**：candle puff of smoke
- **检查**：Pass.

### M03　白烟拧成“∞”
- **场次**：第4场
- **说明**：一缕白烟升起来，在黑暗里慢慢拧成一个极淡的“∞”形
- **剧本依据**：一缕白烟升起来，在黑暗里慢慢拧成一个极淡的“∞”形
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 3)
- **提示词要点**：white smoke twisting into a sideways infinity
- **检查**：Pass, matches 第4场白烟拧成∞.

### M04　老灯塔的光（停电前闪一下/亮起第一束光/雨中一明一灭/真实的灯塔光）
- **场次**：第1场, 第4场, 第12场, 第19场, 第22场, 第23场, 第24场
- **说明**：灯一亮，窗外远处的老灯塔闪了一下
- **剧本依据**：灯一亮，窗外远处的老灯塔闪了一下
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 4) + W_vfx_sheet.jpg
- **提示词要点**：red-white lighthouse beam
- **检查**：Pass.

### M05　手机=鱼群/探照灯/黑洞/眼睛
- **场次**：第3场, 第6场, 第7场, 第16场, 第20场
- **说明**：全班手机“齐刷刷翻面”的动作，像一片鱼群
- **剧本依据**：全班手机“齐刷刷翻面”的动作，像一片鱼群
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 5)
- **提示词要点**：phone screens swimming like a school of fish
- **检查**：Pass, from 第6场 OP.

### M06　数字“17”/倒计时
- **场次**：第1场, 第4场, 第5场, 第6场, 第13场, 第14场, 第21场, 第22场
- **说明**：倒计时数字“17”从海面升起
- **剧本依据**：倒计时数字“17”从海面升起
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 6)
- **提示词要点**：seventeen tick marks in a ring, no digits
- **检查**：Pass. Actual 17 numeral is post only.

### M07　剪刀与拼回的画面（剪辑=偏见）
- **场次**：第6场
- **说明**：一个画面被剪刀“咔嚓”剪成两半
- **剧本依据**：一个画面被剪刀“咔嚓”剪成两半
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 7)
- **提示词要点**：film frames cut by scissors and taped back
- **检查**：Pass.

### M08　有人看见、有人没看见的构图（前景模糊的围观者，焦点在真相）
- **场次**：第2场, 第8场
- **说明**：“有人看见、有人没看见”的构图从这里就开始了
- **剧本依据**：“有人看见、有人没看见”的构图从这里就开始了
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (panel 8)
- **提示词要点**：soft foreground crowd, sharp distant action
- **检查**：Pass.

### M09　码头上的等待（十年前没等到/这一次等到了/笑着挥手）
- **场次**：第18场, 第23场, 第25场
- **说明**：这一次，码头上有人在等，等到了。
- **剧本依据**：这一次，码头上有人在等，等到了。
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (row 3 col 1)
- **提示词要点**：waiting on a pier, then a group waiting/waving
- **检查**：Pass.

### M10　碗筷（多一双筷子→“砚”字碗）
- **场次**：第4场, 第24场
- **说明**：最后桌上多了一副他的碗筷
- **剧本依据**：最后桌上多了一副他的碗筷
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (chopsticks + blue-rim bowl)
- **提示词要点**：extra chopsticks and 砚-bowl shape, bowl interior blank
- **检查**：Pass. 砚 character is post only. Bowl prop also exists as P31.

### M11　便利贴（周静→周砚→知遥）
- **场次**：第9场, 第13场, 第14场
- **说明**：冰箱上贴满给儿子的便利贴
- **剧本依据**：冰箱上贴满给儿子的便利贴
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (yellow sticky notes on a fridge)
- **提示词要点**：plain yellow notes, no writing
- **检查**：Pass.

### M12　“看全了再说”/前面那三分钟
- **场次**：第6场, 第10场, 第19场, 第24场
- **说明**：口头禅：“看全了再说。”
- **剧本依据**：口头禅：“看全了再说。”
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (open hand / look-again gesture)
- **提示词要点**：pause-and-look hand
- **检查**：Abstract stand-in for 看全了再说.

### M13　黄色小点/黄雨衣
- **场次**：第8场, 第13场, 第15场, 第21场, 第22场
- **说明**：远处堤上，一个黄色的小点在灯塔下面蹲着
- **剧本依据**：远处堤上，一个黄色的小点在灯塔下面蹲着
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (yellow raincoat figure + yellow dot on a dike)
- **提示词要点**：distant yellow raincoat
- **检查**：Pass. Dou Dou himself is a lead, not drawn as a character here.

### M14　冷暖对撞：视频A冷灰 vs 视频B暖黄；会议室冷/家暖
- **场次**：第12场, 第14场, 第17场
- **说明**：冷暖两套色调对撞
- **剧本依据**：冷暖两套色调对撞
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (cold gray vs warm yellow split) + U_composites.jpg
- **提示词要点**：cold/warm collision
- **检查**：Pass.

### M15　水下镜头对称（第1场下沉/第23场一只手抓住）
- **场次**：第1场, 第23场
- **说明**：水下镜头与第1场完全对称
- **剧本依据**：水下镜头与第1场完全对称
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (underwater reaching hand) + W_vfx_sheet.jpg
- **提示词要点**：underwater sinking vs a hand reaching down
- **检查**：Pass.

### M16　客厅矮桌构图复刻（第4/21/24场）
- **场次**：第4场, 第21场, 第24场
- **说明**：客厅全景完全复刻第4场和第21场的构图
- **剧本依据**：客厅全景完全复刻第4场和第21场的构图
- **状态**：在拼贴图中
- **文件**：M_motifs_sheet.jpg (warm low table living room)
- **提示词要点**：repeating living-room table composition
- **检查**：Single panel, not a triple 4/21/24 lineup. Usable.

## 招牌形状 Signage（13）

### G01　夏记面馆招牌
- **场次**：第2场, 第5场, 第21场, 第25场
- **说明**：木质招牌，后期加“夏记”二字
- **剧本依据**：面馆「夏记」招牌（人物卡代表元素）
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (wooden hanging sign)
- **提示词要点**：blank wooden shop sign
- **检查**：Pass, empty for 夏记.

### G02　骑楼铁皮招牌（台风中哐哐响）
- **场次**：第21场
- **说明**：铁皮挂牌，内容空白
- **剧本依据**：骑楼的铁皮招牌被吹得哐哐响
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (rusted corrugated iron sign)
- **提示词要点**：blank iron qilou sign
- **检查**：Pass.

### G03　巷口小超市招牌
- **场次**：第8场
- **说明**：空白招牌，虚构中文店名后期
- **剧本依据**：巷口一家小超市门口装着监控
- **状态**：已出图
- **文件**：G_signage_extra.jpg (hanging supermarket sign)
- **提示词要点**：blank alley supermarket sign
- **检查**：Pass. Blank hanging supermarket sign on the extra sheet; store name is post.

### G04　24小时便利店招牌/自动门
- **场次**：第19场
- **说明**：虚构店名后期，“欢迎光临”电子音
- **剧本依据**：便利店自动门的“欢迎光临”电子音
- **状态**：已出图
- **文件**：G_signage_extra.jpg (blade + automatic doors)
- **提示词要点**：24h convenience blade sign + automatic-door transom, blank
- **检查**：Pass. Blade sign and automatic doors, all typography reserved for post.

### G05　第七中学校门/校名、校报
- **场次**：第3场, 第16场, 第17场, 第24场
- **说明**：校名、校报版头后期
- **剧本依据**：澄港第七中学
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (stone plaque frame)
- **提示词要点**：blank school name plaque
- **检查**：Pass, empty for 第七中学.

### G06　“一鸣惊瓜”霓虹灯牌、账号水印
- **场次**：第3场, 第14场, 第17场, 第20场
- **说明**：粉紫霓虹灯管
- **剧本依据**：他背后挂着“一鸣惊瓜”的霓虹灯牌
- **状态**：已出图（粉紫上色）
- **文件**：G06_neon_tinted.jpg；G_signage_shapes.jpg 仍保留未上色灯管套件
- **提示词要点**：pink-purple lit neon tubes, geometric frames and loose U-bends only, no letters
- **检查**：Pass. Pink/magenta/purple geometric rectangle, circle, loose U-bent tubes, plus a wall inset of an empty rectangular frame. No letterforms (a cursive monogram attempt was discarded). 一鸣惊瓜 lettering is post.

### G07　“海生”船名、钥匙木牌、救生圈字
- **场次**：第2场, 第15场, 第21场, 第23场, 第25场
- **说明**：白漆字/刻字/印字
- **剧本依据**：船头漆着白字“海生”
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (wood board + wooden key fob + blank life ring)
- **提示词要点**：blank boat-name board, key tag, life ring
- **检查**：Pass. 海生 lettering is post. Life ring is white rather than faded orange — note for comp.

### G08　泊位缴费单文字
- **场次**：第9场
- **说明**：“澄港避风塘泊位年费｜船名：海生号｜缴费人：夏红梅”
- **剧本依据**：特写缴费单
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (receipt slip with empty lines)
- **提示词要点**：blank fee form
- **检查**：Pass. 泊位年费 wording is post.

### G09　“澄港少年游泳队”训练包印字
- **场次**：第24场
- **说明**：白色印字
- **剧本依据**：印着“澄港少年游泳队”的训练包
- **状态**：已出图
- **文件**：G_signage_extra.jpg (duffel blank panel)
- **提示词要点**：blank end-panel of a swim-team duffel
- **检查**：Pass. Blank duffel end panel; “澄港少年游泳队” is post.

### G10　游泳队徽章“少年队”字样
- **场次**：第3场
- **说明**：徽章字带
- **剧本依据**：图案是浪花和“少年队”字样
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (round enamel badge, blank center)
- **提示词要点**：blank badge face
- **检查**：Pass. 少年队 lettering is post. Full badge prop is P06.

### G11　“班长”袖章
- **场次**：第3场, 第7场
- **说明**：红底字
- **剧本依据**：红色「班长」袖章
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (red armband, blank)
- **提示词要点**：blank red armband
- **检查**：Pass. 班长 is post.

### G12　“自己的碗，端稳了”T恤印字
- **场次**：第25场
- **说明**：胸前大字
- **剧本依据**：T恤上印着“自己的碗，端稳了”
- **状态**：已出图
- **文件**：G_signage_extra.jpg (T-shirt blank chest)
- **提示词要点**：blank T-shirt print area
- **检查**：Pass. Blank chest print area; “自己的碗，端稳了” is post.

### G13　“砚”字碗底红漆、“遥”字刺绣
- **场次**：第1场, 第3场, 第24场
- **说明**：手写/刺绣小字
- **剧本依据**：碗底用红漆写了一个小小的“砚”字
- **状态**：在拼贴图中
- **文件**：G_signage_shapes.jpg (blue-rim bowl + small blank embroidery patch)
- **提示词要点**：blank bowl interior and patch
- **检查**：Pass. 砚 / 遥 are post.

## 载具 Vehicles（8）

### P18　白色面包车（车顶架补光灯）
- **场次**：第22场
- **说明**：白色面包车（车顶架补光灯）
- **状态**：已出图（完结补图重绘）
- **文件**：P18_white_van.jpg (alias O12_white_van.jpg)
- **提示词要点**：8-angle 2D cel van, no grille emblem, exactly three consistent roof LED lights, blank plates, no typography
- **检查**：Pass. Latest regen is 2D cel, no grille emblem, exactly three roof LED lights consistent across the eight views.

### P42　搬家小货车
- **场次**：第2场
- **说明**：搬家小货车
- **状态**：已出图（完结补图 2D 重绘）
- **文件**：P42_truck.jpg (alias O10_truck.jpg)
- **提示词要点**：8-angle 2D cel small moving box truck, pale-blue cab, beige box, blank plates, no typography
- **检查**：Pass with note. Now 2D cel (pale-blue cab, beige box, 8-angle). A residual tiny circular grille badge remains after one dedicated “no emblem” retry.

### P45　外卖电动车（后视镜）
- **场次**：第8场
- **说明**：外卖电动车（后视镜）
- **状态**：已出图（完结补图 2D 重绘）
- **文件**：P45_delivery_ebike.jpg (alias O11_delivery_ebike.jpg)
- **提示词要点**：8-angle unbranded matte-yellow delivery scooter + yellow box, no logos
- **检查**：Pass. 2D cel, unbranded matte yellow body and box, 8-angle. Color now matches the bible’s yellow delivery look. EX08 rider sheet is still teal-gray and should be recolored to match.

### P80　夏红梅的电动车
- **场次**：第21场
- **说明**：夏红梅的电动车
- **状态**：已出图（完结补图 2D 重绘）
- **文件**：P80_hongmei_ebike.jpg (alias O13_hongmei_ebike.jpg)
- **提示词要点**：8-angle 2D cel worn burgundy household e-bike with front basket, no cargo box, no logos
- **检查**：Pass with note. 2D cel, worn burgundy, front basket, no cargo box. Possible tiny side marks on a couple of views.

### P81　海生号（旧小机动渔船，船头白字“海生”）
- **场次**：第2场, 第15场, 第21场, 第23场, 第25场
- **说明**：海生号（旧小机动渔船，船头白字“海生”）
- **状态**：由道具目录承担
- **文件**：（无）
- **提示词要点**：covered by prop P05_haishenghao — not duplicated here
- **检查**：Intentionally not redrawn in /other; see assets_bible/props/P05_haishenghao.png.

### P85　海上救援橙色救生艇
- **场次**：第23场
- **说明**：海上救援橙色救生艇
- **状态**：已出图
- **文件**：P85_rescue_boat.jpg (alias O14_rescue_boat.jpg)
- **提示词要点**：8-angle orange rescue boat, warning lights, blank life rings, no type
- **检查**：Pass. Clean 2D line + cel. No letters.

### P98　避风塘小渔船群（背景船）
- **场次**：第1场, 第12场, 第15场, 第25场
- **说明**：避风塘小渔船群（背景船）
- **状态**：已出图
- **文件**：P98_fishing_boat.jpg (alias P98_fishing_boats.jpg)
- **提示词要点**：generic small harbor fishing boat 8-angle, unbranded, not 海生号
- **检查**：Pass with minor view-order note. 2D cel, muted teal weathered hull, blank name boards, not 海生号. Eight views cover the circle reasonably; one frontal-ish view is slightly redundant.

### P99　公交车（仅提及）
- **场次**：第19场
- **说明**：公交车（仅提及）
- **状态**：已出图
- **文件**：P99_city_bus.jpg
- **提示词要点**：city bus, 仅提及 in 第19场 (知遥坐了四十分钟的公交)
- **检查**：仍未完全修好（已重绘两次）。2D cel cream-and-blue unbranded bus, blank destination boards and plates. Front / right / rear are present, plus a rear three-quarter; left-side profile (nose pointing right) and front-left 45° are still missing, with duplicate front/rear/right views. Possible tiny side badges. Logged to qc/post_fix_list.md.

## 动物 Animals（2）

### A01　橘猫“灯泡”
- **场次**：第8场, 第12场, 第22场, 第23场, 第24场, 第25场
- **说明**：胖橘猫，住灯塔底石缝；第22场湿透被豆豆抱着；第24场被豆豆收养趴窗台晒夕阳打呼噜。
- **剧本依据**：它是只橘猫，可胖了，住在灯塔底下的石头缝里。
- **状态**：已出图（湿毛/窗台变体已补）
- **文件**：A01_cat_dengpao.jpg (alias O08_cat_dengpao.jpg) — 干毛八视图；A01_cat_variants.jpg — 湿毛与窗台
- **提示词要点**：fat orange tabby, cream belly, mackerel stripes, no collar, 8-angle, plus wet and windowsill variants, soft cel
- **检查**：Dry turnaround still stands. Variant sheet adds a wet sitting/huddled/held row and a sunset windowsill loafing row, same cat. Note: wet fur is only lightly beaded, not fully plastered/darkened; logged as a minor post note.

### A02　海鸥
- **场次**：第1场, 第15场, 第24场
- **说明**：港口海鸥群。
- **剧本依据**：海鸥在桅杆间盘旋。
- **状态**：已出图
- **文件**：A02_seagull.jpg (alias O09_seagull.jpg)
- **提示词要点**：herring gull, 8-angle, folded wings, plain bg
- **检查**：Pass as 2D animal sheet. Line is a little tighter/naturalistic vs the character ref, but clearly drawn, not photoreal.

## 路人 / 群演 Extras（13）

### EX01　班主任老何
- **场次**：第3场, 第17场
- **说明**：[设计补充] 50岁左右男性教师，微秃，浅灰短袖衬衫，深色西裤，干笑表情。
- **剧本依据**：第3场：「班主任老何领着周砚进来。」；第17场：「对面坐着钱主任和老何。」
- **状态**：已出图
- **文件**：EX01_teacher.jpg
- **提示词要点**：50-year-old male teacher, thinning hair, light-grey short-sleeve shirt, dark slacks, dry smile, 8-angle [设计补充]
- **检查**：Pass. Style matches the character ref well.

### EX02　教导主任钱主任
- **场次**：第17场
- **说明**：[设计补充] 50多岁，深色西装外套，眼镜，严肃。
- **剧本依据**：第17场：「教导主任钱主任」；第17场：「钱主任（翻着打印出来的网络截图）」
- **状态**：已出图
- **文件**：EX02_director.jpg
- **提示词要点**：mid-50s male director, glasses, dark navy suit, serious, 8-angle [设计补充]
- **检查**：Pass.

### EX03　高二（3）班同学（同学甲乙/若干）
- **场次**：第3场, 第7场, 第13场, 第20场
- **说明**：[设计补充] 第七中学校服：男生白衬衫+深蓝校服外套+深色长裤；女生白衬衫+红领结+深色格纹裙。
- **剧本依据**：第3场：「同学甲：“真的是他？”」；第7场：「教室后排，一个同学正举着手机拍窗外的晚霞」
- **状态**：已出图（女同学八视图已补）
- **文件**：EX03_students.jpg (alias O15_extras_students.jpg) — 男生；EX03_female_student.jpg — 女生
- **提示词要点**：male classmate, white shirt + dark-blue blazer + dark trousers, 8-angle; female: white shirt, red neck-ribbon, dark-blue blazer, dark plaid skirt, simple ponytail, no heroine bow/cardigan [设计补充]
- **检查**：Male sheet already passed (bag strap still inconsistent). Female sheet regenerated: same unnamed classmate (not Zhiyao). The eight views now include front, shallow FR, right, back-right 45, back, back-left 45, left, and a shallow front-left. Bag disappears in some views. Remaining shallow-front 45s / bag inconsistency logged as a minor post note.

### EX04　故意伸脚的男生（课间蒙太奇）
- **场次**：第13场
- **说明**：同 EX03 男生校服。
- **剧本依据**：第13场：「她提前把楼梯口那个故意伸脚的男生叫走问作业。」
- **状态**：已出图
- **文件**：EX04_trip_pose.jpg
- **提示词要点**：same EX03 male uniform, tripping-foot pose in 第13场
- **检查**：Pass. Same navy-blazer male uniform, eight poses including a foot stuck out across a stair block from several angles, plus an 'innocent' stand and walk. One back-kick pose is a bit theatrical; smiles are slightly soft for a tripper.

### EX05　围观学生（后门）
- **场次**：第16场
- **说明**：同 EX03 校服，举手机。
- **剧本依据**：第16场：「后门口的几个学生纷纷举起手机。」
- **状态**：已出图
- **文件**：EX05_phone_crowd.jpg
- **提示词要点**：same school uniform, holding phones at the back gate, 第16场
- **检查**：Pass with note. 2D pose sheet of boys and girls in the correct uniforms holding blank-screen phones; girls have red 领结 and no heroine bow/cardigan. Isolated cutouts rather than a back-gate cluster; several girls share one face/hair; one boy has no phone.

### EX06　搬家工人
- **场次**：第2场
- **说明**：[设计补充] 蓝色工装T恤、深色工装裤。
- **剧本依据**：第2场：「搬家工人搬下纸箱。」
- **状态**：已出图（完结补图 2D 重绘）
- **文件**：EX06_movers.jpg (alias O17_extras_movers.jpg)
- **提示词要点**：bible: 蓝色工装T恤、深色工装裤 [设计补充], 8-angle
- **检查**：Pass. 2D cel, blue work tee, dark pants, gloves at waist, 8-angle.

### EX07　拎菜的老奶奶
- **场次**：第2场
- **说明**：[设计补充] 驼背，灰白短发，深蓝布衫。
- **剧本依据**：第2场：「一个拎着两大袋菜、走得踉踉跄跄的老奶奶」
- **状态**：已出图
- **文件**：EX07_granny.jpg
- **提示词要点**：stooped elderly woman, gray-white hair, deep navy cloth blouse, vegetable basket, 8-angle [设计补充]
- **检查**：Pass. Distinct from 街坊阿姨甲/乙 (those are costumed leads).

### EX08　外卖电动车骑手（只露背影）
- **场次**：第8场
- **说明**：[设计补充] 黄色外卖服、头盔（无字）。
- **剧本依据**：第8场：「外卖电动车骑手（只露背影）」；第8场：「骑手低头看着手机」
- **状态**：已出图（末轮改黄，对齐 P45）
- **文件**：EX08_rider.jpg (alias O16_extras_rider.jpg)
- **提示词要点**：yellow unbranded delivery rider matching P45 yellow, helmet no logos, 8-angle [设计补充]
- **检查**：Pass. Same 8-angle rider, unbranded dark helmet, tee recolored to the warm matte yellow of P45. Cargo pants remain gray; the back-view (只露背影) now reads yellow. Pants leftover logged as a minor post note.

### EX09　面馆食客
- **场次**：第11场, 第20场
- **说明**：[设计补充] 街坊、渔民、上班族混合。
- **剧本依据**：第11场：「晚饭高峰，面馆坐满了人。」；第20场：「食客们举起手机」
- **状态**：已出图（渔民/街坊变体已补）
- **文件**：EX09_diners.jpg (alias O18_extras_diners.jpg) — 上班族；EX09_diner_variants.jpg — 渔民与街坊阿姨
- **提示词要点**：office-worker diner 8-angle; plus fisherman and neighborhood-auntie variants, front / 3/4 / side [设计补充]
- **检查**：Pass. Original plaid newspaper diner kept. New sheet: weathered fisherman in a navy vest with a net, and a middle-aged auntie in a floral blouse with a basket, each in front / three-quarter / side. No typography.

### EX10　三个霸凌者（闪回）
- **场次**：第14场
- **说明**：[设计补充] 同 ZYN-L5 旧学校校服，高大，面部处于阴影。
- **剧本依据**：第14场：「三个高大的身影围着一个瘦小的男生。」
- **状态**：已出图（另两名变体已补）
- **文件**：EX10_bully.jpg；EX10_bully_variants.jpg
- **提示词要点**：tall male bully, rumpled dark school jacket, face partly in shadow, 8-angle [设计补充], cooler flashback mood
- **检查**：Original single bully sheet still stands. Variants regenerated as two clearly teen (16–17) boys in rumpled school uniforms: one loose charcoal blazer with no tie, one navy blazer with a loosened red tie; each in front, three-quarter, and side. Youthful faces, 2D cel. Residual: faces are still mostly lit rather than shadowed, and both have similar short black hair. Usable as the remaining two of the '三个高大的身影'.

### EX11　海上救援人员
- **场次**：第23场
- **说明**：[设计补充] 橙色救生衣、头盔（远景）。
- **剧本依据**：第23场：「海上救援（远景）」
- **状态**：已出图
- **文件**：EX11_rescue.jpg
- **提示词要点**：orange rescue suit, vest, helmet, black boots, 8-angle, no agency type [设计补充]
- **检查**：Pass.

### EX12　穿海魂衫的小伙子（年轻外公）
- **场次**：第25场
- **说明**：蓝白横条海魂衫、深色长裤，黑白照片质感。
- **剧本依据**：第25场：「一个穿海魂衫的小伙子」；第13场：「我十七岁那年，跟你外公也是这么‘学习’的。」
- **状态**：已出图
- **文件**：EX12_young_grandpa.jpg
- **提示词要点**：young man in navy-white striped 海魂衫, dark trousers, 8-angle
- **检查**：Pass as a color turnaround. Bible asks for 黑白照片质感 — apply a monochrome grade in the 第25场 photo shot rather than on the model sheet.

### EX13　新闻主播/广播（仅声音或电视画面）
- **场次**：第1场, 第21场, 第24场
- **说明**：如需出画：电视新闻主播半身，正装。
- **剧本依据**：第1场：「广播声：“今天是9月1日，各中小学正式开学……”」；第24场：「电视里播着本地新闻」
- **状态**：已出图
- **文件**：EX13_news_anchor.jpg
- **提示词要点**：TV news-anchor bust, formal wear, or audio-only
- **检查**：Pass. 2D cel professional woman, navy suit, teal bow, blank mic flag, plus a TV-frame inset. Not a full unique 8-angle (front / 3/4 / sides / back + mic and TV insets). No channel logos or type.

## 天气与特效 Weather / VFX（16）

### W01　清晨金色晨光+薄雾
- **场次**：第1场, 第2场
- **说明**：清晨金色晨光+薄雾
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 1)
- **提示词要点**：golden morning harbor light + thin mist
- **检查**：Pass.

### W02　台风“青鸾”远景：窗外极淡云带
- **场次**：第3场
- **说明**：台风“青鸾”远景：窗外极淡云带
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 2)
- **提示词要点**：faint distant typhoon cloud swirl in a pale sky
- **检查**：Very subtle; usable as a sky insert.

### W03　烛光/停电十秒/灯塔闪一下
- **场次**：第4场, 第5场
- **说明**：烛光/停电十秒/灯塔闪一下
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 3)
- **提示词要点**：candle + a lighthouse wink in a darkened room
- **检查**：Pass.

### W04　厨房蒸汽、热气颗粒感；面粉在光柱里飘
- **场次**：第2场, 第9场, 第11场
- **说明**：厨房蒸汽、热气颗粒感；面粉在光柱里飘
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 4)
- **提示词要点**：kitchen steam and flour motes in a warm shaft
- **检查**：Pass.

### W05　夕阳长影（骑楼柱）
- **场次**：第8场
- **说明**：夕阳长影（骑楼柱）
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet_2.jpg (panel 1)
- **提示词要点**：long sunset shadows of qilou columns, 第8场
- **检查**：Pass. Evening qilou colonnade, raking column shadows on the pavement, 2D anime background art.

### W06　积雨云压境，突降瓢泼大雨，雨停
- **场次**：第10场
- **说明**：积雨云压境，突降瓢泼大雨，雨停
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 5)
- **提示词要点**：sudden rooftop downpour
- **检查**：Pass.

### W07　日落、海风、浪拍消波块溅湿鞋、灯塔亮起第一束光
- **场次**：第12场
- **说明**：日落、海风、浪拍消波块溅湿鞋、灯塔亮起第一束光
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet_2.jpg (panel 2)
- **提示词要点**：sunset, sea wind, spray on shoes, first lighthouse beam, 第12场
- **检查**：Pass. Sunset breakwater, first lighthouse beam, spray, a pair of wet shoes at the edge (the wearer is off-frame).

### W08　黄昏高饱和天空+体积云+碎金海面
- **场次**：第15场
- **说明**：黄昏高饱和天空+体积云+碎金海面
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet_2.jpg (panel 3)
- **提示词要点**：high-saturation dusk sky, volume clouds, gilt sea, 第15场
- **检查**：Pass. High-saturation dusk, volume clouds, broken-gold sea, background fishing boats.

### W09　细雨，灯塔光在雨里一明一灭
- **场次**：第19场
- **说明**：细雨，灯塔光在雨里一明一灭
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet_2.jpg (panel 4)
- **提示词要点**：fine rain, lighthouse beam blinking, 第19场
- **检查**：Pass. Night drizzle, lighthouse beam cutting the rain. Blink is implied by a single lit beam still.

### W10　越来越大的雨（第16天夜）
- **场次**：第20场
- **说明**：越来越大的雨（第16天夜）
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet_2.jpg (panel 5)
- **提示词要点**：rain growing heavier on 第16天 night
- **检查**：Pass. Residential window at night, rain streaks thickening on the glass.

### W11　台风夜：钢针般暴雨、三四层楼高浪墙、白沫、闪电白/冷蓝/墨绿、多层合成雨丝、1/4速浪头
- **场次**：第1场, 第21场, 第22场
- **说明**：台风夜：钢针般暴雨、三四层楼高浪墙、白沫、闪电白/冷蓝/墨绿、多层合成雨丝、1/4速浪头
- **状态**：已出图（浪高尺度已补）
- **文件**：W11_wave_height.jpg；W_vfx_sheet.jpg (panel 6) 仍作情绪板
- **提示词要点**：typhoon night, needle rain, 3–4-storey dark-green wave wall scaled against architecture, lightning
- **检查**：Pass. Dedicated still: a dark-green/ink wave wall taller than the harbor lighthouse and keeper house, tiny figures on the pier for scale, needle rain, cold-white/blue lightning, white foam. Slightly painterly, appropriate for a VFX plate. 1/4-speed and cracked-glass water remain implied for animation.

### W12　水下：墨黑、气泡上翻、闪电照亮的碎玻璃水面
- **场次**：第1场, 第23场
- **说明**：水下：墨黑、气泡上翻、闪电照亮的碎玻璃水面
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 7)
- **提示词要点**：underwater ink-black, bubbles, light from above
- **检查**：Pass.

### W13　探照灯体积光柱劈开雨幕
- **场次**：第23场
- **说明**：探照灯体积光柱劈开雨幕
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 7) + U09_endcard.jpg
- **提示词要点**：volumetric searchlight / lighthouse shaft cutting rain or water
- **检查**：Combined with the underwater plate rather than a boat-mounted 探照灯 sweep. Usable.

### W14　台风后洗净的天空与晚霞
- **场次**：第24场
- **说明**：台风后洗净的天空与晚霞
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet_2.jpg (panel 6)
- **提示词要点**：washed-clean post-typhoon sky and sunset, 第24场
- **检查**：Pass. Pale washed sky and a calm gilt sunset over a clean harbor.

### W15　弹幕VFX（见UI：RGB色散、像素碎裂、文字粒子、萤火虫消散）
- **场次**：第5场, 第7场, 第18场, 第23场
- **说明**：弹幕VFX（见UI：RGB色散、像素碎裂、文字粒子、萤火虫消散）
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 8) + U01/U02/U09
- **提示词要点**：RGB fringe, pixel shatter, particle dissolve, fireflies
- **检查**：Pass as a combined danmaku-VFX panel.

### W16　闪回滤镜：褪色蓝灰+颗粒噪点
- **场次**：第14场
- **说明**：闪回滤镜：褪色蓝灰+颗粒噪点
- **状态**：在拼贴图中
- **文件**：W_vfx_sheet.jpg (panel 8 grain)
- **提示词要点**：faded blue-gray grainy flashback grade, 第14场
- **检查**：Present as a grain/grade swatch, not a full flashback frame of the corridor fight.

## 声音（32，不出图）
总表 `other.sounds` A01–A32 为音效/配乐设计，不在本目录出图。

## 问题与未完成
末轮（约 30 分钟，同一套画法规则：只对齐人物参考的线描与赛璐珞，不写字，逐张检查）已完成清单内项：EX04 / EX05 姿势表、EX09 渔民与街坊变体、A01 湿毛与窗台、U07 房间淹没三格、W11 三四层楼浪墙、G06 粉紫几何灯管、EX08 改黄对齐 P45、U02 半透明错落弹幕、女同学补 45°、霸凌变体改为少年形象。P99 左侧角度两次重绘仍不齐，与其它细小外观问题一并记入 `/workspace/bie-xin-danmu/qc/post_fix_list.md`，本轮不再修。

本目录现状：56 张唯一图像，75 个 jpg。官方 other ID 均已有图或拼贴覆盖（P81 仍由道具 P05 承担；声音 A01–A32 不出图）。
