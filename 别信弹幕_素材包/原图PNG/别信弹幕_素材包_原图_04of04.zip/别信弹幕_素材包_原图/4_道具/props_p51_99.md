<!-- 本文件是 P51–P99 出图分组报告。完整目录已于 2026-11-11 修正轮合并进同目录 `props.md`，请以 props.md 为准。 -->

# 《别信弹幕》道具设定 P51–P99 本路出图报告

对照：`/workspace/bie-xin-danmu/assets_bible/assets.json`、`assets_bible.md`。
画风：对齐 `batch/refs/ref_xiazhiyao.png` 的线稿/赛璐珞/软现代动画技法，颜色按各道具自身描述。
规范：白底转面（理想 8 个水平角 + 俯视 + 特写），无字（后期加），无人物。
本路只负责 P51–P99。目录：`/workspace/bie-xin-danmu/assets_bible/props/`。

## 统计

- P51–P99 共 49 件，全部已有正式编号文件：**49 / 49**
- 本路新出（本轮生成）：**43** 件（其余 6 件为本轮开始前已在目录中的旧稿：P59、P79、P81、P82、P83、P88）
- 合页（同一张图复制到多个 ID 文件名，与 P06/P07 先例相同）：
  - P51 + P52（剥虾 / 面团案板）→ `P51_boxia.png`
  - P53 + P70 + P73 + P93（缴费单 / 饭卡 / 纸条 / 纸牌）→ `P53_bowei_jiaofeidan.png`
  - P54 + P61 + P72（便当 / 虾饼 / 鱼蛋）→ `P54_biandang.png`
  - P55 + P96 + P97（三部手机）→ `P55_songjiayi_shouji.png`
  - P60 + P63 + P69 + P84（毛巾 / 碎石 / 泳镜 / 毯子）→ `P60_maojin.png`
  - P64 + P68 + P74（便利贴 / 手写日历 / 挂历）→ `P64_bianlitie.png`
  - P66 + P75（煎蛋面 / 晚饭排骨面）→ `P66_jiandan_liangwanmian.png`
  - P76 + P78（汤勺汤锅 / 海鲜粥）→ `P76_tangshao.png`

## 本轮新出文件清单

- `P51_boxia.png`（合 P52）
- `P52_miantuan_anban.png`（同 P51）
- `P53_bowei_jiaofeidan.png`（合 P70/P73/P93）
- `P54_biandang.png`（合 P61/P72）
- `P55_songjiayi_shouji.png`（合 P96/P97）
- `P56_tiantai_hezhao.png`
- `P57_houChu_huozai_yinhuan.png`
- `P58_guazhong.png`
- `P60_maojin.png`（合 P63/P69/P84）
- `P61_xiabing.png`（同 P54）
- `P62_shuiguopan.png`
- `P63_suishi.png`（同 P60）
- `P64_bianlitie.png`（合 P68/P74）
- `P65_zhouyan_weiqun.png`
- `P66_jiandan_liangwanmian.png`（合 P75）
- `P67_xiehe_jiangpai.png`
- `P68_shouxie_rili.png`（同 P64）
- `P69_yongjing.png`（同 P60）
- `P70_fanka.png`（同 P53）
- `P71_xiaofangshuanxiang.png`
- `P72_yudan.png`（同 P54）
- `P73_songjiayi_zhitiao.png`（同 P53）
- `P74_zhiyao_rili.png`（同 P64）
- `P75_wanfan.png`（同 P66）
- `P76_tangshao.png`（合 P78）
- `P77_jiudianshi.png`
- `P78_haixianzhou.png`（同 P76）
- `P80_xiahongmei_diandongche.png`
- `P84_tanzi.png`（同 P60）
- `P85_jiushengting.png`
- `P86_piaofuwu.png`
- `P87_yigeyuehou_fancai.png`
- `P89_xunlianbao.png`
- `P90_jianbao_xiangkuang.png`
- `P91_waipo_laozhaopian.png`
- `P92_wanjia.png`
- `P93_shouxie_zhipai.png`（同 P53）
- `P94_jiandao.png`
- `P95_taideng.png`
- `P96_zhouyan_shouji.png`（同 P55）
- `P97_waipo_shouji.png`（同 P55）
- `P98_xiaoyuchuanqun.png`
- `P99_gongjiaoche.png`

先前已在目录、本路未重画：`P59_hongse_miehuoqi.png`、`P79_chuanchuanshi.png`、`P81_haishenghao.png`、`P82_tanzhaodeng.png`、`P83_jiushengquan.png`、`P88_yanzi_wan.png`。

## 关键项检查

### P90 校报剪报相框
- 文件：`P90_jianbao_xiangkuang.png`
- 首稿失败：用人物卡作风格参考时，相框里画出了夏知遥全身转面，未采用。
- 重画：不用人物参考，改用裁出的空框/模糊栏剪报。定稿无人物。浅木框，栏为模糊不可读的灰纹理，另有空白米色衬底特写。
- 余问：个别剪报页眉仍有极淡疑似字形，需后期抹掉；空白照片区多在特写里单独出现，没有稳定地嵌在剪报版心。

### P91 外婆黑白老照片
- 文件：`P91_waipo_laozhaopian.png`
- 首稿失败：同样串进人物校服转面，未采用。
- 重画：抽象失焦的灰调港景/船影，白边、四角发黄、图钉、背面，无面孔、无人形。按任务要求处理为「框/照片物件 + 内容抽象」，不画年轻外婆与海魂衫小伙。

### 载具
- P80 深蓝色旧电动车：八角度 + 俯视 + 特写，有车篮和后架。车架侧面仍有淡淡商标形残字，需后期去掉。颜色偏中蓝，略浅于「深蓝」。
- P85 橙色硬壳充气救生艇：多角度 + 俯视 + 警灯特写，无字。挂机近景可能有类似品牌的细部，需核对后期去掉。
- P98 避风塘小渔船群：主船转面 + 青/红/白三种变体、渔网、纯色旗（无字）。主船部分侧面较重复，斜侧略少。
- P99 浅绿色公交：完整车体转面 + 俯视，目的地牌留白。首稿有一截成货车斗的错误视角，已重画，定稿车体完整。
- 监控摄像头 P24–P29 不在本路范围（P01–P50）。

## 分条问题（对照圣经，已各重画一次仍残留的记在这里）

1. **文字政策**：P90 剪报页眉淡痕；P53 浅粉缴费单左侧仍有很小的栏目标签残字（「黑名」一类），需后期抹平；P55 合页上有 P55/P96/P97 编号字，且老人机按键上有数字；P57 图上有英文 BEFORE / DANGER / SAFE；P80 车架残标。其余新图基本留白。
2. **P57 后厨隐患组**：单件正确（耳柄黑铁锅、长柄铝锅、双眼灶、灰白格抹布、水池）。组合作业的「危险布局」画成了灶上两口汤锅，没有「汤锅长柄伸向油锅、抹布垂近火苗」。安全布局也不完整。已重画一次（初稿还误把海生号船栓特写拼进来，已弃）。
3. **P55/P96/P97 手机**：白壳/黑壳中档机 + 红壳老人机方向正确。初稿三台都画成旗舰三摄，已重画。残留：图上有编号字；白/黑机个别视角误画成了带按键的老人机；按键有数字；画风偏产品图。
4. **P51 虾壳盆**：右侧盆更像带壳熟虾，不是剥下的虾壳。特写偏写实。
5. **P56 天台合照**：按「禁止出人物」处理成雨中天台、水箱、屋檐，以及一件失焦的藏青外套色块，无人脸。内容抽象，看不出「两人共披外套」的可识别轮廓。手机外形偏旗舰。
6. **P67 奖牌鞋盒**：金银铜 + 蓝挂带 + 浪花浮雕、无字，正确。奖牌是整齐一排放在浅盒里，不是「打开旧鞋盒、十来块叠放、最上一块大金牌」。
7. **P68 手写日历**：有玻璃压板和末格涂黑，但格子看起来是 4×4（16 格）而不是 17 格。无日期数字（后期加）。
8. **P66/P75 合页**：煎蛋面清楚；晚饭一侧除排骨盘外，还有把排骨盛进面碗的变体，不是干净的「三碗面 + 一盘排骨」。食物特写偏照片。
9. **转面完整度**：P65 围裙、P71 消防栓箱、P77 电视、P80 电动车、P89 训练包、P94 剪刀、P98/P99、P58 钟较完整。食物、纸品、纺织合页多为三四分之一 + 俯视，不是严格的八角度。
10. **画风**：整体是 2D 动画设定，但电动车/台灯/部分食物特写、手机合页偏产品图或照片质感；与人物卡比，线面硬度不完全一致。颜色未强制马卡龙粉。

## 未采用的废稿

首轮 P90、P91（相框/照片内画出人物）未入库。车辆首轮偏写实或公交被截成货车斗的稿未作定稿路径（定稿为重画版）。`props/_gen_refs/` 仅是为重画 P90/P91 裁的空框参考，不是定稿。
