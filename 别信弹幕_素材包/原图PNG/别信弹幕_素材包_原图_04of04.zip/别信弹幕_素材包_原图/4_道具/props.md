# 《别信弹幕：第十七天的他和我》道具设定（props）

对照总表：`/workspace/bie-xin-danmu/assets_bible/assets.json`（99件道具，含载具/摄像机等）。
画风要求：只对齐人物卡的**线稿/赛璐珞/软现代动画技法**（参考 `batch/refs/ref_xiazhiyao.png`），颜色按各道具剧本/圣经描述，不强制马卡龙粉色。
出图规范：白底转面，理想为正面、背面、左、右、四个斜侧（约45°/135°/225°/315°），再加俯视与细节特写；屏幕、招牌、刺绣、船名、碗底字一律后期加。
目录：`/workspace/bie-xin-danmu/assets_bible/props/`。旧版错编号或偏写实稿在 `_legacy/`，勿直接当定稿。
本页已合并两组目录：P01–P50 与 P51–P99 均已出图。P51–P99 的修正记录见各条「本轮状态」和 `qc/post_fix_list.md`。旧的分组报告仍保存在 `props_p51_99.md`，以本页为准。

## 本轮出图统计

- **全本 99 / 99 已出图**（含合页；无缺号）
- **P01–P50：50 / 50**；**P51–P99：49 / 49**
- 另有 UI 套件 1 张（`UI_danmu_app.png`）
- **合页（P01–P50）**：
  - P06 + P07 → `P06_gaozhi.png` / `P07_tugaiye_qianzi.png`（同一张）
  - P14 + P15 → `P14_P15_shouji.png`
  - P19 + P20 → `P19_P20_huiyi_wenjian.png`
  - P22 + P23 → `P22_P23_yanjing_yangui.png`
  - P24 + P25 + P26 + P27 + P28 + P29 → `P24-P29_jiankong.png`
  - P32 + P33 → `P32_P33_keting_jiaju.png`
  - P34 + P35 + P36 + P37 + P38 + P39 + P40 → `P34-P40_chuju_xiaojian.png`
  - P41 + P42 → `P41_P45_banjia_waimai.png`（合页上的旧外卖踏板已作废，勿用）
  - P45 单独成页 → `P45_waimai_diandongche.png`
  - P43 + P44 + P46 + P48 + P49 + P50 → `P43-P50_xiaojian.png`
  - P47 单独成页
- **合页（P51–P99）**：
  - P51 + P52 → `P51_boxia.png` / `P52_miantuan_anban.png`（同一张）
  - P53 + P70 + P73 + P93 → `P53_bowei_jiaofeidan.png`
  - P54 + P61 + P72 → `P54_biandang.png`
  - P55 + P96 + P97 → `P55_songjiayi_shouji.png`
  - P60 + P63 + P69 + P84 → `P60_maojin.png`
  - P64 + P68 + P74 → `P64_bianlitie.png`
  - P66 + P75 → `P66_jiandan_liangwanmian.png`
  - P76 + P78 → `P76_tangshao.png`

## 已出图清单（P01–P50）

- `P01_honghudiejie.png`
- `P02_zangqing_waitao.png`
- `P03_shengri_lazhu17.png`
- `P04_shengri_dangao.png`
- `P05_qianlan_zuowenben.png`
- `P06_gaozhi.png`
- `P07_tugaiye_qianzi.png`（与 P06 同一张）
- `P08_tougaoxiang.png`
- `P09_youyongdui_huizhang.png`
- `P10_zhouyan_shuangjianbao.png`
- `P11_zhiyao_shubao.png`
- `P12_zhiyao_shouji.png`
- `P13_fangshui_shoujidai.png`
- `P14_P15_shouji.png`（P14、P15）
- `P16_shouji_wendingqi.png`
- `P17_wuxian_erji.png`
- `P18_baise_mianbaoche.png`
- `P19_P20_huiyi_wenjian.png`（P19、P20）
- `P21_xuxiaoman_jiushouji.png`
- `P22_P23_yanjing_yangui.png`（P22、P23）
- `P24-P29_jiankong.png`（P24–P29）
- `P30_qiangshang_laozhaopian.png`
- `P31_jiu_xiangce.png`
- `P32_P33_keting_jiaju.png`（P32、P33）
- `P34-P40_chuju_xiaojian.png`（P34–P40）
- `P41_P45_banjia_waimai.png`（P41、P42；合页上的旧外卖踏板已作废）
- `P45_waimai_diandongche.png`
- `P43-P50_xiaojian.png`（P43、P44、P46、P48–P50）
- `P47_huang_yuyi.png`
- `UI_danmu_app.png`（弹幕UI，非 P 编号）


## 已出图清单（P51–P99）

- `P51_boxia.png`（P51、P52）
- `P52_miantuan_anban.png`（与 P51 同一张）
- `P53_bowei_jiaofeidan.png`（P53、P70、P73、P93）
- `P54_biandang.png`（P54、P61、P72）
- `P55_songjiayi_shouji.png`（P55、P96、P97）
- `P56_tiantai_hezhao.png`
- `P57_houChu_huozai_yinhuan.png`
- `P58_guazhong.png`
- `P59_hongse_miehuoqi.png`
- `P60_maojin.png`（P60、P63、P69、P84）
- `P61_xiabing.png`（与 P54 同一张）
- `P62_shuiguopan.png`
- `P63_suishi.png`（与 P60 同一张）
- `P64_bianlitie.png`（P64、P68、P74）
- `P65_zhouyan_weiqun.png`
- `P66_jiandan_liangwanmian.png`（P66、P75）
- `P67_xiehe_jiangpai.png`
- `P68_shouxie_rili.png`（与 P64 同一张）
- `P69_yongjing.png`（与 P60 同一张）
- `P70_fanka.png`（与 P53 同一张）
- `P71_xiaofangshuanxiang.png`
- `P72_yudan.png`（与 P54 同一张）
- `P73_songjiayi_zhitiao.png`（与 P53 同一张）
- `P74_zhiyao_rili.png`（与 P64 同一张）
- `P75_wanfan.png`（与 P66 同一张）
- `P76_tangshao.png`（P76、P78）
- `P77_jiudianshi.png`
- `P78_haixianzhou.png`（与 P76 同一张）
- `P79_chuanchuanshi.png`
- `P80_xiahongmei_diandongche.png`
- `P81_haishenghao.png`
- `P82_tanzhaodeng.png`
- `P83_jiushengquan.png`
- `P84_tanzi.png`（与 P60 同一张）
- `P85_jiushengting.png`
- `P86_piaofuwu.png`
- `P87_yigeyuehou_fancai.png`
- `P88_yanzi_wan.png`
- `P89_xunlianbao.png`
- `P90_jianbao_xiangkuang.png`
- `P91_waipo_laozhaopian.png`
- `P92_wanjia.png`
- `P93_shouxie_zhipai.png`（与 P53 同一张）
- `P94_jiandao.png`
- `P95_taideng.png`
- `P96_zhouyan_shouji.png`（与 P55 同一张）
- `P97_waipo_shouji.png`（与 P55 同一张）
- `P98_xiaoyuchuanqun.png`
- `P99_gongjiaoche.png`

## P01 红蝴蝶结（缎面，尾端绣“遥”）

- **英文名**：Red satin hair bow with the character 遥 embroidered on the tail
- **类别**：道具
- **归属**：夏知遥（父亲夏海生所送）
- **场次**：第1场、第2场、第3场、第6场、第7场、第10场、第12场、第15场、第16场、第17场、第18场、第20场、第21场、第22场、第23场、第24场、第25场
- **外观**：大号双环蝴蝶结，大红色缎面带光泽，两条垂尾约20cm，尾端用白色[设计补充]丝线绣一个小“遥”字；中心结扣包缎；系在后脑稍高处，正面看双环对称探出头顶。
- **状态变化**：
  - 第2场：妈妈替她系，“又快又紧”
  - 第3场：系得太急，被风吹松滑落在过道
  - 第7场：被手指一圈圈绕尾巴
  - 第15场：海风吹松，周砚帮她系歪
  - 第16场：被柯一鸣扯歪
  - 第18场：自己解下重新系紧
  - 第20场：妈妈最后一次替她系紧：“系紧点。”
  - 第1场：原本未来：在水下沉落，缎带像金鱼摆动
  - 第23场：湿透，在黑海面上被探照灯照到；水下被手腕旁的手抓住
  - 第24场：正常系着，被绕在指尖
- **备注**：['“遥”字刺绣颜色剧本未写，[设计补充]白色/金色二选一。', '文字类刺绣AI可能写错，建议出图后手工修字或后期贴图。']
- **出图提示词（圣经）**：prop turnaround sheet, Red satin hair bow with the character 遥 embroidered on the tail: large double-loop hair bow of glossy scarlet satin, two tails about 20 cm long, a tiny embroidered character on one tail end (white thread, design choice); wrapped satin knot; worn high on the back of the head so both loops show symmetrically above the head from the front. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the embroidered tail end, the center knot, satin sheen and folds, and the soaked drooping state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P01_honghudiejie.png`
- **本轮状态**：已出图（沿用）。2D 赛璐珞朱红缎面；尾端白线空白绣位，「遥」字后期加。问题：部分角度尾巴偏短偏宽；个别视图把卡子画到正面。

## P02 周砚的藏青外套（拉链夹克）

- **英文名**：Zhou Yan's navy zip-up jacket
- **类别**：道具
- **归属**：周砚
- **场次**：第1场、第2场、第3场、第4场、第6场、第7场、第10场、第13场、第17场、第21场、第22场、第23场、第24场
- **外观**：藏青色棉质立领拉链夹克，长度到胯，两侧斜插袋，左胸一枚小圆形徽章（见人物卡）；面料略哑光，袖口罗纹[设计补充]。
- **状态变化**：
  - 第4场：在家脱下，只穿白T
  - 第10场：罩在知遥头上，他那半边湿透
  - 第17场：出现在宋佳怡偷拍的照片里
  - 第21场：拉链拉到顶
  - 第22场：裹住豆豆
  - 第23场：豆豆抱着它站在码头
  - 第24场：搭在椅背上
  - 第6场：OP：和红蝴蝶结在风里交错飞过
- **备注**：['与服装 ZYN-L1 同一件；作为道具单独出图用于“罩头”“裹孩子”镜头。']
- **出图提示词（圣经）**：prop turnaround sheet, Zhou Yan's navy zip-up jacket: navy cotton stand-collar zip jacket, hip length, two slanted pockets, a small round badge on the left chest (per character card); matte fabric, ribbed cuffs . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the zipper and collar, pocket, small chest badge, soaked darker state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P02_zangqing_waitao.png`
- **本轮状态**：已按本轮决定重画并略软化线面：藏青立领拉链夹克，左胸不加徽章（徽章只别在书包带上）。问题：线面仍偏硬，斜侧第8格为敞开拉链。

## P03 数字蜡烛“17”（烧剩一半）

- **英文名**：Number candle '17' (half burned)
- **类别**：道具
- **归属**：夏知遥
- **场次**：第4场、第5场、第24场
- **外观**：数字造型蜡烛“1”“7”连体（或两根）[设计补充：连体一根]，约8cm高，奶油白蜡身带金色细描边[设计补充]，烛芯黑。
- **状态变化**：
  - 第4场：燃烧，被两人同时吹灭，白烟拧成∞
  - 第5场：烧剩一半，被纸巾包好攥在手心
  - 第24场：压在剪报相框底下
- **备注**：['剧本写“剧情数字蜡烛17”，是一根还是两根未写明，需确认。']
- **出图提示词（圣经）**：prop turnaround sheet, Number candle '17' (half burned): number-shaped candle '17' as one piece , about 8 cm tall, cream-white wax with thin gold outline , black wick. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups: new, burning with flame, half-melted, wrapped in tissue. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P03_shengri_lazhu17.png`
- **本轮状态**：已重画为连体一根「17」：1与7共底座、半烧残、烛芯已熄、奶油白金边。问题：俯视格画成带17阴刻的底座俯视，不像烛芯俯视；部分斜侧仍偏像两根立在同一底座上。

## P04 生日小蛋糕

- **英文名**：Small birthday cake
- **类别**：道具
- **归属**：夏家
- **场次**：第4场、第5场
- **外观**：直径约15cm奶油小蛋糕，白奶油抹面，顶部几颗草莓和奶油花[设计补充]。
- **状态变化**：
  - 第4场：完整，插蜡烛
  - 第5场：吃过一部分[设计补充]
- **出图提示词（圣经）**：prop turnaround sheet, Small birthday cake: small 15 cm cream cake with white frosting, a few strawberries and piped cream on top . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: top view, cut slice. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P04_shengri_dangao.png`
- **本轮状态**：已出图。约15cm白奶油草莓小蛋糕，烛孔空置。问题：部分正面重复；俯视草莓偏多。

## P05 浅蓝色作文本（规则笔记本《弹幕法则》）

- **英文名**：Light-blue composition notebook (the 'Danmaku Rules' notebook)
- **类别**：道具
- **归属**：夏知遥
- **场次**：第6场、第7场、第10场、第13场、第15场、第18场
- **外观**：A5软皮作文本，浅蓝色封面（封面字样后期加），内页横格米白纸，手写蓝黑字迹；用旧后边角微卷。
- **状态变化**：
  - 第6场：最后一页写《弹幕到底是什么？》4条
  - 第7场：加第5、6条
  - 第10场：雨中被外套一起裹住
  - 第13场：新一页改名《弹幕法则》1–8条
  - 第18场：加第9条；最后一页写“我不该相信他们”并折起
  - 第25场：片尾静帧画风“像知遥作文本里的插画”
- **备注**：['本子内文字一律后期加，出图时空白横格。']
- **出图提示词（圣经）**：prop turnaround sheet, Light-blue composition notebook (the 'Danmaku Rules' notebook): A5 soft-cover composition notebook with a light-blue cover (cover text in post), cream lined pages with handwritten blue-black ink; corners slightly curled from use. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: cover, open spread with handwritten list (text in post), close-up of the folded bottom edge of the last page. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P05_qianlan_zuowenben.png`
- **本轮状态**：已重画软化：浅蓝A5软皮、封面无字、空白内页、边角卷起。线面变化不大，仍是干净2D。

## P06 《港口的早晨》稿纸（被涂改液改名）

- **英文名**：Essay manuscript 'Harbor Morning' (name covered with correction fluid)
- **类别**：道具
- **归属**：夏知遥
- **场次**：第3场、第7场、第15场、第24场
- **外观**：几页A4方格稿纸，钢笔字；右上角一块白色涂改液，上方后来手写名字。
- **状态变化**：
  - 第7场：名字被涂→知遥在涂改液上方写回自己的名字→投进投稿箱
  - 第15场：最后一行下被画线，写“好看”
  - 第24场：登报剪报装进相框
- **出图提示词（圣经）**：prop turnaround sheet, Essay manuscript 'Harbor Morning' (name covered with correction fluid): a few sheets of A4 grid manuscript paper in fountain-pen handwriting; a patch of white correction fluid at the top right with a name later written above it. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the correction-fluid patch and the pen tip writing. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P06_gaozhi.png`
- **本轮状态**：已出图。A4方格稿纸，右上涂改液白块，字迹为不可读潦草（后期换正文）。与 P07 合页。

## P07 涂改液与借来的签字笔

- **英文名**：Correction fluid and a borrowed gel pen
- **类别**：道具
- **归属**：宋佳怡（涂改液）/ 知遥（借笔）
- **场次**：第7场
- **外观**：笔形涂改液（白色笔身）；黑色按动/拧盖签字笔。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Correction fluid and a borrowed gel pen: pen-type correction fluid (white body); black capped gel pen. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: pen tip close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P07_tugaiye_qianzi.png`
- **本轮状态**：已出图，与 P06 合页（同一张图：涂改液笔+黑色签字笔特写）。

## P08 校报投稿箱

- **英文名**：School newspaper submission box
- **类别**：道具
- **归属**：第七中学
- **场次**：第7场
- **外观**：挂墙木箱约40×30×15cm，正面上方一条投信口，正面标签牌空白（后期加字），刷浅绿色漆，带小锁。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, School newspaper submission box: wall-mounted wooden box about 40×30×15 cm, a slot at the top front, blank label plate (text in post), pale-green paint, small padlock. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: slot close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P08_tougaoxiang.png`
- **本轮状态**：已出图。浅绿木漆挂墙投稿箱，投信口、空白标签牌、小锁、背面支架，无人物。第一次试画串进人物，已重画。

## P09 褪色的蓝色游泳队徽章（浪花+“少年队”）

- **英文名**：Faded blue swim-team badge (wave motif, 'youth team')
- **类别**：道具
- **归属**：周砚
- **场次**：第3场、第10场、第14场、第15场、第22场
- **外观**：直径约3cm圆形珐琅别针徽章，褪色的蓝底，白色浪花图案，下方一条小弧形字带（文字后期）；边缘金属磨损。
- **状态变化**：无单独记录
- **备注**：['characters.md 的周砚提示词另写“夹克左胸有小圆形徽章”，与此书包带徽章是否同一枚/两枚，需确认。']
- **出图提示词（圣经）**：prop turnaround sheet, Faded blue swim-team badge (wave motif, 'youth team'): round enamel pin about 3 cm, faded blue field with a white wave motif and a small curved text ribbon (text in post); worn metal rim. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the wave design, the pin back, pinned on the bag strap. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P09_youyongdui_huizhang.png`
- **本轮状态**：已重画：褪色蓝底白浪花+底部空白字带（「少年队」后期），无泳者、无人物。带书包带别针特写。问题：肌理仍略厚，不像人物卡那么薄线。

## P10 周砚的黑色双肩包（单肩背）

- **英文名**：Zhou Yan's black backpack (worn on one shoulder)
- **类别**：道具
- **归属**：周砚
- **场次**：第2场、第3场、第8场、第12场、第13场、第16场、第21场
- **外观**：黑色尼龙双肩包，简洁无大logo，一侧肩带别蓝色游泳队徽章；略旧。
- **状态变化**：
  - 第21场：被扔在面馆门口
- **出图提示词（圣经）**：prop turnaround sheet, Zhou Yan's black backpack (worn on one shoulder): plain black nylon backpack with no big logo, the swim badge pinned on one strap; slightly worn. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: strap and badge close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P10_zhouyan_shuangjianbao.png`
- **本轮状态**：已重画软化。黑尼龙双肩包，肩带别与 P09 一致的浪花空白字带徽章。问题：徽章特写字带不够明显；未强调单肩背用法。

## P11 知遥的书包（侧袋网兜被刮破）

- **英文名**：Zhiyao's schoolbag (side mesh pocket torn)
- **类别**：道具
- **归属**：夏知遥
- **场次**：第7场、第8场、第18场
- **外观**：深棕色[设计补充]双肩书包，两侧网兜侧袋。
- **状态变化**：
  - 第8场：被电动车后视镜刮出长口子
  - 第18场：侧袋掉出宋佳怡纸条
- **出图提示词（圣经）**：prop turnaround sheet, Zhiyao's schoolbag (side mesh pocket torn): dark brown backpack with mesh side pockets. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups: intact mesh pocket and the long tear. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P11_zhiyao_shubao.png`
- **本轮状态**：已出图。深棕书包，侧袋网兜有长口子。[设计补充]颜色深棕。

## P12 知遥的手机

- **英文名**：Zhiyao's phone
- **类别**：道具
- **归属**：夏知遥
- **场次**：第3场、第16场、第17场、第18场、第19场、第20场、第21场、第22场
- **外观**：普通直板智能手机，浅色[设计补充]简单手机壳；屏幕内容后期合成。
- **状态变化**：
  - 第18场：掉地，前置摄像头录像红点亮
  - 第20场：架在书桌上录视频、发布
  - 第21场：装进防水袋挂在胸前
  - 第22场：直播→浸水黑屏只剩在线人数
- **出图提示词（圣经）**：prop turnaround sheet, Zhiyao's phone: ordinary slab smartphone with a pale simple case ; screen content composited in post. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: front/back, lit screen, black after submerged. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P12_zhiyao_shouji.png`
- **本轮状态**：已重画为普通中档直板机：浅米简壳、单后摄、挖孔屏、屏幕留白，不再是三摄旗舰。

## P13 外卖用防水手机袋（挂胸前）

- **英文名**：Waterproof phone pouch used for deliveries (worn on chest)
- **类别**：道具
- **归属**：夏记面馆
- **场次**：第21场、第22场
- **外观**：透明PVC防水手机袋，顶部三道密封扣，挂绳；可透袋看到手机屏。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Waterproof phone pouch used for deliveries (worn on chest): clear PVC waterproof phone pouch with triple zip-seal top and lanyard; screen visible through it. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the seal; worn on chest. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P13_fangshui_shoujidai.png`
- **本轮状态**：已出图。透明PVC防水袋、挂绳、袋内浅壳手机、屏幕留白。问题：正面重复偏多；密封扣看起来不像三道。

## P14 林朵朵的手机

- **英文名**：Lin Duoduo's phone
- **类别**：道具
- **归属**：林朵朵
- **场次**：第2场、第20场、第21场
- **外观**：粉色[设计补充]手机壳，挂小挂件。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Lin Duoduo's phone: phone with a pink case and a small charm . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: case back. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P14_P15_shouji.png`
- **本轮状态**：已出图，与 P15 合页。粉色壳中档手机+小花挂件，屏幕留白。[设计补充]粉壳。

## P15 围观的手机群（同学/食客/路人）

- **英文名**：Crowd of phones held up by onlookers
- **类别**：道具
- **归属**：同学、食客、围观学生
- **场次**：第3场、第6场、第7场、第16场、第20场
- **外观**：各色手机，镜头一律朝向主体，闪光灯/摄像头作为“眼睛”意象。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Crowd of phones held up by onlookers: assorted phones with camera lenses facing the subject, lenses read as 'eyes'. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of rear camera lenses. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P14_P15_shouji.png`
- **本轮状态**：已出图，与 P14 合页。多部各色中档手机镜头朝内围成一圈，作「眼睛」意象，屏幕留白、无品牌。

## P16 柯一鸣的手机+手持稳定器

- **英文名**：Ke Yiming's phone on a handheld gimbal
- **类别**：道具
- **归属**：柯一鸣
- **场次**：第1场、第14场、第16场、第22场
- **外观**：黑色三轴手机稳定器，夹一部大屏手机，手柄上带小补光灯[设计补充]。
- **状态变化**：
  - 第16场：摔在坡道上，镜头朝上
- **备注**：['第14场闪回（一年前）只写“举着手机”，无稳定器。']
- **出图提示词（圣经）**：prop turnaround sheet, Ke Yiming's phone on a handheld gimbal: black three-axis smartphone gimbal holding a large phone, small LED light on the handle . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: three-axis joints, phone clamp, dropped lens-up state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P16_shouji_wendingqi.png`
- **本轮状态**：已出图。黑色三轴稳定器夹手机。问题：手柄小补光灯不明显；一格手机横置。

## P17 柯一鸣的无线耳机（耳麦）

- **英文名**：Ke Yiming's wireless earbud mic
- **类别**：道具
- **归属**：柯一鸣
- **场次**：第16场、第20场、第22场
- **外观**：黑色单只入耳式无线耳机带短麦杆，戴左耳（人物卡）。
- **状态变化**：
  - 第20场：被摔在桌上
- **出图提示词（圣经）**：prop turnaround sheet, Ke Yiming's wireless earbud mic: single black in-ear wireless earbud with short mic stem, worn in the left ear (per card). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P17_wuxian_erji.png`
- **本轮状态**：已出图（2026-11-11 打磨重画）。黑色单只入耳式无线耳麦，8 面+俯视+特写；短麦杆在各角度都清楚可见。无字、无人。

## P18 白色面包车（车顶架补光灯）

- **英文名**：White van with flood lights on the roof
- **类别**：交通工具
- **归属**：柯一鸣
- **场次**：第22场
- **外观**：白色小型面包车，车顶行李架上架两盏方形补光灯，车身无字。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, White van with flood lights on the roof: small white minivan, two square flood lights on the roof rack, no markings. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of roof lights. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P18_baise_mianbaoche.png`
- **本轮状态**：已出图。白色小面包车，车顶行李架两盏方形补光灯，车牌留白、车身无字。

## P19 会议室笔记本电脑（视频连线）

- **英文名**：Laptop for the video call
- **类别**：道具
- **归属**：学校
- **场次**：第17场
- **外观**：银灰色普通笔记本电脑。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Laptop for the video call: plain silver laptop. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: screen-facing view. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P19_P20_huiyi_wenjian.png`
- **本轮状态**：已出图，与 P20 合页。银灰色笔记本，屏幕留白。键盘键帽为机器固有造型。

## P20 打印的网络截图与文件夹

- **英文名**：Printed screenshots and a folder
- **类别**：道具
- **归属**：钱主任
- **场次**：第17场
- **外观**：A4打印纸一叠（图像模糊，文字后期）+ 深蓝色文件夹。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Printed screenshots and a folder: stack of A4 printouts (blurry images, text in post) and a dark-blue folder. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P19_P20_huiyi_wenjian.png`
- **本轮状态**：已出图，与 P19 合页。深蓝文件夹+A4打印叠，图块模糊、文字栏留白。文件夹偏公事包造型。

## P21 许小满的旧手机（屏幕裂痕，03:12原视频）

- **英文名**：Xu Xiaoman's old phone (cracked screen, the 3:12 video)
- **类别**：道具
- **归属**：许小满
- **场次**：第14场、第19场、第20场
- **外观**：旧款小屏手机，屏幕左上到右下一道裂痕，边框磨损。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Xu Xiaoman's old phone (cracked screen, the 3:12 video): old small-screen phone with a diagonal crack across the screen, worn edges. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: crack close-up, lit screen. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P21_xuxiaoman_jiushouji.png`
- **本轮状态**：已出图（2026-11-11 打磨重画）。旧款小屏黑机、边框磨损；屏幕为左上到右下**一道**斜裂，正面与裂纹特写一致。无字、无品牌、背面为单摄像头无装饰符号。

## P22 许小满的圆框眼镜

- **英文名**：Xu Xiaoman's round glasses
- **类别**：道具
- **归属**：许小满
- **场次**：第14场、第19场、第24场、第25场
- **外观**：瘦小黑色细圆框眼镜。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Xu Xiaoman's round glasses: thin small black round-frame glasses. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: front and side. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P22_P23_yanjing_yangui.png`
- **本轮状态**：已出图，与 P23 合页。瘦小黑色细圆框眼镜多角度+铰链特写。

## P23 烟柜与烟盒

- **英文名**：Cigarette cabinet and packs
- **类别**：道具
- **归属**：便利店
- **场次**：第19场
- **外观**：收银台后玻璃烟柜，烟盒包装无字纯色块。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Cigarette cabinet and packs: glass cigarette cabinet behind the counter, packs as plain color blocks without text. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P22_P23_yanjing_yangui.png`
- **本轮状态**：已出图，与 P22 合页。玻璃烟柜，烟盒为无字纯色块。柜子偏高立柜。

## P24 面馆旧监控摄像头（楼梯拐角/收银台上方）

- **英文名**：Noodle shop's old CCTV cameras (stair landing / above counter)
- **类别**：监控
- **归属**：夏记面馆
- **场次**：第6场、第11场
- **外观**：旧款米白色枪式摄像头，带支架，镜头下方一颗红色指示灯，外壳发黄。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Noodle shop's old CCTV cameras (stair landing / above counter): old off-white bullet CCTV camera on a bracket with a red LED below the lens, yellowed housing. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: red LED close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P24-P29_jiankong.png`
- **本轮状态**：已出图，与 P25–P29 合页。旧款发黄米白枪机，镜头下红指示灯。

## P25 巷口小超市门口监控

- **英文名**：Mini-mart entrance CCTV
- **类别**：监控
- **归属**：小超市
- **场次**：第8场
- **外观**：黑色半球/枪机，挂门楣。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Mini-mart entrance CCTV: black bullet camera on the door lintel. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P24-P29_jiankong.png`
- **本轮状态**：已出图，与 P24–P29 合页。黑色门楣枪机。

## P26 天台物业监控

- **英文名**：Rooftop property CCTV
- **类别**：监控
- **归属**：物业
- **场次**：第10场
- **外观**：白色枪机装在立杆上。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Rooftop property CCTV: white bullet camera on a pole. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P24-P29_jiankong.png`
- **本轮状态**：已出图，与 P24–P29 合页。白色立杆枪机。

## P27 会议室监控

- **英文名**：Meeting-room CCTV
- **类别**：监控
- **归属**：学校
- **场次**：第17场
- **外观**：白色半球摄像头吊顶角落。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Meeting-room CCTV: white dome camera in the ceiling corner. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P24-P29_jiankong.png`
- **本轮状态**：已出图，与 P24–P29 合页。白色天花半球。

## P28 码头入口渔政监控

- **英文名**：Fisheries CCTV at the pier entrance
- **类别**：监控
- **归属**：渔政
- **场次**：第15场
- **外观**：立杆上的灰色枪机加太阳能板[设计补充]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Fisheries CCTV at the pier entrance: grey bullet camera on a pole with a small solar panel . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P24-P29_jiankong.png`
- **本轮状态**：已出图，与 P24–P29 合页。灰色立杆枪机+太阳能板[设计补充]。

## P29 便利店监控

- **英文名**：Convenience store CCTV
- **类别**：监控
- **归属**：便利店
- **场次**：第19场
- **外观**：天花角落白色半球。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Convenience store CCTV: white ceiling dome. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P24-P29_jiankong.png`
- **本轮状态**：已出图，与 P24–P29 合页。白色天花半球（较新）。

## P30 墙上旧照片：海生站在船头抱着系红蝴蝶结的小女孩

- **英文名**：Old wall photo: Haisheng on the boat bow holding a little girl with a red bow
- **类别**：道具
- **归属**：夏家
- **场次**：第2场、第24场
- **外观**：约30×20cm木框彩色旧照片，色彩褪成暖黄；画面内容如原文（船名白字后期）。
- **状态变化**：无单独记录
- **备注**：['剧本第2场旧照片在一楼面馆墙上；第24场“墙上，旧照片旁边”在二楼客厅。是同一张挂在两处，还是两张照片？需确认（本表设为两处各一张同底片）。']
- **出图提示词（圣经）**：prop turnaround sheet, Old wall photo: Haisheng on the boat bow holding a little girl with a red bow: about 30×20 cm wooden-framed old color photo faded warm-yellow, content as described (boat name added in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: make the photo image itself (captain Haisheng + little Zhiyao), then a faded framed version. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P30_qiangshang_laozhaopian.png`
- **本轮状态**：已出图。木框暖黄旧照：父亲在蓝白小船船头怀里抱着系红蝴蝶结的小女孩，船名留白。问题：缺少完整框背面。

## P31 旧相册（十岁生日照）

- **英文名**：Old photo album (10th birthday photo)
- **类别**：道具
- **归属**：夏家
- **场次**：第4场、第5场
- **外观**：厚布面旧相册，深红色封面，覆膜内页。
- **状态变化**：
  - 第5场：掉在地上翻开
- **出图提示词（圣经）**：prop turnaround sheet, Old photo album (10th birthday photo): thick cloth-bound old album, dark red cover, plastic-sleeve pages. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: open page with the 10th-birthday photo. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P31_jiu_xiangce.png`
- **本轮状态**：已出图（2026-11-11 打磨重画）。深红布面厚相册 8 面+俯视+磨旧边角特写+打开覆膜内页（小女孩红结与父亲、生日蛋糕，赛璐珞平涂）。线比上一版细，厚涂感已减轻。无字。

## P32 客厅置物架陈设（腌菜罐、渔网结装饰）

- **英文名**：Living-room shelf dressing (pickle jars, knotted fishing-net decorations)
- **类别**：道具
- **归属**：夏家
- **场次**：第4场、第5场、第21场、第24场
- **外观**：玻璃腌菜罐数个（萝卜、梅子色），挂墙渔网结与浮球装饰。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Living-room shelf dressing (pickle jars, knotted fishing-net decorations): several glass pickle jars, a knotted fishing net with floats as wall decor. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P32_P33_keting_jiaju.png`
- **本轮状态**：已出图，与 P33 合页。置物架腌菜罐（萝卜/梅子色）+渔网结与浮球。罐内更像圆果，不完全是切块腌菜。

## P33 客厅矮桌

- **英文名**：Living-room low table
- **类别**：道具
- **归属**：夏家
- **场次**：第4场、第5场、第18场、第21场、第24场
- **外观**：长方形实木矮桌约120×70cm，高35cm，桌面有使用痕迹。
- **状态变化**：无单独记录
- **备注**：['第18场“晚饭桌”未说是矮桌，按同一张[设计补充]。']
- **出图提示词（圣经）**：prop turnaround sheet, Living-room low table: rectangular solid-wood low table about 120×70 cm, 35 cm high, used surface. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P32_P33_keting_jiaju.png`
- **本轮状态**：已出图，与 P32 合页。实木矮桌多角度与桌面俯视。

## P34 外婆的炒勺与铁锅

- **英文名**：Grandma's wok and ladle
- **类别**：道具
- **归属**：陈秀英
- **场次**：第2场、第11场
- **外观**：黑铁炒锅带木柄，长柄不锈钢炒勺。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Grandma's wok and ladle: black iron wok with a wooden handle, long steel ladle. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P34-P40_chuju_xiaojian.png`
- **本轮状态**：已出图，与 P35–P40 合页。黑铁木柄炒锅+长柄钢炒勺。

## P35 面馆面碗（虾仁面）

- **英文名**：Noodle-shop bowl (shrimp noodles)
- **类别**：道具
- **归属**：夏记面馆
- **场次**：第2场、第4场、第11场、第14场、第18场、第24场、第25场
- **外观**：白瓷大面碗，碗沿一圈蓝边[设计补充，与“砚”碗统一]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Noodle-shop bowl (shrimp noodles): white porcelain noodle bowl with a blue rim . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: top view with noodles. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P34-P40_chuju_xiaojian.png`
- **本轮状态**：已出图，与 P34–P40 合页。蓝边白瓷面碗，碗底无字（「砚」字碗是 P88）。

## P36 收银台电话

- **英文名**：Cashier-counter landline
- **类别**：道具
- **归属**：夏红梅
- **场次**：第2场
- **外观**：米色老式座机。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Cashier-counter landline: beige old landline. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P34-P40_chuju_xiaojian.png`
- **本轮状态**：已出图，与 P34–P40 合页。米色老式座机。

## P37 瓷盘（摔碎）

- **英文名**：Porcelain plate (smashed)
- **类别**：道具
- **归属**：夏家
- **场次**：第5场
- **外观**：白瓷蛋糕盘，碎片状态。
- **状态变化**：
  - 第5场：摔碎
- **出图提示词（圣经）**：prop turnaround sheet, Porcelain plate (smashed): white porcelain cake plate, intact and shattered. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: shards. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P34-P40_chuju_xiaojian.png`
- **本轮状态**：已出图，与 P34–P40 合页。白瓷盘完整态与碎裂态。

## P38 薯片

- **英文名**：Potato chips
- **类别**：道具
- **归属**：朵朵、豆豆
- **场次**：第4场
- **外观**：袋装薯片（包装无字）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Potato chips: bag of chips (no text). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P34-P40_chuju_xiaojian.png`
- **本轮状态**：已出图，与 P34–P40 合页。无字黄橙薯片袋。

## P39 保鲜盒（装饺子）

- **英文名**：Food container (dumplings)
- **类别**：道具
- **归属**：周静/周砚
- **场次**：第4场、第9场
- **外观**：透明塑料保鲜盒蓝色扣盖，内装饺子。
- **状态变化**：
  - 第9场：归还，空盒
- **出图提示词（圣经）**：prop turnaround sheet, Food container (dumplings): clear plastic container with blue clip lid, dumplings inside. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P34-P40_chuju_xiaojian.png`
- **本轮状态**：已出图，与 P34–P40 合页。透明蓝扣保鲜盒，内装饺子。

## P40 打火机

- **英文名**：Lighter
- **类别**：道具
- **归属**：陈秀英
- **场次**：第4场
- **外观**：红色一次性打火机。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Lighter: red disposable lighter. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P34-P40_chuju_xiaojian.png`
- **本轮状态**：已出图，与 P34–P40 合页。红色一次性打火机。

## P41 搬家纸箱

- **英文名**：Moving boxes
- **类别**：道具
- **归属**：周家
- **场次**：第2场
- **外观**：牛皮纸箱、胶带。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Moving boxes: kraft cardboard boxes with tape. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P41_P45_banjia_waimai.png`
- **本轮状态**：已出图，与 P42 合页 `P41_P45_banjia_waimai.png`。牛皮纸箱与胶带。该合页上的旧外卖踏板已作废。

## P42 搬家小货车

- **英文名**：Small moving truck
- **类别**：交通工具
- **归属**：搬家公司
- **场次**：第2场
- **外观**：白蓝小型厢式货车，车身无字。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Small moving truck: small white-blue box truck, no markings. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P41_P45_banjia_waimai.png`
- **本轮状态**：已出图，与 P41 合页 `P41_P45_banjia_waimai.png`。白蓝小型厢式货车，车身无字、车牌留白。该合页上的旧外卖踏板已作废。

## P43 老奶奶的两大袋菜

- **英文名**：Old lady's two heavy grocery bags
- **类别**：道具
- **归属**：路人老奶奶
- **场次**：第2场
- **外观**：两只红白条纹塑料袋装满青菜。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Old lady's two heavy grocery bags: two red-white striped plastic bags stuffed with vegetables. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P43-P50_xiaojian.png`
- **本轮状态**：已出图，与 P44、P46、P48–P50 合页。两只红白条纹塑料袋装满青菜。

## P44 街坊阿姨的菜篮

- **英文名**：Neighbour aunties' shopping baskets
- **类别**：道具
- **归属**：阿姨甲/阿姨乙
- **场次**：第2场
- **外观**：阿姨甲：装青菜的藤编篮；阿姨乙：装紫茄子的红色塑料菜篮（据人物卡）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Neighbour aunties' shopping baskets: Auntie A: rattan basket of greens; Auntie B: red plastic basket of eggplants (per cards). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P43-P50_xiaojian.png`
- **本轮状态**：已出图，与 P43、P46、P48–P50 合页。藤编青菜篮 + 红色塑料茄篮。

## P45 外卖电动车（后视镜）

- **英文名**：Delivery e-scooter (with side mirror)
- **类别**：交通工具
- **归属**：外卖骑手
- **场次**：第8场
- **外观**：黄色[设计补充]外卖电动车，后座保温箱（无字），大后视镜，车灯。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Delivery e-scooter (with side mirror): yellow delivery e-scooter with an insulated box (no text), large side mirror, headlight. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: mirror close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P45_waimai_diandongche.png`
- **本轮状态**：已出图（2026-11-11 打磨重画，单独成页）。黄色自行车式外卖电动车（非踏板/Vespa），后座无字保温箱、车把后视镜、前大灯、电池仓。旧合页 `P41_P45_banjia_waimai.png` 上的踏板车已作废。问题：背面有两处相近的正后视图；个别角度后视镜数量不完全一致（侧视为一面大镜，部分背面画成两面）。

## P46 一小袋猫粮

- **英文名**：Small bag of cat food
- **类别**：道具
- **归属**：林豆豆
- **场次**：第8场、第21场
- **外观**：巴掌大的猫粮袋，橘色包装（无字）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Small bag of cat food: palm-sized cat-food pouch, orange packaging, no text. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P43-P50_xiaojian.png`
- **本轮状态**：已出图，与 P43–P44、P48–P50 合页。巴掌大橘色无字猫粮袋。

## P47 豆豆的明黄色雨衣（崭新）

- **英文名**：Doudou's bright-yellow raincoat (brand new)
- **类别**：道具
- **归属**：林豆豆
- **场次**：第8场、第13场、第15场、第21场、第22场、第23场
- **外观**：儿童连帽长雨衣，明黄色有光泽PVC，按扣门襟，及膝。
- **状态变化**：
  - 第21场：本该挂在后门挂钩上，不见了
  - 第22场：湿透
- **备注**：['同时是服装 LDou-L2。']
- **出图提示词（圣经）**：prop turnaround sheet, Doudou's bright-yellow raincoat (brand new): child's hooded long raincoat in glossy bright-yellow PVC, snap front, knee length. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: hood, snaps, hanging on the hook, soaked. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P47_huang_yuyi.png`
- **本轮状态**：已出图（单独页）。崭新明黄色儿童连帽雨衣。问题：多数格子帽子是戴上的。

## P48 后门挂钩（空）

- **英文名**：Back-door coat hook (empty)
- **类别**：道具
- **归属**：夏记面馆
- **场次**：第21场
- **外观**：门内侧铸铁单挂钩。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Back-door coat hook (empty): single cast-iron hook on the inside of the door. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: empty hook close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P43-P50_xiaojian.png`
- **本轮状态**：已出图，与 P43–P44、P46、P49–P50 合页。门内侧铸铁空挂钩。

## P49 创可贴盒+周砚的便利贴

- **英文名**：Box of band-aids with Zhou Yan's sticky note
- **类别**：道具
- **归属**：周砚
- **场次**：第9场
- **外观**：小纸盒创可贴（无字），一张淡黄便利贴，工整字迹（后期）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Box of band-aids with Zhou Yan's sticky note: small paper box of band-aids (no text), one pale-yellow sticky note with neat handwriting (in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: sticky note close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P43-P50_xiaojian.png`
- **本轮状态**：已出图，与相邻小件合页。无字创可贴纸盒、空白淡黄便利贴（字后期加）。

## P50 塑料袋

- **英文名**：Plastic bag
- **类别**：道具
- **归属**：周砚
- **场次**：第9场
- **外观**：白色半透明塑料袋，装保鲜盒和创可贴。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Plastic bag: translucent white plastic bag. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P43-P50_xiaojian.png`
- **本轮状态**：已出图，与相邻小件合页。半透明白塑料袋，空袋与装着盒子的状态。

## P51 剥虾（虾、虾壳、小板凳）

- **英文名**：Peeling shrimp (shrimp, shells, small stool)
- **类别**：道具
- **归属**：夏知遥
- **场次**：第9场
- **外观**：不锈钢盆装鲜虾、一盆虾壳，红色塑料小板凳。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Peeling shrimp (shrimp, shells, small stool): steel bowls of shrimp and shells, small red plastic stool. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P51_boxia.png`
- **本轮状态**：已出图（与 P52 合页）；2026-11-11 修正轮重排：左侧不锈钢盆为带壳生鲜虾，右侧盆和特写为剥下的空虾壳（不再是整只熟虾），另有红塑料小板凳、空盆、面团案板与湿布。问题：合页角度以正面/特写为主；空盆裁切边缘略硬。

## P52 面团、案板与湿布

- **英文名**：Dough, kneading board and damp cloth
- **类别**：道具
- **归属**：陈秀英
- **场次**：第9场
- **外观**：大块白面团，厚木案板，白纱湿布。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Dough, kneading board and damp cloth: large white dough, thick wooden board, white damp cloth. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P52_miantuan_anban.png`
- **本轮状态**：已出图（与 P51 同一张）。厚木案板、大块白面团、白纱湿布。见 P51。

## P53 避风塘泊位缴费单

- **英文名**：Typhoon-shelter berth fee receipt
- **类别**：道具
- **归属**：夏红梅
- **场次**：第9场、第21场
- **外观**：三联收据式A5单据，浅粉色[设计补充]，折成小方块；文字后期。
- **状态变化**：
  - 第9场：折起塞进围裙口袋
  - 第21场：从围裙口袋露出一角
- **出图提示词（圣经）**：prop turnaround sheet, Typhoon-shelter berth fee receipt: A5 triplicate receipt, pale pink , folded into a small square; text added in post. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: unfolded and folded close-ups. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P53_bowei_jiaofeidan.png`
- **本轮状态**：已出图（与 P70/P73/P93 合页）。浅粉三联单（展平+折叠）、空白饭卡、揉皱横格纸、空白 A3 纸牌。残字见 `qc/post_fix_list.md`：缴费单左侧仍有小栏目标签，需后期抹平。

## P54 便当

- **英文名**：Lunch box
- **类别**：道具
- **归属**：夏知遥
- **场次**：第10场
- **外观**：双层便当盒，浅蓝色[设计补充]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Lunch box: two-tier bento box, light blue . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: open top view. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P54_biandang.png`
- **本轮状态**：已出图（与 P61/P72 合页）。浅蓝双层便当（开合与俯视）、金黄虾饼上嵌整虾、素面纸袋与鱼蛋特写。问题：转面不是完整八角度。

## P55 宋佳怡的手机

- **英文名**：Song Jiayi's phone
- **类别**：道具
- **归属**：宋佳怡
- **场次**：第10场、第16场、第17场、第20场
- **外观**：白色手机壳。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Song Jiayi's phone: phone with a white case. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P55_songjiayi_shouji.png`
- **本轮状态**：已出图（与 P96/P97 合页）；2026-11-11 修正轮重画：白壳中档触屏机在所有视角都无物理键盘，已去掉编号字。画风仍略偏产品图。

## P56 天台合照（藏青外套下两人）

- **英文名**：The rooftop photo (two people under one navy jacket)
- **类别**：画面道具
- **归属**：宋佳怡拍/柯一鸣展示
- **场次**：第10场、第17场
- **外观**：手机屏内照片画面（雨中，水箱屋檐下两人共披外套）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, The rooftop photo (two people under one navy jacket): photo on a phone screen: in the rain, two people under one jacket beneath the water-tank eave. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P56_tiantai_hezhao.png`
- **本轮状态**：已出图；2026-11-11 修正轮重画：雨中天台、水箱与屋檐，屏里两人共披一件藏青外套的剪影，面孔完全模糊不可辨。手机外形仍偏旗舰。按「禁止可识别人物」处理，不画五官。

## P57 后厨火灾隐患组（油锅、汤锅、燃气灶、抹布、水池）

- **英文名**：Kitchen fire-hazard set (fryer, soup pot, gas stove, dish rag, sink)
- **类别**：道具
- **归属**：夏记面馆
- **场次**：第11场
- **外观**：深口黑铁油锅；铝制汤锅长柄；双眼燃气灶；灰白格子抹布。
- **状态变化**：
  - 第11场：7:02危险布局→知遥处理后安全
- **出图提示词（圣经）**：prop turnaround sheet, Kitchen fire-hazard set (fryer, soup pot, gas stove, dish rag, sink): deep black iron fryer; aluminium soup pot with long handle; double gas burner; grey-white checked rag. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: hazard state (handle sticking out, rag touching flame) vs safe state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P57_houChu_huozai_yinhuan.png`
- **本轮状态**：已出图；2026-11-11 修正轮重画危险布局：左炉黑铁锅（带火）+ 右炉长柄铝锅，锅柄朝油锅方向伸出、间距约一拳，灰白格抹布垂在炉沿靠近火苗；安全布局为锅柄外转、抹布远离火焰。单件（锅、灶、抹布、水池）保留。问题：安全布局灶上仍有一小块蓝底乱码显示，需后期抹掉（见 `qc/post_fix_list.md`）。英文字标已去掉。

## P58 挂钟（面馆后厨/客厅）

- **英文名**：Wall clocks (kitchen / living room)
- **类别**：道具
- **归属**：夏家
- **场次**：第6场、第11场、第21场
- **外观**：后厨：白底黑针圆形挂钟带秒针；客厅：木框圆钟[设计补充]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Wall clocks (kitchen / living room): kitchen: white round clock with second hand; living room: wooden round clock . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: hands close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P58_guazhong.png`
- **本轮状态**：已出图。白底黑针红秒针后厨圆钟，木框客厅圆钟，无数字无商标，含背面、侧沿与特写。

## P59 红色灭火器（压力表指针在绿区）

- **英文名**：Red fire extinguisher (gauge in the green)
- **类别**：道具
- **归属**：周砚家
- **场次**：第11场
- **外观**：4kg红色干粉灭火器，黑色喷管，压力表。
- **状态变化**：
  - 第11场：被放在后巷地上
- **出图提示词（圣经）**：prop turnaround sheet, Red fire extinguisher (gauge in the green): 4 kg red dry-powder extinguisher with black hose and pressure gauge. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: gauge close-up with needle in green. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P59_hongse_miehuoqi.png`
- **本轮状态**：已出图。红色灭火器，无说明书文字，压力表可见。问题：部分斜侧较接近；未强调「指针在绿区」特写。

## P60 毛巾

- **英文名**：Hand towel
- **类别**：道具
- **归属**：面馆
- **场次**：第11场
- **外观**：白色旧毛巾。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Hand towel: worn white towel. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P60_maojin.png`
- **本轮状态**：已出图（与 P63/P69/P84 合页）。旧白毛巾、灰色毛毯、蓝镜片泳镜多角度、指甲盖大的灰碎石。问题：毛巾/毯子转面不完整，毛巾成色偏新。

## P61 虾饼

- **英文名**：Shrimp cakes
- **类别**：道具
- **归属**：陈秀英
- **场次**：第11场
- **外观**：金黄圆形炸虾饼，表面嵌整只虾。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Shrimp cakes: golden round fried shrimp cakes with whole shrimp on top. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P61_xiabing.png`
- **本轮状态**：已出图（与 P54 同一张）。金黄圆形炸虾饼，表面嵌整虾。见 P54。

## P62 水果盘（四盘，第四盘剥好的橘子）与糖水

- **英文名**：Fruit plates (four; the fourth peeled oranges) and sweet soup
- **类别**：道具
- **归属**：陈秀英
- **场次**：第13场
- **外观**：白瓷圆盘：西瓜、葡萄、苹果[设计补充]、剥好的橘子。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Fruit plates (four; the fourth peeled oranges) and sweet soup: white plates of watermelon, grapes, apple , peeled oranges. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P62_shuiguopan.png`
- **本轮状态**：已出图。四只白瓷盘：西瓜、葡萄、苹果片、剥开的橘瓣，另有一碗糖水。问题：多为四分之三正面，转面不完整；橘子偏切片而非整瓣去皮。

## P63 跑道上的碎石

- **英文名**：Pebble on the track
- **类别**：道具
- **归属**：—
- **场次**：第13场
- **外观**：指甲盖大小灰色碎石。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Pebble on the track: fingernail-sized grey pebble. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P63_suishi.png`
- **本轮状态**：已出图（与 P60 同一张）。灰碎石及无数字比例示意。见 P60。

## P64 冰箱门上的黄色便利贴（周静留言）与知遥留下的一张

- **英文名**：Yellow sticky notes on the fridge (Zhou Jing's) plus one from Zhiyao
- **类别**：道具
- **归属**：周静/夏知遥
- **场次**：第14场
- **外观**：黄色方形便利贴二十余张贴满冰箱门，手写（文字后期）；知遥那张用浅蓝便利贴[设计补充]以区分。
- **状态变化**：无单独记录
- **备注**：['characters.md 周静“代表元素：便利贴、保温盒”。']
- **出图提示词（圣经）**：prop turnaround sheet, Yellow sticky notes on the fridge (Zhou Jing's) plus one from Zhiyao: twenty-plus yellow square sticky notes covering the fridge door, handwritten (text in post); Zhiyao's one in light blue to stand out. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P64_bianlitie.png`
- **本轮状态**：已出图（与 P68/P74 合页）。冰箱门贴满空白黄便利贴，一张浅蓝便利贴突出；挂墙九月月历图画区为海浪、无字。见 P68。

## P65 周砚的围裙

- **英文名**：Zhou Yan's apron
- **类别**：道具
- **归属**：周砚
- **场次**：第14场
- **外观**：深灰色素面挂脖围裙[设计补充]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Zhou Yan's apron: plain dark-grey bib apron . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P65_zhouyan_weiqun.png`
- **本轮状态**：已出图。深灰挂脖围裙，八角度 + 平铺正反面与系带特写。素面无字；带口袋。

## P66 煎蛋与两碗面

- **英文名**：Fried eggs and two bowls of noodles
- **类别**：道具
- **归属**：周砚
- **场次**：第14场
- **外观**：两只普通白碗清汤面，各卧一只煎蛋。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Fried eggs and two bowls of noodles: two plain white bowls of noodle soup each topped with a fried egg. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P66_jiandan_liangwanmian.png`
- **本轮状态**：已出图（与 P75 合页）；2026-11-11 修正轮重画晚饭一侧。左侧为清汤面卧煎蛋（多角度）；右侧固定为清汤面碗 + 单独一盘红烧排骨，排骨不再盛进面碗。画风为赛璐珞，已去掉偏照片的特写。

## P67 鞋盒与游泳奖牌

- **英文名**：Shoebox of swimming medals
- **类别**：道具
- **归属**：周砚
- **场次**：第14场
- **外观**：打开的旧鞋盒，十几块金银铜奖牌带蓝色挂带，最上面一块金色。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Shoebox of swimming medals: open old shoebox with a dozen gold/silver/bronze medals on blue ribbons, a gold one on top. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: top view. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P67_xiehe_jiangpai.png`
- **本轮状态**：已出图；2026-11-11 修正轮重画：打开的旧鞋盒里金银铜奖牌（蓝挂带、浪花浮雕、无字）叠放，特写里金牌压在最上面。盒身转面仍偏产品图，盒内排列还不够完全凌乱。

## P68 周砚的手写日历（9/1–9/17，17日涂黑）

- **英文名**：Zhou Yan's handwritten calendar (1–17 Sept, the 17th blacked out)
- **类别**：道具
- **归属**：周砚
- **场次**：第14场
- **外观**：一张A4纸手画17格日历，红笔圈注（文字后期），第17格整块黑色马克笔涂满，压在书桌玻璃下。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Zhou Yan's handwritten calendar (1–17 Sept, the 17th blacked out): an A4 sheet hand-drawn into 17 boxes with red-pen circles (text in post), box 17 filled solid black with marker, under the desk glass. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the black box. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P68_shouxie_rili.png`
- **本轮状态**：已出图（与 P64/P74 同一张）；2026-11-11 修正轮把手工日历改为整整 17 格：三行五格加第四行两格，第 17 格涂黑，无日期数字（后期加），旁有桌面玻璃板。

## P69 泳镜（提及）

- **英文名**：Swim goggles (mentioned)
- **类别**：道具
- **归属**：周砚
- **场次**：第14场
- **外观**：蓝色镜片泳镜。
- **状态变化**：无单独记录
- **备注**：['人物卡代表元素之一；剧本只在台词中提及。']
- **出图提示词（圣经）**：prop turnaround sheet, Swim goggles (mentioned): blue-lens swim goggles. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P69_yongjing.png`
- **本轮状态**：已出图（与 P60 同一张）。蓝镜片泳镜，含正面、侧面、背面与镜片特写。见 P60。

## P70 饭卡（闪回）

- **英文名**：Meal card (flashback)
- **类别**：道具
- **归属**：许小满
- **场次**：第14场
- **外观**：白色塑料校园卡。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Meal card (flashback): white plastic school card. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P70_fanka.png`
- **本轮状态**：已出图（与 P53 同一张）。白色饭卡，照片窗留白，无编号。见 P53。

## P71 消防栓箱（闪回）

- **英文名**：Fire-hydrant cabinet (flashback)
- **类别**：道具
- **归属**：旧学校
- **场次**：第14场
- **外观**：红色墙嵌消防栓箱。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Fire-hydrant cabinet (flashback): red wall-mounted hydrant cabinet. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P71_xiaofangshuanxiang.png`
- **本轮状态**：已出图。红色墙嵌消防栓箱，门上无字，含关闭、侧沿、开门见水带与阀门特写。

## P72 一袋鱼蛋

- **英文名**：Bag of fish balls
- **类别**：道具
- **归属**：—
- **场次**：第15场
- **外观**：纸袋/竹签咖喱鱼蛋[设计补充]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Bag of fish balls: paper bag of curry fish balls on skewers . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P72_yudan.png`
- **本轮状态**：已出图（与 P54 同一张）。素面纸袋与竹签咖喱鱼蛋。见 P54。

## P73 宋佳怡的纸条

- **英文名**：Song Jiayi's note
- **类别**：道具
- **归属**：宋佳怡
- **场次**：第18场
- **外观**：巴掌大的横格纸，揉皱后展开。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Song Jiayi's note: palm-sized lined note paper, crumpled and unfolded. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P73_songjiayi_zhitiao.png`
- **本轮状态**：已出图（与 P53 同一张）。巴掌大揉皱横格纸，无字。见 P53。

## P74 知遥卧室墙上的日历

- **英文名**：Wall calendar in Zhiyao's room
- **类别**：道具
- **归属**：夏知遥
- **场次**：第18场
- **外观**：挂墙月历，九月页。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Wall calendar in Zhiyao's room: hanging monthly calendar on the September page. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P74_zhiyao_rili.png`
- **本轮状态**：已出图（与 P64 同一张）。挂墙月历，海浪图画区，日期格无字。见 P64。

## P75 晚饭：三碗面、排骨、筷子

- **英文名**：Dinner: three bowls of noodles, spare ribs, chopsticks
- **类别**：道具
- **归属**：夏家
- **场次**：第18场
- **外观**：三只面碗、一盘红烧排骨、竹筷。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Dinner: three bowls of noodles, spare ribs, chopsticks: three noodle bowls, a plate of braised ribs, bamboo chopsticks. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P75_wanfan.png`
- **本轮状态**：已出图（与 P66 同一张）；2026-11-11 修正轮改为一致的晚饭组合：清汤面碗 + 单独一盘红烧排骨 + 竹筷，面碗里不再出现排骨。见 P66。

## P76 汤勺（熬汤）

- **英文名**：Soup ladle
- **类别**：道具
- **归属**：夏红梅
- **场次**：第20场
- **外观**：长柄不锈钢汤勺，大汤锅。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Soup ladle: long steel ladle and a big stockpot. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P76_tangshao.png`
- **本轮状态**：已出图（与 P78 合页）。长柄不锈钢汤勺、大铝锅、砂锅海鲜粥与白瓷勺。问题：铝锅各视角较接近。

## P77 客厅旧电视

- **英文名**：Living-room TV
- **类别**：道具
- **归属**：夏家
- **场次**：第21场、第24场
- **外观**：小尺寸平板电视放在电视柜上（画面后期）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Living-room TV: small flat TV on the cabinet (screen in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P77_jiudianshi.png`
- **本轮状态**：已出图。小尺寸旧平板电视放在木电视柜上，屏幕留黑，含背面线缆、俯视与特写。

## P78 一大锅海鲜粥与勺子

- **英文名**：Big pot of seafood congee and spoons
- **类别**：道具
- **归属**：陈秀英
- **场次**：第21场
- **外观**：砂锅/大铁锅海鲜粥，白瓷勺。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Big pot of seafood congee and spoons: big clay pot of seafood congee, white porcelain spoons. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P78_haixianzhou.png`
- **本轮状态**：已出图（与 P76 同一张）。砂锅海鲜粥（可见虾与鱼片）与白瓷勺。见 P76。

## P79 海生号旧钥匙串（褪色小木牌刻“海生”）

- **英文名**：Old key ring of the Haisheng with a faded wooden tag
- **类别**：道具
- **归属**：夏红梅
- **场次**：第21场
- **外观**：铜钥匙三四把串在铁环上，椭圆小木牌褪色发白，刻字（后期修字）。
- **状态变化**：无单独记录
- **备注**：['挂在墙上的位置剧本未写——本表设为面馆一楼门边墙钉[设计补充]。']
- **出图提示词（圣经）**：prop turnaround sheet, Old key ring of the Haisheng with a faded wooden tag: three or four brass keys on an iron ring with a small faded oval wooden tag with carved characters (fix text in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the carved tag. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P79_chuanchuanshi.png`
- **本轮状态**：已出图（已从照片级重画为2D）。铁环、黄铜钥匙、椭圆木牌留白刻位。问题：多数格子只有一两把钥匙，木牌没有出现在每一面；不是稳定的三四把钥匙组合。

## P80 夏红梅的电动车

- **英文名**：Xia Hongmei's e-bike
- **类别**：交通工具
- **归属**：夏红梅
- **场次**：第21场
- **外观**：深蓝色[设计补充]老款电动自行车，带车篮。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Xia Hongmei's e-bike: old dark-blue electric bicycle with front basket. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P80_xiahongmei_diandongche.png`
- **本轮状态**：已出图（相对首稿已改成 2D 动画风）。深蓝旧电动车，前篮、后货架，八角度 + 俯视 + 特写。车架侧有淡商标残字，见 `qc/post_fix_list.md`。颜色略浅于「深蓝」。

## P81 海生号（旧小机动渔船，船头白字“海生”）

- **英文名**：The Haisheng (old small motor fishing boat, white characters on the bow)
- **类别**：交通工具
- **归属**：夏海生→夏红梅
- **场次**：第2场、第15场、第21场、第23场、第25场
- **外观**：长约7米[设计补充]木质小机动渔船，蓝白[设计补充]船身漆斑驳，船头左右两侧白漆“海生”二字（后期修字），船尾舵柄+挂机，船舷挂旧救生圈，船尾支架装手持探照灯。
- **状态变化**：
  - 第2场：照片里：新船
  - 第15场：十年未开，漆斑驳
  - 第23场：台风夜开出救人
  - 第25场：重新漆过
- **备注**：['船体颜色剧本未写，[设计补充]。']
- **出图提示词（圣经）**：prop turnaround sheet, The Haisheng (old small motor fishing boat, white characters on the bow): about 7 m wooden small motor fishing boat with weathered blue-and-white paint , white painted name on both sides of the bow (fix text in post), tiller and outboard at the stern, old life ring on the gunwale, handheld searchlight at the stern. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: bow lettering, stern helm, life ring, weathered vs repainted. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P81_haishenghao.png`
- **本轮状态**：已出图（已按圣经改为蓝白斑驳船身，2D动画风）。船头名牌留白后期，舷侧救生圈、船尾挂机与黄探照灯。问题：挂机上可能有细小英文商标；俯视有两只救生圈。

## P82 海生号手持探照灯

- **英文名**：Handheld searchlight on the Haisheng
- **类别**：道具
- **归属**：夏红梅
- **场次**：第23场
- **外观**：黄色[设计补充]手持船用探照灯，圆形大灯头。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Handheld searchlight on the Haisheng: yellow handheld marine searchlight with a large round head. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: head close-up / beam on. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P82_tanzhaodeng.png`
- **本轮状态**：已出图。黄色手持船用探照灯，八方向较完整。[设计补充]黄色。

## P83 旧救生圈（印褪色“海生”）

- **英文名**：Old life ring printed with a faded 'Haisheng'
- **类别**：道具
- **归属**：海生号
- **场次**：第23场
- **外观**：橙红白相间旧救生圈，带绳，字迹褪色（后期）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Old life ring printed with a faded 'Haisheng': old orange-and-white life ring with rope, faded lettering (in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P83_jiushengquan.png`
- **本轮状态**：已出图。橙白旧救生圈、带绳、无字。问题：俯视与斜俯有些接近。

## P84 毯子

- **英文名**：Blanket
- **类别**：道具
- **归属**：夏红梅
- **场次**：第23场
- **外观**：灰色旧毛毯[设计补充]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Blanket: old grey wool blanket . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P84_tanzi.png`
- **本轮状态**：已出图（与 P60 同一张）。灰色旧毛毯。见 P60。

## P85 海上救援橙色救生艇

- **英文名**：Orange sea-rescue boat
- **类别**：交通工具
- **归属**：海上救援
- **场次**：第23场
- **外观**：橙色硬壳充气救生艇，顶灯蓝红警灯（无字）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Orange sea-rescue boat: orange rigid inflatable rescue boat with flashing warning lights (no text). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P85_jiushengting.png`
- **本轮状态**：已出图。橙色硬壳充气救生艇，蓝红警灯，无字，多角度 + 俯视。挂机近景可能有细小品牌痕迹，建议后期抹掉。

## P86 漂浮物：断缆绳与泡沫箱

- **英文名**：Floating debris: broken ropes and foam boxes
- **类别**：道具
- **归属**：—
- **场次**：第23场
- **外观**：白色泡沫鱼箱、断裂的蓝色/黄色尼龙缆绳。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Floating debris: broken ropes and foam boxes: white styrofoam fish boxes, snapped blue/yellow nylon ropes. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P86_piaofuwu.png`
- **本轮状态**：已出图。白色泡沫鱼箱（完好/开裂）与蓝、黄断裂尼龙缆绳及散股特写，无字。

## P87 一个月后的饭菜：红烧鱼、周静带的一锅汤、瓜子

- **英文名**：Dinner a month later: braised fish, Zhou Jing's pot of soup, sunflower seeds
- **类别**：道具
- **归属**：夏家/周静/朵朵
- **场次**：第24场
- **外观**：大瓷盆红烧鱼、带盖汤锅、一捧瓜子。
- **状态变化**：无单独记录
- **备注**：['characters.md 周静代表元素“保温盒”：汤锅可做成保温桶[设计补充]。']
- **出图提示词（圣经）**：prop turnaround sheet, Dinner a month later: braised fish, Zhou Jing's pot of soup, sunflower seeds: big bowl of red-braised fish, lidded soup pot, a handful of sunflower seeds. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P87_yigeyuehou_fancai.png`
- **本轮状态**：已出图。大瓷盆红烧鱼、带提手的保温汤锅、一碟瓜子，多角度与特写，无字。

## P88 写着“砚”字的新碗（蓝边白瓷）

- **英文名**：New bowl with 砚 painted inside (blue-rimmed white porcelain)
- **类别**：道具
- **归属**：夏红梅送周砚
- **场次**：第24场
- **外观**：蓝边白瓷饭碗，碗底中央红漆小字（后期修字）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, New bowl with 砚 painted inside (blue-rimmed white porcelain): blue-rimmed white porcelain rice bowl, a small red-painted character at the bottom center (fix in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the bowl bottom. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P88_yanzi_wan.png`
- **本轮状态**：已出图。蓝边白瓷碗，碗底红字。问题：圣经要求「砚」字后期加，图里已写出繁体「硯」；碗外壁八个角度因旋转对称而较像。

## P89 “澄港少年游泳队”训练包

- **英文名**：Chenggang Youth Swim Team training bag
- **类别**：道具
- **归属**：周砚
- **场次**：第24场
- **外观**：藏青色手提运动包，侧面白色印字（后期）、浪花标志与徽章一致。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Chenggang Youth Swim Team training bag: navy duffel bag with white side print (in post) and the same wave emblem as the badge. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P89_xunlianbao.png`
- **本轮状态**：已出图。藏青手提训练包，侧面白色浪花标志、空白字位后期加字，八角度较完整。

## P90 校报剪报相框（征文一等奖）

- **英文名**：Framed newspaper clipping (essay first prize)
- **类别**：道具
- **归属**：夏家
- **场次**：第24场
- **外观**：简洁木框，内为泛黄校报剪报（文字后期）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Framed newspaper clipping (essay first prize): simple wooden frame holding a school-newspaper clipping (text in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P90_jianbao_xiangkuang.png`
- **本轮状态**：已出图。首稿把人物画进相框，已弃；定稿为浅木框 + 模糊不可读栏的校报剪报 + 空白照片区，无人物。页眉淡痕见 `qc/post_fix_list.md`。空白照片区多在特写里单独出现。

## P91 黑白老照片：年轻外婆与穿海魂衫的小伙子在渔船前

- **英文名**：Old B&W photo: young Grandma and a young man in a striped sailor shirt before a fishing boat
- **类别**：道具
- **归属**：陈秀英
- **场次**：第25场
- **外观**：小幅黑白照片，白边，钉在后厨墙上，四角发黄。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Old B&W photo: young Grandma and a young man in a striped sailor shirt before a fishing boat: small black-and-white photo with white border pinned to the kitchen wall, yellowed corners. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: make the photo image itself. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P91_waipo_laozhaopian.png`
- **本轮状态**：已出图。首稿串进人物，已弃；定稿为白边发黄的小幅黑白照，内容是失焦的港景/船影，图钉与背面，无面孔。按任务不画可识别的外婆与海魂衫人物。

## P92 碗架与洗碗

- **英文名**：Dish rack and washing up
- **类别**：道具
- **归属**：陈秀英
- **场次**：第25场
- **外观**：不锈钢碗架，叠放面碗。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Dish rack and washing up: steel dish rack with stacked bowls. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P92_wanjia.png`
- **本轮状态**：已出图。不锈钢碗架，叠放白面碗，含空架、多角度与俯视。

## P93 许小满的手写纸牌（看台）

- **英文名**：Xu Xiaoman's handmade sign (in the stands)
- **类别**：道具
- **归属**：许小满
- **场次**：第25场
- **外观**：A3白卡纸，手写加油字（后期）。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Xu Xiaoman's handmade sign (in the stands): A3 white card with handwritten cheer (text in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P93_shouxie_zhipai.png`
- **本轮状态**：已出图（与 P53 同一张）。空白 A3 白卡纸，加油字后期加。见 P53。

## P94 剪刀（OP意象）

- **英文名**：Scissors (opening-title motif)
- **类别**：意象道具
- **归属**：—
- **场次**：第6场
- **外观**：银色大剪刀。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Scissors (opening-title motif): large silver scissors. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P94_jiandao.png`
- **本轮状态**：已出图。银色大剪刀，开合与多角度、枢轴特写，无商标。

## P95 知遥书桌台灯

- **英文名**：Zhiyao's desk lamp
- **类别**：道具
- **归属**：夏知遥
- **场次**：第6场、第13场
- **外观**：奶油色金属摇臂台灯，暖光。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Zhiyao's desk lamp: cream metal arm desk lamp with warm light. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P95_taideng.png`
- **本轮状态**：已出图。奶油色金属摇臂台灯，暖光，多角度与开关、灯罩特写。画风略偏产品图。

## P96 周砚的手机

- **英文名**：Zhou Yan's phone
- **类别**：道具
- **归属**：周砚
- **场次**：第14场、第17场、第20场
- **外观**：黑色手机壳。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Zhou Yan's phone: phone with a black case. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P96_zhouyan_shouji.png`
- **本轮状态**：已出图（与 P55 同一张）。黑色中档触屏机，修正轮后各视角均无物理键盘。见 P55。

## P97 外婆的手机

- **英文名**：Grandma's phone
- **类别**：道具
- **归属**：陈秀英
- **场次**：第20场
- **外观**：大字老人机/大屏手机，红色壳[设计补充]。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Grandma's phone: big-screen phone with a red case . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P97_waipo_shouji.png`
- **本轮状态**：已出图（与 P55 同一张）。红壳大按键老人机，按键无数字，屏幕留黑。见 P55。

## P98 避风塘小渔船群（背景船）

- **英文名**：Fleet of small fishing boats in the shelter (background boats)
- **类别**：交通工具
- **归属**：—
- **场次**：第1场、第12场、第15场、第25场
- **外观**：各色小木渔船，桅杆、渔网、旗。
- **状态变化**：无单独记录
- **出图提示词（圣经）**：prop turnaround sheet, Fleet of small fishing boats in the shelter (background boats): assorted small wooden fishing boats with masts, nets and flags. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P98_xiaoyuchuanqun.png`
- **本轮状态**：已出图。主船转面 + 青/红/白三种避风塘小渔船变体，渔网与纯色旗，无船名。主船部分侧面较重复。

## P99 公交车（仅提及）

- **英文名**：City bus (mentioned only)
- **类别**：交通工具
- **归属**：—
- **场次**：第19场
- **外观**：剧本未出画；如需过场可做浅绿色城市公交[设计补充]。
- **状态变化**：无单独记录
- **备注**：['仅台词/动作描述，未明确出画。']
- **出图提示词（圣经）**：prop turnaround sheet, City bus (mentioned only): not shown in script; optional light-green city bus . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/P99_gongjiaoche.png`
- **本轮状态**：已出图。浅绿色城市公交，目的地牌留白，完整车体转面 + 俯视。首稿有一截成货车斗的错误视角，已重画。

## 额外文件

### UI_danmu_app.png
- **文件**：`/workspace/bie-xin-danmu/assets_bible/props/UI_danmu_app.png`
- **说明**：弹幕/直播UI套件（非 props 编号）。无字：竖屏直播框、单红点、空白弹幕条、冷灰/暖黄空白字幕卡、开关。注意不要与官方 P08「投稿箱」混淆。问题：底部俯视仍有双红点，与正面单点不一致。

## 问题与未完成（P01–P50 本组）

1. **P01–P50 已全部出图**（50/50），其中多件合页，见上文合页表。P51–P99 见下一节。
2. **已按决定修正**：P03 改为连体「17」半烧残；P02 左胸不加徽章；P09 改为浪花+空白字带、去掉泳者和人物；P12 改为普通中档机。P02/P05/P10 做了软化重画，但线面变化有限，仍略硬。
3. **转面**：合页小件多为正面/侧面/特写，不是完整 8 斜侧。单体关键件（投稿箱、连体蜡烛、徽章、手机、相册、面包车）更接近 8 面。
4. **文字**：新图尽量留白。蜡烛「17」是造型本身。P09 字带空白。P19 键盘为按键造型。
5. **已打磨（2026-11-11）**：P17 补清短麦杆；P21 改为左上到右下一道斜裂（已去掉交叉裂特写）；P31 改为细线赛璐珞、减轻厚涂；P45 改为单独页自行车式外卖电动车（非踏板）。仍有的偏差：P03 俯视格不理想；P45 背面两处正后视图接近、个别角度后视镜数量不完全一致；P08/P09 曾因人物卡参考把夏知遥画进画面，已去掉参考图重画。部分其他静物仍可能略厚。
6. **`_legacy/`**：旧编号或偏写实稿，仅供对照。本路修正前的 P51/P55/P56/P57/P64/P66/P67 等旧稿也在 `_legacy/pre_fixpass_*`。

## 问题与未完成（P51–P99）

1. **P51–P99 已全部出图**（49/49），其中多件合页，见上文合页表。关键项 P90 剪报相框、P91 黑白老照片（均已去掉误入的人物）、P80 电动车、P85 救生艇、P98 渔船群、P99 公交都已入库。
2. **2026-11-11 修正轮**：P57 危险布局改为油锅 + 锅柄朝油锅伸出 + 抹布近火；P51 虾壳盆改为空壳而非整虾；P67 奖牌在打开鞋盒里叠放、特写金牌在最上；P68 手写日历整整 17 格且第 17 格涂黑；P75 晚饭改为「面碗 + 单独排骨盘」、不再把排骨盛进面碗；P56 补上两人共披外套的模糊剪影；P55/P96/P97 去掉触屏机上的误植键盘和编号字。
3. **后期去字**：P53 缴费单栏目标签、P80 车架残标、P90 剪报页眉淡痕、P57 安全灶蓝底乱码，见 `qc/post_fix_list.md`。P55 新稿已无编号字和按键数字，仍建议扫一眼。
4. **仍有的小偏差**：P67 盒内排列还不够完全凌乱、画风略偏产品图；P56/P80/P95/部分手机合页线面仍偏产品图；食物/纸品/纺织合页多为正面与俯视，不是完整八角度；P51 空盆裁切边缘略硬。

