# 《别信弹幕：第十七天的他和我》前期美术资产圣经（Asset Bible）

来源：`script.md`（全文25场）、`characters.md`、`cards/`。只从剧本和人物卡提取；剧本没写、为了统一而补的设计都标了 **[设计补充]**。每条都注明场次和原文。

## 使用约定

- **统一画风**：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富。
- **360°全景**：2:1 等距柱状投影；画面中心=正面（layout.front），左右1/4=左/右，两端=背面并无缝衔接；无人物、无文字。
- **一致性流程**：每个场景先出第一个变体（通常是 -A）的全景并定稿，其余时间/天气变体用定稿全景做图生图参考，只改光线；四视角图同样以定稿全景为参考。
- **文字**：招牌、屏幕、本子、刺绣、船名等一律不让AI画字，后期贴字。
- **人脸**：服装提示词只写衣服，脸按 `cards/*_card1.jpg`，不重新设计。

## 统计

| 类别 | 数量 |
|---|---|
| 场景（含子区域） | 33 |
| 场景时间/天气变体（=360全景提示词） | 74 |
| 四视角提示词 | 296 |
| 道具 | 99 |
| 服装造型 | 33 |
| 造型变体（湿/伤/脏等） | 18 |
| 无卡配角/群演 | 13 |
| 界面UI/画面设计 | 31 |
| 母题符号 | 16 |
| 招牌/文字元素 | 13 |
| 交通工具（含于道具） | 8 |
| 动物 | 2 |
| 天气/特效 | 16 |
| 声音/音乐要点 | 32 |

## 一、场景

### S01 澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔）

*Chenggang harbor town establishing view (arcade-house streets, laundry poles, sloping lanes, old lighthouse in distance)*

- **使用场次**：第1、6、24、25场
- **原文出处**：第1场：「晨光照在澄港的骑楼、晾衣竿、坡道和远处的老灯塔上。海鸥飞过，渔船回港。」；第6场：「画面二：知遥站在澄港坡道上，四周的人头顶都飘着弹幕」；第24场：「最后慢慢拉远到整个澄港和那座灯塔」；设定（第三~六节）：「美术基调：虚构的南方海港城市“澄港”，有骑楼、坡道、渔港、老灯塔防波堤」
- **空间描述**：站在半山坡道中段的石板坡道上俯瞰：两侧是两三层的南方骑楼，拱廊下是店铺，楼上窗外伸出晾衣竿；坡道向下通往港口，远处海湾里伸出一条灰白防波堤，尽头是红白相间的老灯塔。
- **布局**：
  - 正面：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔
  - 右：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽
  - 背面：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶[设计补充]
  - 左：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿
  - 顶：开阔天空，海鸥
  - 地：磨旧的石板坡道，路边排水沟
- **色调**：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿　**氛围**：安静、生活气、被晨光洗过
- 注：坡道朝向、街区布局为[设计补充]；剧本只给出元素：骑楼、晾衣竿、坡道、老灯塔、海鸥、渔船。
- 注：已有参考：locations/sheet_澄港清晨街景.jpg（多张不一致，建议以本条全景重做）。

**S01-A｜清晨金色晨光（9月1日）**（第1场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），清晨金色斜射晨光，暖金色空气透视，薄雾，海面平静。站在半山坡道中段的石板坡道上俯瞰：两侧是两三层的南方骑楼，拱廊下是店铺，楼上窗外伸出晾衣竿；坡道向下通往港口，远处海湾里伸出一条灰白防波堤，尽头是红白相间的老灯塔。 正面：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；右侧：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；背面：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；左侧：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿；氛围：安静、生活气、被晨光洗过。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Chenggang harbor town establishing view (arcade-house streets, laundry poles, sloping lanes, old lighthouse in distance), early-morning golden raking sunlight, warm golden aerial haze, light mist, calm sea. standing midway on a stone-paved slope lane looking down to the harbor: two- and three-storey southern Chinese arcade buildings (qilou) line both sides with shops under the arcades and bamboo laundry poles from upper windows; the lane descends to the harbor where a grey-white breakwater stretches into the bay ending in a red-and-white striped old lighthouse. Front: the lane slopes down to the harbor water, returning fishing boats, the distant breakwater and red-white lighthouse; right: matching arcade facade with tin awnings, AC units and potted plants; back: the lane climbs uphill toward older blocks and the hilltop where the school stands [design]; left: arcade facade: ground-floor arched shopfronts with blank signboards, upper wooden windows with laundry poles; above: open sky with seagulls; ground: worn stone-slab slope with a side gutter. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），清晨金色斜射晨光，暖金色空气透视，薄雾，海面平静。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；画面左边缘可见：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；画面右边缘可见：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），清晨金色斜射晨光，暖金色空气透视，薄雾，海面平静。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；画面左边缘可见：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；画面右边缘可见：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），清晨金色斜射晨光，暖金色空气透视，薄雾，海面平静。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；画面左边缘可见：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；画面右边缘可见：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），清晨金色斜射晨光，暖金色空气透视，薄雾，海面平静。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；画面左边缘可见：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；画面右边缘可见：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S01-B｜白天（OP画面二）**（第6场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），晴朗白天，明亮高调，略带夸张的动画色彩。站在半山坡道中段的石板坡道上俯瞰：两侧是两三层的南方骑楼，拱廊下是店铺，楼上窗外伸出晾衣竿；坡道向下通往港口，远处海湾里伸出一条灰白防波堤，尽头是红白相间的老灯塔。 正面：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；右侧：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；背面：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；左侧：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿；氛围：安静、生活气、被晨光洗过。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Chenggang harbor town establishing view (arcade-house streets, laundry poles, sloping lanes, old lighthouse in distance), clear bright daytime, high-key, slightly stylized anime colors. standing midway on a stone-paved slope lane looking down to the harbor: two- and three-storey southern Chinese arcade buildings (qilou) line both sides with shops under the arcades and bamboo laundry poles from upper windows; the lane descends to the harbor where a grey-white breakwater stretches into the bay ending in a red-and-white striped old lighthouse. Front: the lane slopes down to the harbor water, returning fishing boats, the distant breakwater and red-white lighthouse; right: matching arcade facade with tin awnings, AC units and potted plants; back: the lane climbs uphill toward older blocks and the hilltop where the school stands [design]; left: arcade facade: ground-floor arched shopfronts with blank signboards, upper wooden windows with laundry poles; above: open sky with seagulls; ground: worn stone-slab slope with a side gutter. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），晴朗白天，明亮高调，略带夸张的动画色彩。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；画面左边缘可见：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；画面右边缘可见：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），晴朗白天，明亮高调，略带夸张的动画色彩。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；画面左边缘可见：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；画面右边缘可见：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），晴朗白天，明亮高调，略带夸张的动画色彩。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；画面左边缘可见：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；画面右边缘可见：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），晴朗白天，明亮高调，略带夸张的动画色彩。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；画面左边缘可见：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；画面右边缘可见：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S01-C｜台风后傍晚晚霞（一个月后）**（第24场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），台风过后天空洗过一样干净，满天晚霞铺满海面，灯塔安静地亮着。站在半山坡道中段的石板坡道上俯瞰：两侧是两三层的南方骑楼，拱廊下是店铺，楼上窗外伸出晾衣竿；坡道向下通往港口，远处海湾里伸出一条灰白防波堤，尽头是红白相间的老灯塔。 正面：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；右侧：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；背面：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；左侧：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿；氛围：安静、生活气、被晨光洗过。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Chenggang harbor town establishing view (arcade-house streets, laundry poles, sloping lanes, old lighthouse in distance), rain-washed clear sky after the typhoon, glowing sunset clouds over the whole sea, lighthouse lamp quietly lit. standing midway on a stone-paved slope lane looking down to the harbor: two- and three-storey southern Chinese arcade buildings (qilou) line both sides with shops under the arcades and bamboo laundry poles from upper windows; the lane descends to the harbor where a grey-white breakwater stretches into the bay ending in a red-and-white striped old lighthouse. Front: the lane slopes down to the harbor water, returning fishing boats, the distant breakwater and red-white lighthouse; right: matching arcade facade with tin awnings, AC units and potted plants; back: the lane climbs uphill toward older blocks and the hilltop where the school stands [design]; left: arcade facade: ground-floor arched shopfronts with blank signboards, upper wooden windows with laundry poles; above: open sky with seagulls; ground: worn stone-slab slope with a side gutter. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），台风过后天空洗过一样干净，满天晚霞铺满海面，灯塔安静地亮着。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；画面左边缘可见：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；画面右边缘可见：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），台风过后天空洗过一样干净，满天晚霞铺满海面，灯塔安静地亮着。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；画面左边缘可见：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；画面右边缘可见：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），台风过后天空洗过一样干净，满天晚霞铺满海面，灯塔安静地亮着。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：骑楼立面：一楼拱廊店铺（招牌空白），二三楼木窗伸出晾衣竿；画面左边缘可见：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；画面右边缘可见：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港城市空镜（骑楼街区·晾衣竿·坡道·远眺老灯塔），台风过后天空洗过一样干净，满天晚霞铺满海面，灯塔安静地亮着。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：同风格骑楼立面，有铁皮雨篷、空调外机、盆栽；画面左边缘可见：坡道向下延伸，尽头是港口海面、回港渔船和远处防波堤与红白老灯塔；画面右边缘可见：坡道向上，通往山坡上的旧街区和远处第七中学所在的坡顶；上方：开阔天空，海鸥；地面：磨旧的石板坡道，路边排水沟。色调：暖金、奶油白骑楼墙、赭红瓦、海面蓝绿。布局与360°全景 S01-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S02 夏记面馆一楼·堂食区（含收银台、墙上旧照片）

*Xia Ji Noodle Shop ground floor dining room (cashier counter, old photo on wall)*

- **使用场次**：第2、9、11、20、21场
- **原文出处**：第2场：「面馆一楼，蒸汽腾腾……夏红梅在收银台后用围裙擦手，一边接电话订货。」；第2场：「墙上挂着一张旧照片：一个皮肤黝黑的男人站在一条小渔船船头」；第9场：「打烊后的面馆，卷帘门拉下一半。」；第11场：「晚饭高峰，面馆坐满了人……收银台上方的面馆监控红灯亮着。」；第11场：「三号桌加个蛋」；第20场：「面馆里，外婆举着手机给每个食客看」；第21场：「厕所门开着，没人。面馆后门虚掩着」
- **空间描述**：骑楼一楼的老面馆，临街一面是可拉下的卷帘门和玻璃门；堂内七八张木方桌配木凳；收银台在左侧靠门，台上方装旧监控；后墙是通往后厨的门帘口和传菜窗；右墙挂着「海生号」旧照片和菜单板；左后角是上二楼的木楼梯；右后角是厕所小门。
- **布局**：
  - 正面：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌[文字后期]
  - 右：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架
  - 背面：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门
  - 左：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼
  - 顶：木梁吊顶，三四盏暖黄吊灯，吊扇
  - 地：旧水磨石地面，木方桌与长凳
- **色调**：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀　**氛围**：烟火气、蒸汽、热闹又亲切
- 注：布局（收银台左、楼梯左后、厕所右后、照片右墙）为[设计补充]；剧本只确认：收银台、监控在收银台上方、墙上旧照片、卷帘门、厕所、后门、三号桌。
- 注：已有参考 locations/sheet_夏记面馆一楼.jpg 各镜布局不一致，正是需要统一的原因。

**S02-A｜清晨开张（9月1日 6:40）**（第2场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨，暖黄灯与门外晨光混合，后厨飘出的蒸汽在光里呈颗粒感。骑楼一楼的老面馆，临街一面是可拉下的卷帘门和玻璃门；堂内七八张木方桌配木凳；收银台在左侧靠门，台上方装旧监控；后墙是通往后厨的门帘口和传菜窗；右墙挂着「海生号」旧照片和菜单板；左后角是上二楼的木楼梯；右后角是厕所小门。 正面：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；右侧：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；背面：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；左侧：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀；氛围：烟火气、蒸汽、热闹又亲切。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop ground floor dining room (cashier counter, old photo on wall), early morning, warm tungsten lamps mixed with dawn light from the door, kitchen steam drifting with visible grain. an old noodle shop on the ground floor of an arcade house; street side has a roll-up shutter and glass door; seven or eight square wooden tables with stools; wooden cashier counter on the left near the entrance with an old CCTV camera above it; back wall has a curtained doorway and pass-through window to the kitchen; right wall holds a framed old photo of a fisherman on a small boat and a blank menu board; a wooden staircase to the second floor in the back-left corner; a small toilet door in the back-right corner. Front: street frontage: glass door under a roll-up shutter, arcade and street beyond, blank wooden signboard by the door (text in post); right: right wall: framed old photo of the father and little girl on the boat bow, blank menu board, condiment shelf; back: back wall: blue cloth-curtained doorway and stainless pass-through window into the kitchen, wall clock above; toilet door in back-right corner; left: left wall: wooden cashier counter with landline phone, calculator, cash box; old CCTV camera with red LED high above it; wooden staircase up in back-left corner; above: wooden beam ceiling, three or four warm pendant lamps, a ceiling fan; ground: old terrazzo floor, square wooden tables and benches. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨，暖黄灯与门外晨光混合，后厨飘出的蒸汽在光里呈颗粒感。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面左边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面右边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨，暖黄灯与门外晨光混合，后厨飘出的蒸汽在光里呈颗粒感。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面左边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面右边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨，暖黄灯与门外晨光混合，后厨飘出的蒸汽在光里呈颗粒感。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面左边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面右边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨，暖黄灯与门外晨光混合，后厨飘出的蒸汽在光里呈颗粒感。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面左边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面右边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S02-B｜打烊夜（卷帘门半拉）**（第9场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），打烊后夜晚，卷帘门拉下一半，只留两盏灯，桌上倒扣凳子。骑楼一楼的老面馆，临街一面是可拉下的卷帘门和玻璃门；堂内七八张木方桌配木凳；收银台在左侧靠门，台上方装旧监控；后墙是通往后厨的门帘口和传菜窗；右墙挂着「海生号」旧照片和菜单板；左后角是上二楼的木楼梯；右后角是厕所小门。 正面：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；右侧：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；背面：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；左侧：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀；氛围：烟火气、蒸汽、热闹又亲切。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop ground floor dining room (cashier counter, old photo on wall), night after closing, roll-up shutter half down, only two lamps on, stools upturned on tables. an old noodle shop on the ground floor of an arcade house; street side has a roll-up shutter and glass door; seven or eight square wooden tables with stools; wooden cashier counter on the left near the entrance with an old CCTV camera above it; back wall has a curtained doorway and pass-through window to the kitchen; right wall holds a framed old photo of a fisherman on a small boat and a blank menu board; a wooden staircase to the second floor in the back-left corner; a small toilet door in the back-right corner. Front: street frontage: glass door under a roll-up shutter, arcade and street beyond, blank wooden signboard by the door (text in post); right: right wall: framed old photo of the father and little girl on the boat bow, blank menu board, condiment shelf; back: back wall: blue cloth-curtained doorway and stainless pass-through window into the kitchen, wall clock above; toilet door in back-right corner; left: left wall: wooden cashier counter with landline phone, calculator, cash box; old CCTV camera with red LED high above it; wooden staircase up in back-left corner; above: wooden beam ceiling, three or four warm pendant lamps, a ceiling fan; ground: old terrazzo floor, square wooden tables and benches. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），打烊后夜晚，卷帘门拉下一半，只留两盏灯，桌上倒扣凳子。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面左边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面右边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），打烊后夜晚，卷帘门拉下一半，只留两盏灯，桌上倒扣凳子。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面左边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面右边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），打烊后夜晚，卷帘门拉下一半，只留两盏灯，桌上倒扣凳子。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面左边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面右边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），打烊后夜晚，卷帘门拉下一半，只留两盏灯，桌上倒扣凳子。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面左边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面右边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S02-C｜晚饭高峰（夜 7:00）**（第11、20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），晚饭高峰，全部吊灯亮起，热气蒸腾，门外骑楼路灯。骑楼一楼的老面馆，临街一面是可拉下的卷帘门和玻璃门；堂内七八张木方桌配木凳；收银台在左侧靠门，台上方装旧监控；后墙是通往后厨的门帘口和传菜窗；右墙挂着「海生号」旧照片和菜单板；左后角是上二楼的木楼梯；右后角是厕所小门。 正面：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；右侧：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；背面：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；左侧：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀；氛围：烟火气、蒸汽、热闹又亲切。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop ground floor dining room (cashier counter, old photo on wall), dinner rush, all pendant lamps on, rising steam, arcade street lamps outside. an old noodle shop on the ground floor of an arcade house; street side has a roll-up shutter and glass door; seven or eight square wooden tables with stools; wooden cashier counter on the left near the entrance with an old CCTV camera above it; back wall has a curtained doorway and pass-through window to the kitchen; right wall holds a framed old photo of a fisherman on a small boat and a blank menu board; a wooden staircase to the second floor in the back-left corner; a small toilet door in the back-right corner. Front: street frontage: glass door under a roll-up shutter, arcade and street beyond, blank wooden signboard by the door (text in post); right: right wall: framed old photo of the father and little girl on the boat bow, blank menu board, condiment shelf; back: back wall: blue cloth-curtained doorway and stainless pass-through window into the kitchen, wall clock above; toilet door in back-right corner; left: left wall: wooden cashier counter with landline phone, calculator, cash box; old CCTV camera with red LED high above it; wooden staircase up in back-left corner; above: wooden beam ceiling, three or four warm pendant lamps, a ceiling fan; ground: old terrazzo floor, square wooden tables and benches. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），晚饭高峰，全部吊灯亮起，热气蒸腾，门外骑楼路灯。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面左边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面右边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），晚饭高峰，全部吊灯亮起，热气蒸腾，门外骑楼路灯。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面左边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面右边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），晚饭高峰，全部吊灯亮起，热气蒸腾，门外骑楼路灯。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面左边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面右边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），晚饭高峰，全部吊灯亮起，热气蒸腾，门外骑楼路灯。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面左边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面右边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S02-D｜清晨未开门（第16天）**（第20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨未营业，卷帘门关着，室内只亮后厨透出的光，偏冷灰。骑楼一楼的老面馆，临街一面是可拉下的卷帘门和玻璃门；堂内七八张木方桌配木凳；收银台在左侧靠门，台上方装旧监控；后墙是通往后厨的门帘口和传菜窗；右墙挂着「海生号」旧照片和菜单板；左后角是上二楼的木楼梯；右后角是厕所小门。 正面：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；右侧：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；背面：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；左侧：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀；氛围：烟火气、蒸汽、热闹又亲切。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop ground floor dining room (cashier counter, old photo on wall), early morning before opening, shutter closed, only light spilling from the kitchen, cool grey. an old noodle shop on the ground floor of an arcade house; street side has a roll-up shutter and glass door; seven or eight square wooden tables with stools; wooden cashier counter on the left near the entrance with an old CCTV camera above it; back wall has a curtained doorway and pass-through window to the kitchen; right wall holds a framed old photo of a fisherman on a small boat and a blank menu board; a wooden staircase to the second floor in the back-left corner; a small toilet door in the back-right corner. Front: street frontage: glass door under a roll-up shutter, arcade and street beyond, blank wooden signboard by the door (text in post); right: right wall: framed old photo of the father and little girl on the boat bow, blank menu board, condiment shelf; back: back wall: blue cloth-curtained doorway and stainless pass-through window into the kitchen, wall clock above; toilet door in back-right corner; left: left wall: wooden cashier counter with landline phone, calculator, cash box; old CCTV camera with red LED high above it; wooden staircase up in back-left corner; above: wooden beam ceiling, three or four warm pendant lamps, a ceiling fan; ground: old terrazzo floor, square wooden tables and benches. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨未营业，卷帘门关着，室内只亮后厨透出的光，偏冷灰。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面左边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面右边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-D 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨未营业，卷帘门关着，室内只亮后厨透出的光，偏冷灰。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面左边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面右边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-D 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨未营业，卷帘门关着，室内只亮后厨透出的光，偏冷灰。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面左边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面右边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-D 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），清晨未营业，卷帘门关着，室内只亮后厨透出的光，偏冷灰。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面左边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面右边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-D 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S02-E｜台风夜（第17天）**（第21场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），台风夜，室内灯光昏黄，门外风雨猛烈，雨水从虚掩的后门灌进来，闪电时冷白闪光。骑楼一楼的老面馆，临街一面是可拉下的卷帘门和玻璃门；堂内七八张木方桌配木凳；收银台在左侧靠门，台上方装旧监控；后墙是通往后厨的门帘口和传菜窗；右墙挂着「海生号」旧照片和菜单板；左后角是上二楼的木楼梯；右后角是厕所小门。 正面：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；右侧：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；背面：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；左侧：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀；氛围：烟火气、蒸汽、热闹又亲切。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop ground floor dining room (cashier counter, old photo on wall), typhoon night, dim yellow interior, violent wind and rain outside, rain blowing in, occasional cold white lightning flashes. an old noodle shop on the ground floor of an arcade house; street side has a roll-up shutter and glass door; seven or eight square wooden tables with stools; wooden cashier counter on the left near the entrance with an old CCTV camera above it; back wall has a curtained doorway and pass-through window to the kitchen; right wall holds a framed old photo of a fisherman on a small boat and a blank menu board; a wooden staircase to the second floor in the back-left corner; a small toilet door in the back-right corner. Front: street frontage: glass door under a roll-up shutter, arcade and street beyond, blank wooden signboard by the door (text in post); right: right wall: framed old photo of the father and little girl on the boat bow, blank menu board, condiment shelf; back: back wall: blue cloth-curtained doorway and stainless pass-through window into the kitchen, wall clock above; toilet door in back-right corner; left: left wall: wooden cashier counter with landline phone, calculator, cash box; old CCTV camera with red LED high above it; wooden staircase up in back-left corner; above: wooden beam ceiling, three or four warm pendant lamps, a ceiling fan; ground: old terrazzo floor, square wooden tables and benches. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），台风夜，室内灯光昏黄，门外风雨猛烈，雨水从虚掩的后门灌进来，闪电时冷白闪光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面左边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面右边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-E 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），台风夜，室内灯光昏黄，门外风雨猛烈，雨水从虚掩的后门灌进来，闪电时冷白闪光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面左边缘可见：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面右边缘可见：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-E 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），台风夜，室内灯光昏黄，门外风雨猛烈，雨水从虚掩的后门灌进来，闪电时冷白闪光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左墙：木质收银台（电话、计算器、零钱盒），台上方墙角旧监控摄像头带红灯；左后角木楼梯上二楼；画面左边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；画面右边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-E 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·堂食区（含收银台、墙上旧照片），台风夜，室内灯光昏黄，门外风雨猛烈，雨水从虚掩的后门灌进来，闪电时冷白闪光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右墙：「海生号」船头父女旧照片相框、空白菜单板、调料架；画面左边缘可见：临街门面：玻璃门+上方卷帘门，门外是骑楼拱廊和街道，门边挂空白木招牌；画面右边缘可见：后墙：通往后厨的蓝布门帘口与不锈钢传菜窗，墙上挂钟；右后角厕所门；上方：木梁吊顶，三四盏暖黄吊灯，吊扇；地面：旧水磨石地面，木方桌与长凳。色调：暖黄钨丝灯、深木色、奶油墙、深蓝门帘、红色点缀。布局与360°全景 S02-E 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S03 夏记面馆一楼·后厨

*Xia Ji Noodle Shop kitchen*

- **使用场次**：第2、9、11、20、25场
- **原文出处**：第2场：「外婆单手颠勺……夏红梅擦手的动作停了一下，转身进了后厨。」；第9场：「外婆在后厨揉面，知遥坐在小板凳上剥虾。」；第11场：「油锅烧得滋滋响。旁边的燃气灶上，一口汤锅的锅柄斜伸出灶台边缘……灶台边的抹布垂下来」；第11场：「后厨通往后巷的那扇小窗」；第20场：「夏红梅在后厨熬汤」；第25场：「深夜，面馆后厨。外婆一个人在洗碗……墙上挂着一张很旧的黑白照片」
- **空间描述**：狭长后厨：正面一排燃气灶台（大炒锅、油锅、汤锅），灶台上方是排烟罩；左墙是揉面大案板和面粉袋；右墙是水池和碗架；灶台旁墙上一扇小窗朝向后巷，窗边是通往后巷的后门；墙上挂钟；水池上方挂黑白老照片。
- **布局**：
  - 正面：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟
  - 右：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷
  - 背面：通往堂食区的蓝布门帘口与传菜窗
  - 左：揉面大木案板、面粉袋、湿布、小板凳、面条架
  - 顶：一盏顶灯形成光柱，油烟熏黄的天花
  - 地：防滑瓷砖地面，排水地漏
- **色调**：暖黄顶光、不锈钢冷灰、面粉白、木色　**氛围**：热、忙、蒸汽与面粉在光柱里飘
- 注：后门与后厨的位置关系为[设计补充]：剧本第11场“推开后门冲进后巷”与第21场“面馆后门虚掩……门口的挂钩上”合并为同一扇后门。
- 注：黑白照片挂在后厨为剧本原文（第25场）；位置在水池上方为[设计补充]。

**S03-A｜清晨开火**（第2、20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，清晨，灶火与蒸汽，暖色顶光。狭长后厨：正面一排燃气灶台（大炒锅、油锅、汤锅），灶台上方是排烟罩；左墙是揉面大案板和面粉袋；右墙是水池和碗架；灶台旁墙上一扇小窗朝向后巷，窗边是通往后巷的后门；墙上挂钟；水池上方挂黑白老照片。 正面：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；右侧：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；背面：通往堂食区的蓝布门帘口与传菜窗；左侧：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色；氛围：热、忙、蒸汽与面粉在光柱里飘。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop kitchen, early morning, burner flames and steam, warm top light. a narrow noodle-shop kitchen: a row of gas burners with a big wok, a deep-fry pot and a soup pot under a range hood straight ahead; a large wooden kneading table and flour sacks on the left; a deep sink and dish rack on the right; beside the stove a small window looks onto the back alley next to the back door; a wall clock; an old black-and-white photo hangs above the sink. Front: row of gas burners with wok, fryer and soup pot under a stainless range hood; small window to the back alley on the right of the stove; wall clock; right: deep sink, dish rack, hanging ladles and spatulas; an old black-and-white photo above the sink; back door (wooden, with a coat hook inside) in the front-right corner leading to the back alley; back: blue cloth-curtained doorway and pass-through window back to the dining room; left: large wooden kneading table, flour sacks, damp cloth, a small stool, noodle drying rack; above: single overhead lamp forming a light shaft, smoke-yellowed ceiling; ground: non-slip tiled floor with a drain. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，清晨，灶火与蒸汽，暖色顶光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面左边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面右边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，清晨，灶火与蒸汽，暖色顶光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往堂食区的蓝布门帘口与传菜窗；画面左边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面右边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，清晨，灶火与蒸汽，暖色顶光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面左边缘可见：通往堂食区的蓝布门帘口与传菜窗；画面右边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，清晨，灶火与蒸汽，暖色顶光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面左边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面右边缘可见：通往堂食区的蓝布门帘口与传菜窗；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S03-B｜打烊夜·揉面**（第9场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，夜，暖色顶光一束，面粉在光柱里飘。狭长后厨：正面一排燃气灶台（大炒锅、油锅、汤锅），灶台上方是排烟罩；左墙是揉面大案板和面粉袋；右墙是水池和碗架；灶台旁墙上一扇小窗朝向后巷，窗边是通往后巷的后门；墙上挂钟；水池上方挂黑白老照片。 正面：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；右侧：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；背面：通往堂食区的蓝布门帘口与传菜窗；左侧：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色；氛围：热、忙、蒸汽与面粉在光柱里飘。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop kitchen, night, a single warm top light beam with flour dust floating in it. a narrow noodle-shop kitchen: a row of gas burners with a big wok, a deep-fry pot and a soup pot under a range hood straight ahead; a large wooden kneading table and flour sacks on the left; a deep sink and dish rack on the right; beside the stove a small window looks onto the back alley next to the back door; a wall clock; an old black-and-white photo hangs above the sink. Front: row of gas burners with wok, fryer and soup pot under a stainless range hood; small window to the back alley on the right of the stove; wall clock; right: deep sink, dish rack, hanging ladles and spatulas; an old black-and-white photo above the sink; back door (wooden, with a coat hook inside) in the front-right corner leading to the back alley; back: blue cloth-curtained doorway and pass-through window back to the dining room; left: large wooden kneading table, flour sacks, damp cloth, a small stool, noodle drying rack; above: single overhead lamp forming a light shaft, smoke-yellowed ceiling; ground: non-slip tiled floor with a drain. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，夜，暖色顶光一束，面粉在光柱里飘。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面左边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面右边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，夜，暖色顶光一束，面粉在光柱里飘。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往堂食区的蓝布门帘口与传菜窗；画面左边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面右边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，夜，暖色顶光一束，面粉在光柱里飘。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面左边缘可见：通往堂食区的蓝布门帘口与传菜窗；画面右边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，夜，暖色顶光一束，面粉在光柱里飘。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面左边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面右边缘可见：通往堂食区的蓝布门帘口与传菜窗；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S03-C｜晚高峰·油锅（倒计时）**（第11场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，晚饭高峰，油锅滋滋冒泡，火苗跳动，紧张的暖橙光。狭长后厨：正面一排燃气灶台（大炒锅、油锅、汤锅），灶台上方是排烟罩；左墙是揉面大案板和面粉袋；右墙是水池和碗架；灶台旁墙上一扇小窗朝向后巷，窗边是通往后巷的后门；墙上挂钟；水池上方挂黑白老照片。 正面：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；右侧：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；背面：通往堂食区的蓝布门帘口与传菜窗；左侧：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色；氛围：热、忙、蒸汽与面粉在光柱里飘。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop kitchen, dinner rush, oil pot sizzling, burner flames flickering, tense warm-orange light. a narrow noodle-shop kitchen: a row of gas burners with a big wok, a deep-fry pot and a soup pot under a range hood straight ahead; a large wooden kneading table and flour sacks on the left; a deep sink and dish rack on the right; beside the stove a small window looks onto the back alley next to the back door; a wall clock; an old black-and-white photo hangs above the sink. Front: row of gas burners with wok, fryer and soup pot under a stainless range hood; small window to the back alley on the right of the stove; wall clock; right: deep sink, dish rack, hanging ladles and spatulas; an old black-and-white photo above the sink; back door (wooden, with a coat hook inside) in the front-right corner leading to the back alley; back: blue cloth-curtained doorway and pass-through window back to the dining room; left: large wooden kneading table, flour sacks, damp cloth, a small stool, noodle drying rack; above: single overhead lamp forming a light shaft, smoke-yellowed ceiling; ground: non-slip tiled floor with a drain. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，晚饭高峰，油锅滋滋冒泡，火苗跳动，紧张的暖橙光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面左边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面右边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，晚饭高峰，油锅滋滋冒泡，火苗跳动，紧张的暖橙光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往堂食区的蓝布门帘口与传菜窗；画面左边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面右边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，晚饭高峰，油锅滋滋冒泡，火苗跳动，紧张的暖橙光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面左边缘可见：通往堂食区的蓝布门帘口与传菜窗；画面右边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，晚饭高峰，油锅滋滋冒泡，火苗跳动，紧张的暖橙光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面左边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面右边缘可见：通往堂食区的蓝布门帘口与传菜窗；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S03-D｜深夜彩蛋·洗碗**（第25场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，深夜，只亮水池上方一盏灯，安静温柔。狭长后厨：正面一排燃气灶台（大炒锅、油锅、汤锅），灶台上方是排烟罩；左墙是揉面大案板和面粉袋；右墙是水池和碗架；灶台旁墙上一扇小窗朝向后巷，窗边是通往后巷的后门；墙上挂钟；水池上方挂黑白老照片。 正面：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；右侧：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；背面：通往堂食区的蓝布门帘口与传菜窗；左侧：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色；氛围：热、忙、蒸汽与面粉在光柱里飘。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia Ji Noodle Shop kitchen, late night, only one lamp over the sink, quiet and tender. a narrow noodle-shop kitchen: a row of gas burners with a big wok, a deep-fry pot and a soup pot under a range hood straight ahead; a large wooden kneading table and flour sacks on the left; a deep sink and dish rack on the right; beside the stove a small window looks onto the back alley next to the back door; a wall clock; an old black-and-white photo hangs above the sink. Front: row of gas burners with wok, fryer and soup pot under a stainless range hood; small window to the back alley on the right of the stove; wall clock; right: deep sink, dish rack, hanging ladles and spatulas; an old black-and-white photo above the sink; back door (wooden, with a coat hook inside) in the front-right corner leading to the back alley; back: blue cloth-curtained doorway and pass-through window back to the dining room; left: large wooden kneading table, flour sacks, damp cloth, a small stool, noodle drying rack; above: single overhead lamp forming a light shaft, smoke-yellowed ceiling; ground: non-slip tiled floor with a drain. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，深夜，只亮水池上方一盏灯，安静温柔。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面左边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面右边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-D 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，深夜，只亮水池上方一盏灯，安静温柔。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往堂食区的蓝布门帘口与传菜窗；画面左边缘可见：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面右边缘可见：揉面大木案板、面粉袋、湿布、小板凳、面条架；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-D 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，深夜，只亮水池上方一盏灯，安静温柔。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：揉面大木案板、面粉袋、湿布、小板凳、面条架；画面左边缘可见：通往堂食区的蓝布门帘口与传菜窗；画面右边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-D 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆一楼·后厨，深夜，只亮水池上方一盏灯，安静温柔。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：深水池、碗架、挂勺挂铲；水池上方挂一张旧黑白照片；右前角后门（木门，门内侧挂钩）通后巷；画面左边缘可见：燃气灶台一排（炒锅、油锅、汤锅）与不锈钢排烟罩，灶台右侧墙上小窗朝后巷，墙上挂钟；画面右边缘可见：通往堂食区的蓝布门帘口与传菜窗；上方：一盏顶灯形成光柱，油烟熏黄的天花；地面：防滑瓷砖地面，排水地漏。色调：暖黄顶光、不锈钢冷灰、面粉白、木色。布局与360°全景 S03-D 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S04 面馆后门外·后巷

*Back alley behind the noodle shop*

- **使用场次**：第11、21场
- **原文出处**：第11场：「窗外的后巷里，昏黄路灯下，周砚正站在那里，手里拎着一个红色的灭火器」；第11场：「后巷里起了风，吹得路灯晃了一下。」；第21场：「面馆后门虚掩着，风雨灌进来，门口的挂钩上，那件明黄色的小雨衣不见了」
- **空间描述**：面馆后门外一条窄后巷：一侧是面馆后墙（后门+后厨小窗），另一侧是邻楼后墙，墙上一盏会晃的昏黄路灯；巷子一头通往门口街道，一头通往去海边的坡道。
- **布局**：
  - 正面：面馆后墙：木后门与亮着暖光的后厨小窗
  - 右：巷子通向往海边的下坡，远处黑暗
  - 背面：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱
  - 左：巷子通向门口街道方向，远处有骑楼灯光
  - 顶：两楼之间一线夜空，晾衣绳
  - 地：湿滑水泥地，排水沟
- **色调**：昏黄路灯、暗蓝阴影、窗内暖光　**氛围**：静、悬疑、门神般的守候
- 注：巷子两端去向为[设计补充]。

**S04-A｜夜·昏黄路灯**（第11场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，夜晚，昏黄路灯，起风时灯影晃动。面馆后门外一条窄后巷：一侧是面馆后墙（后门+后厨小窗），另一侧是邻楼后墙，墙上一盏会晃的昏黄路灯；巷子一头通往门口街道，一头通往去海边的坡道。 正面：面馆后墙：木后门与亮着暖光的后厨小窗；右侧：巷子通向往海边的下坡，远处黑暗；背面：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；左侧：巷子通向门口街道方向，远处有骑楼灯光；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光；氛围：静、悬疑、门神般的守候。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Back alley behind the noodle shop, night, dim yellow street lamp, light swaying in the wind. a narrow back alley behind the noodle shop: one side is the shop's back wall with the back door and the small kitchen window, the other side is the neighbouring building's back wall with a swaying dim yellow lamp; one end leads to the front street, the other to the slope down to the sea. Front: the shop's back wall: wooden back door and the small warm-lit kitchen window; right: alley leading to the downhill slope toward the sea, darkness beyond; back: neighbouring building's back wall with a dim yellow wall lamp, clutter and foam boxes at the base; left: alley leading toward the front street, distant arcade lights; above: a strip of night sky between buildings, laundry lines; ground: damp concrete ground with a gutter. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，夜晚，昏黄路灯，起风时灯影晃动。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：面馆后墙：木后门与亮着暖光的后厨小窗；画面左边缘可见：巷子通向门口街道方向，远处有骑楼灯光；画面右边缘可见：巷子通向往海边的下坡，远处黑暗；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，夜晚，昏黄路灯，起风时灯影晃动。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；画面左边缘可见：巷子通向往海边的下坡，远处黑暗；画面右边缘可见：巷子通向门口街道方向，远处有骑楼灯光；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，夜晚，昏黄路灯，起风时灯影晃动。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：巷子通向门口街道方向，远处有骑楼灯光；画面左边缘可见：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；画面右边缘可见：面馆后墙：木后门与亮着暖光的后厨小窗；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，夜晚，昏黄路灯，起风时灯影晃动。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：巷子通向往海边的下坡，远处黑暗；画面左边缘可见：面馆后墙：木后门与亮着暖光的后厨小窗；画面右边缘可见：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S04-B｜台风夜·风雨灌入后门（从门内看）**（第21场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，台风夜，暴雨横扫，后门虚掩，风雨灌入，门内侧挂钩空着。面馆后门外一条窄后巷：一侧是面馆后墙（后门+后厨小窗），另一侧是邻楼后墙，墙上一盏会晃的昏黄路灯；巷子一头通往门口街道，一头通往去海边的坡道。 正面：面馆后墙：木后门与亮着暖光的后厨小窗；右侧：巷子通向往海边的下坡，远处黑暗；背面：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；左侧：巷子通向门口街道方向，远处有骑楼灯光；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光；氛围：静、悬疑、门神般的守候。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Back alley behind the noodle shop, typhoon night, sideways rain, back door ajar, wind and rain blowing in, the inner hook empty. a narrow back alley behind the noodle shop: one side is the shop's back wall with the back door and the small kitchen window, the other side is the neighbouring building's back wall with a swaying dim yellow lamp; one end leads to the front street, the other to the slope down to the sea. Front: the shop's back wall: wooden back door and the small warm-lit kitchen window; right: alley leading to the downhill slope toward the sea, darkness beyond; back: neighbouring building's back wall with a dim yellow wall lamp, clutter and foam boxes at the base; left: alley leading toward the front street, distant arcade lights; above: a strip of night sky between buildings, laundry lines; ground: damp concrete ground with a gutter. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，台风夜，暴雨横扫，后门虚掩，风雨灌入，门内侧挂钩空着。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：面馆后墙：木后门与亮着暖光的后厨小窗；画面左边缘可见：巷子通向门口街道方向，远处有骑楼灯光；画面右边缘可见：巷子通向往海边的下坡，远处黑暗；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，台风夜，暴雨横扫，后门虚掩，风雨灌入，门内侧挂钩空着。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；画面左边缘可见：巷子通向往海边的下坡，远处黑暗；画面右边缘可见：巷子通向门口街道方向，远处有骑楼灯光；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，台风夜，暴雨横扫，后门虚掩，风雨灌入，门内侧挂钩空着。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：巷子通向门口街道方向，远处有骑楼灯光；画面左边缘可见：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；画面右边缘可见：面馆后墙：木后门与亮着暖光的后厨小窗；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，面馆后门外·后巷，台风夜，暴雨横扫，后门虚掩，风雨灌入，门内侧挂钩空着。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：巷子通向往海边的下坡，远处黑暗；画面左边缘可见：面馆后墙：木后门与亮着暖光的后厨小窗；画面右边缘可见：邻楼后墙，墙上挂一盏昏黄路灯，墙根堆着杂物、泡沫箱；上方：两楼之间一线夜空，晾衣绳；地面：湿滑水泥地，排水沟。色调：昏黄路灯、暗蓝阴影、窗内暖光。布局与360°全景 S04-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S05 夏记面馆门口街道（骑楼街·对面老楼）

*Street in front of Xia Ji Noodle Shop (arcade street, old apartment building opposite)*

- **使用场次**：第2、21、25场
- **原文出处**：第2场：「一辆小货车停在对面老楼门口，搬家工人搬下纸箱。」；第2场：「两个街坊阿姨挎着菜篮，在面馆门口压低声音。」；第21场：「骑楼的铁皮招牌被吹得哐哐响。」；第21场：「夏红梅推着电动车冲进雨里」；第25场：「外婆在面馆门口跳广场舞」
- **空间描述**：骑楼街道：一侧是夏记面馆门面（骑楼拱廊下，木招牌），对面是一栋旧居民老楼（周砚家楼，楼梯口在一楼），街道不宽，可停小货车。
- **布局**：
  - 正面：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口[设计补充]
  - 右：街道延伸向港口方向，可见一线海
  - 背面：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌
  - 左：街道延伸向坡顶，两侧骑楼
  - 顶：骑楼屋檐之间的天空
  - 地：沥青路面与骑楼下的花砖人行道
- **色调**：暖米黄骑楼、赭红、清晨淡金　**氛围**：街坊气、有人看见有人没看见
- 注：剧本第2场说“对面老楼”，第5场说“隔壁楼二层的窗口……隔着一条窄巷”，人物小传说“隔壁老楼”。本条设定：周砚家楼位于面馆斜对面，两楼侧面隔一条窄巷，两家二楼窗口相对（见S11）。需用户确认。

**S05-A｜清晨（9月1日）**（第2场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），清晨柔和晨光，街坊来往。骑楼街道：一侧是夏记面馆门面（骑楼拱廊下，木招牌），对面是一栋旧居民老楼（周砚家楼，楼梯口在一楼），街道不宽，可停小货车。 正面：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；右侧：街道延伸向港口方向，可见一线海；背面：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；左侧：街道延伸向坡顶，两侧骑楼；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金；氛围：街坊气、有人看见有人没看见。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Street in front of Xia Ji Noodle Shop (arcade street, old apartment building opposite), soft early morning light. an arcade-lined street: on one side the Xia Ji noodle shop frontage under the arcade with a wooden signboard; across the street an old residential building with a ground-floor stairwell entrance (Zhou Yan's building); the street is narrow but fits a small truck. Front: the old four-storey apartment building opposite, stairwell entrance on the ground floor, second-floor windows [design]; right: street running toward the harbor, a sliver of sea visible; back: the noodle shop frontage: arcade arches, glass door with roll-up shutter, blank wooden signboard (text 'Xia Ji' added in post), tin sign by the door; left: street running uphill, arcades on both sides; above: sky between arcade eaves; ground: asphalt road and patterned-tile arcade sidewalk. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），清晨柔和晨光，街坊来往。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；画面左边缘可见：街道延伸向坡顶，两侧骑楼；画面右边缘可见：街道延伸向港口方向，可见一线海；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），清晨柔和晨光，街坊来往。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；画面左边缘可见：街道延伸向港口方向，可见一线海；画面右边缘可见：街道延伸向坡顶，两侧骑楼；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），清晨柔和晨光，街坊来往。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：街道延伸向坡顶，两侧骑楼；画面左边缘可见：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；画面右边缘可见：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），清晨柔和晨光，街坊来往。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：街道延伸向港口方向，可见一线海；画面左边缘可见：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；画面右边缘可见：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S05-B｜台风夜**（第21场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），台风夜，狂风暴雨，铁皮招牌被吹得乱响，路灯在雨中模糊，闪电。骑楼街道：一侧是夏记面馆门面（骑楼拱廊下，木招牌），对面是一栋旧居民老楼（周砚家楼，楼梯口在一楼），街道不宽，可停小货车。 正面：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；右侧：街道延伸向港口方向，可见一线海；背面：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；左侧：街道延伸向坡顶，两侧骑楼；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金；氛围：街坊气、有人看见有人没看见。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Street in front of Xia Ji Noodle Shop (arcade street, old apartment building opposite), typhoon night, violent wind and rain, tin signs rattling, street lamps blurred by rain, lightning. an arcade-lined street: on one side the Xia Ji noodle shop frontage under the arcade with a wooden signboard; across the street an old residential building with a ground-floor stairwell entrance (Zhou Yan's building); the street is narrow but fits a small truck. Front: the old four-storey apartment building opposite, stairwell entrance on the ground floor, second-floor windows [design]; right: street running toward the harbor, a sliver of sea visible; back: the noodle shop frontage: arcade arches, glass door with roll-up shutter, blank wooden signboard (text 'Xia Ji' added in post), tin sign by the door; left: street running uphill, arcades on both sides; above: sky between arcade eaves; ground: asphalt road and patterned-tile arcade sidewalk. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），台风夜，狂风暴雨，铁皮招牌被吹得乱响，路灯在雨中模糊，闪电。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；画面左边缘可见：街道延伸向坡顶，两侧骑楼；画面右边缘可见：街道延伸向港口方向，可见一线海；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），台风夜，狂风暴雨，铁皮招牌被吹得乱响，路灯在雨中模糊，闪电。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；画面左边缘可见：街道延伸向港口方向，可见一线海；画面右边缘可见：街道延伸向坡顶，两侧骑楼；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），台风夜，狂风暴雨，铁皮招牌被吹得乱响，路灯在雨中模糊，闪电。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：街道延伸向坡顶，两侧骑楼；画面左边缘可见：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；画面右边缘可见：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），台风夜，狂风暴雨，铁皮招牌被吹得乱响，路灯在雨中模糊，闪电。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：街道延伸向港口方向，可见一线海；画面左边缘可见：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；画面右边缘可见：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S05-C｜片尾手绘静帧·白天**（第25场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），手绘插画风静帧，明亮白天，温暖。骑楼街道：一侧是夏记面馆门面（骑楼拱廊下，木招牌），对面是一栋旧居民老楼（周砚家楼，楼梯口在一楼），街道不宽，可停小货车。 正面：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；右侧：街道延伸向港口方向，可见一线海；背面：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；左侧：街道延伸向坡顶，两侧骑楼；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金；氛围：街坊气、有人看见有人没看见。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Street in front of Xia Ji Noodle Shop (arcade street, old apartment building opposite), hand-drawn illustration still, bright warm daytime. an arcade-lined street: on one side the Xia Ji noodle shop frontage under the arcade with a wooden signboard; across the street an old residential building with a ground-floor stairwell entrance (Zhou Yan's building); the street is narrow but fits a small truck. Front: the old four-storey apartment building opposite, stairwell entrance on the ground floor, second-floor windows [design]; right: street running toward the harbor, a sliver of sea visible; back: the noodle shop frontage: arcade arches, glass door with roll-up shutter, blank wooden signboard (text 'Xia Ji' added in post), tin sign by the door; left: street running uphill, arcades on both sides; above: sky between arcade eaves; ground: asphalt road and patterned-tile arcade sidewalk. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），手绘插画风静帧，明亮白天，温暖。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；画面左边缘可见：街道延伸向坡顶，两侧骑楼；画面右边缘可见：街道延伸向港口方向，可见一线海；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），手绘插画风静帧，明亮白天，温暖。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；画面左边缘可见：街道延伸向港口方向，可见一线海；画面右边缘可见：街道延伸向坡顶，两侧骑楼；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），手绘插画风静帧，明亮白天，温暖。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：街道延伸向坡顶，两侧骑楼；画面左边缘可见：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；画面右边缘可见：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏记面馆门口街道（骑楼街·对面老楼），手绘插画风静帧，明亮白天，温暖。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：街道延伸向港口方向，可见一线海；画面左边缘可见：对面老楼：四层旧居民楼，一楼楼梯口，二楼窗口；画面右边缘可见：夏记面馆门面：骑楼拱廊、玻璃门与卷帘门、空白木招牌（「夏记」后期加字）、门边铁皮招牌；上方：骑楼屋檐之间的天空；地面：沥青路面与骑楼下的花砖人行道。色调：暖米黄骑楼、赭红、清晨淡金。布局与360°全景 S05-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S06 夏家楼梯（一楼面馆→二楼住家，拐角旧监控）

*Xia family staircase (shop to upstairs home, old CCTV on landing)*

- **使用场次**：第6、9、20、21场
- **原文出处**：第6场：「楼梯拐角的墙上装着一个面馆防盗用的旧监控摄像头，红灯一闪一闪。」；第9场：「夏红梅从楼梯上下来」；第20场：「外婆不知什么时候站在了楼梯口」；第21场：「外婆站在楼梯上，看着女儿呆立在门口的背影。」
- **空间描述**：窄木楼梯，从面馆堂食区左后角上到二楼，中间有一个拐角平台，平台墙角高处装着带红灯的旧监控；楼梯顶是二楼走廊（左通客厅，右通知遥卧室）。
- **布局**：
  - 正面：向上的楼梯段，通往二楼走廊和知遥卧室门
  - 右：木扶手与栏杆
  - 背面：向下的楼梯段，通往面馆堂食区，下方透出暖光
  - 左：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历[设计补充]
  - 顶：低矮天花，一盏小壁灯
  - 地：磨旧的木台阶
- **色调**：深木色、暗暖光、监控红点　**氛围**：窄、静、被注视
- 注：楼梯在堂食区左后角、二楼走廊两侧分别通客厅与卧室为[设计补充]。

**S06-A｜深夜（规则试探）**（第6场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），深夜，仅壁灯微光，监控红灯一闪一闪。窄木楼梯，从面馆堂食区左后角上到二楼，中间有一个拐角平台，平台墙角高处装着带红灯的旧监控；楼梯顶是二楼走廊（左通客厅，右通知遥卧室）。 正面：向上的楼梯段，通往二楼走廊和知遥卧室门；右侧：木扶手与栏杆；背面：向下的楼梯段，通往面馆堂食区，下方透出暖光；左侧：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点；氛围：窄、静、被注视。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family staircase (shop to upstairs home, old CCTV on landing), late night, faint wall lamp only, CCTV red LED blinking. a narrow wooden staircase rising from the back-left of the dining room to the second floor with a turning landing; an old CCTV camera with a blinking red LED is mounted high in the landing corner; top of the stairs opens to the upstairs hallway (living room to one side, Zhiyao's bedroom to the other). Front: stairs going up to the hallway and Zhiyao's bedroom door; right: wooden handrail and balusters; back: stairs going down to the dining room, warm light from below; left: landing wall: old CCTV camera high up with red LED, an old wall calendar [design]; above: low ceiling with a small wall lamp; ground: worn wooden steps. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），深夜，仅壁灯微光，监控红灯一闪一闪。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：向上的楼梯段，通往二楼走廊和知遥卧室门；画面左边缘可见：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；画面右边缘可见：木扶手与栏杆；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），深夜，仅壁灯微光，监控红灯一闪一闪。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：向下的楼梯段，通往面馆堂食区，下方透出暖光；画面左边缘可见：木扶手与栏杆；画面右边缘可见：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），深夜，仅壁灯微光，监控红灯一闪一闪。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；画面左边缘可见：向下的楼梯段，通往面馆堂食区，下方透出暖光；画面右边缘可见：向上的楼梯段，通往二楼走廊和知遥卧室门；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），深夜，仅壁灯微光，监控红灯一闪一闪。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：木扶手与栏杆；画面左边缘可见：向上的楼梯段，通往二楼走廊和知遥卧室门；画面右边缘可见：向下的楼梯段，通往面馆堂食区，下方透出暖光；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S06-B｜夜/清晨日常**（第9、20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），室内暖光，楼下面馆光线透上来。窄木楼梯，从面馆堂食区左后角上到二楼，中间有一个拐角平台，平台墙角高处装着带红灯的旧监控；楼梯顶是二楼走廊（左通客厅，右通知遥卧室）。 正面：向上的楼梯段，通往二楼走廊和知遥卧室门；右侧：木扶手与栏杆；背面：向下的楼梯段，通往面馆堂食区，下方透出暖光；左侧：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点；氛围：窄、静、被注视。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family staircase (shop to upstairs home, old CCTV on landing), warm interior light, glow from the shop below. a narrow wooden staircase rising from the back-left of the dining room to the second floor with a turning landing; an old CCTV camera with a blinking red LED is mounted high in the landing corner; top of the stairs opens to the upstairs hallway (living room to one side, Zhiyao's bedroom to the other). Front: stairs going up to the hallway and Zhiyao's bedroom door; right: wooden handrail and balusters; back: stairs going down to the dining room, warm light from below; left: landing wall: old CCTV camera high up with red LED, an old wall calendar [design]; above: low ceiling with a small wall lamp; ground: worn wooden steps. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），室内暖光，楼下面馆光线透上来。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：向上的楼梯段，通往二楼走廊和知遥卧室门；画面左边缘可见：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；画面右边缘可见：木扶手与栏杆；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），室内暖光，楼下面馆光线透上来。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：向下的楼梯段，通往面馆堂食区，下方透出暖光；画面左边缘可见：木扶手与栏杆；画面右边缘可见：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），室内暖光，楼下面馆光线透上来。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；画面左边缘可见：向下的楼梯段，通往面馆堂食区，下方透出暖光；画面右边缘可见：向上的楼梯段，通往二楼走廊和知遥卧室门；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），室内暖光，楼下面馆光线透上来。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：木扶手与栏杆；画面左边缘可见：向上的楼梯段，通往二楼走廊和知遥卧室门；画面右边缘可见：向下的楼梯段，通往面馆堂食区，下方透出暖光；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S06-C｜台风夜**（第21场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），台风夜，灯光昏黄，闪电从楼下门口透进冷光。窄木楼梯，从面馆堂食区左后角上到二楼，中间有一个拐角平台，平台墙角高处装着带红灯的旧监控；楼梯顶是二楼走廊（左通客厅，右通知遥卧室）。 正面：向上的楼梯段，通往二楼走廊和知遥卧室门；右侧：木扶手与栏杆；背面：向下的楼梯段，通往面馆堂食区，下方透出暖光；左侧：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点；氛围：窄、静、被注视。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family staircase (shop to upstairs home, old CCTV on landing), typhoon night, dim yellow light, cold lightning flashes from the doorway below. a narrow wooden staircase rising from the back-left of the dining room to the second floor with a turning landing; an old CCTV camera with a blinking red LED is mounted high in the landing corner; top of the stairs opens to the upstairs hallway (living room to one side, Zhiyao's bedroom to the other). Front: stairs going up to the hallway and Zhiyao's bedroom door; right: wooden handrail and balusters; back: stairs going down to the dining room, warm light from below; left: landing wall: old CCTV camera high up with red LED, an old wall calendar [design]; above: low ceiling with a small wall lamp; ground: worn wooden steps. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），台风夜，灯光昏黄，闪电从楼下门口透进冷光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：向上的楼梯段，通往二楼走廊和知遥卧室门；画面左边缘可见：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；画面右边缘可见：木扶手与栏杆；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），台风夜，灯光昏黄，闪电从楼下门口透进冷光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：向下的楼梯段，通往面馆堂食区，下方透出暖光；画面左边缘可见：木扶手与栏杆；画面右边缘可见：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），台风夜，灯光昏黄，闪电从楼下门口透进冷光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：拐角墙面：高处旧监控摄像头（红灯），墙上贴老挂历；画面左边缘可见：向下的楼梯段，通往面馆堂食区，下方透出暖光；画面右边缘可见：向上的楼梯段，通往二楼走廊和知遥卧室门；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家楼梯（一楼面馆→二楼住家，拐角旧监控），台风夜，灯光昏黄，闪电从楼下门口透进冷光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：木扶手与栏杆；画面左边缘可见：向上的楼梯段，通往二楼走廊和知遥卧室门；画面右边缘可见：向下的楼梯段，通往面馆堂食区，下方透出暖光；上方：低矮天花，一盏小壁灯；地面：磨旧的木台阶。色调：深木色、暗暖光、监控红点。布局与360°全景 S06-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S07 夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海）

*Xia family second-floor living room (low table, floor lamp, cluttered shelf, window to arcade roofs and sea)*

- **使用场次**：第4、5、9、18、21、24场
- **原文出处**：第4场：「暖黄的落地灯，木地板，靠墙的置物架上堆满腌菜罐、旧相册、渔网结成的装饰。窗外是骑楼的屋檐和远处一线海。一张矮桌上摆着一个小蛋糕」；第5场：「她猛地后退，撞到置物架，一个旧相册掉下来。」；第9场：「看见母亲坐在窗边，手里捏着一张缴费单，对着窗外的海发呆。」；第21场：「和第1天一模一样的矮桌……电视里在播台风橙色预警」；第24场：「墙上，旧照片旁边多了一个相框……从柜子里拿出一只新碗」；第24场：「橘猫“灯泡”……正趴在窗台上晒最后一点夕阳」
- **空间描述**：木地板客厅，中央一张矮桌，大家席地而坐；正面是大窗（窗台宽，可趴猫），窗外是骑楼屋檐和远处一线海；左墙靠墙置物架（腌菜罐、旧相册、渔网装饰）与落地灯；右墙是电视柜（旧电视）和碗柜；墙上挂旧照片与后来的剪报相框；背面是通往楼梯/厨房/阳台的门。
- **布局**：
  - 正面：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔
  - 右：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）
  - 背面：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门
  - 左：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟
  - 顶：木梁天花，一盏吸顶灯
  - 地：温润木地板，中央矮桌，周围坐垫
- **色调**：暖黄、橙、木棕、奶油白；窗外冷蓝的海　**氛围**：温暖、家、烟火气；全片“回到起点”的锚点空间
- 注：第4、21、24场构图刻意复刻，请先出 S07-A 全景，其余变体以它为图生图参考。
- 注：电视与碗柜位置为[设计补充]（剧本只有“电视里在播”“从柜子里拿出一只新碗”）。

**S07-A｜生日夜·暖灯（第1天 19:30）**（第4、5场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，暖黄落地灯，窗外夜色与远处一线海，温暖。木地板客厅，中央一张矮桌，大家席地而坐；正面是大窗（窗台宽，可趴猫），窗外是骑楼屋檐和远处一线海；左墙靠墙置物架（腌菜罐、旧相册、渔网装饰）与落地灯；右墙是电视柜（旧电视）和碗柜；墙上挂旧照片与后来的剪报相框；背面是通往楼梯/厨房/阳台的门。 正面：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；右侧：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；背面：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；左侧：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海；氛围：温暖、家、烟火气；全片“回到起点”的锚点空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family second-floor living room (low table, floor lamp, cluttered shelf, window to arcade roofs and sea), night, warm yellow floor lamp, night outside with a distant line of sea. a wooden-floored living room with a low table in the middle where everyone sits on the floor; a large window straight ahead with a wide sill, showing arcade rooftops and a distant line of sea; on the left wall a cluttered shelf of pickle jars, old photo albums and knotted fishing-net decorations, with a warm floor lamp; on the right wall a TV cabinet with an old TV and a crockery cupboard; framed old photo on the wall; behind, doorways to the stairs, a small kitchen and the balcony. Front: large wood-framed window with a wide sill; arcade rooftops, a distant line of sea and the far lighthouse outside; right: TV cabinet with an old TV, crockery cupboard; family photos on the wall (a framed newspaper clipping added in scene 24); back: doorway to the stairs and the small kitchen; glass sliding door to the balcony at back-right; left: wooden shelf against the wall crammed with pickle jars, old photo albums, knotted fishing-net decorations; warm floor lamp; wall clock; above: wood-beamed ceiling with a ceiling lamp; ground: warm wooden floorboards, low table in the middle with floor cushions. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，暖黄落地灯，窗外夜色与远处一线海，温暖。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面左边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面右边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，暖黄落地灯，窗外夜色与远处一线海，温暖。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面左边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面右边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，暖黄落地灯，窗外夜色与远处一线海，温暖。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面左边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面右边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，暖黄落地灯，窗外夜色与远处一线海，温暖。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面左边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面右边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S07-B｜生日夜·关灯烛光/停电**（第4、5场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），关灯后只剩蛋糕烛光的暖橙光；停电时全黑，窗外老灯塔闪一下。木地板客厅，中央一张矮桌，大家席地而坐；正面是大窗（窗台宽，可趴猫），窗外是骑楼屋檐和远处一线海；左墙靠墙置物架（腌菜罐、旧相册、渔网装饰）与落地灯；右墙是电视柜（旧电视）和碗柜；墙上挂旧照片与后来的剪报相框；背面是通往楼梯/厨房/阳台的门。 正面：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；右侧：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；背面：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；左侧：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海；氛围：温暖、家、烟火气；全片“回到起点”的锚点空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family second-floor living room (low table, floor lamp, cluttered shelf, window to arcade roofs and sea), lights off, only warm orange candlelight; blackout version fully dark with the distant lighthouse flashing. a wooden-floored living room with a low table in the middle where everyone sits on the floor; a large window straight ahead with a wide sill, showing arcade rooftops and a distant line of sea; on the left wall a cluttered shelf of pickle jars, old photo albums and knotted fishing-net decorations, with a warm floor lamp; on the right wall a TV cabinet with an old TV and a crockery cupboard; framed old photo on the wall; behind, doorways to the stairs, a small kitchen and the balcony. Front: large wood-framed window with a wide sill; arcade rooftops, a distant line of sea and the far lighthouse outside; right: TV cabinet with an old TV, crockery cupboard; family photos on the wall (a framed newspaper clipping added in scene 24); back: doorway to the stairs and the small kitchen; glass sliding door to the balcony at back-right; left: wooden shelf against the wall crammed with pickle jars, old photo albums, knotted fishing-net decorations; warm floor lamp; wall clock; above: wood-beamed ceiling with a ceiling lamp; ground: warm wooden floorboards, low table in the middle with floor cushions. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），关灯后只剩蛋糕烛光的暖橙光；停电时全黑，窗外老灯塔闪一下。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面左边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面右边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），关灯后只剩蛋糕烛光的暖橙光；停电时全黑，窗外老灯塔闪一下。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面左边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面右边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），关灯后只剩蛋糕烛光的暖橙光；停电时全黑，窗外老灯塔闪一下。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面左边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面右边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），关灯后只剩蛋糕烛光的暖橙光；停电时全黑，窗外老灯塔闪一下。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面左边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面右边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S07-C｜夜·窗边逆光（缴费单）/晚饭争吵**（第9、18场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，室内暖黄，窗外的海是一条冷蓝色的线，窗边逆光剪影。木地板客厅，中央一张矮桌，大家席地而坐；正面是大窗（窗台宽，可趴猫），窗外是骑楼屋檐和远处一线海；左墙靠墙置物架（腌菜罐、旧相册、渔网装饰）与落地灯；右墙是电视柜（旧电视）和碗柜；墙上挂旧照片与后来的剪报相框；背面是通往楼梯/厨房/阳台的门。 正面：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；右侧：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；背面：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；左侧：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海；氛围：温暖、家、烟火气；全片“回到起点”的锚点空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family second-floor living room (low table, floor lamp, cluttered shelf, window to arcade roofs and sea), night, warm interior, the sea outside a cold blue line, backlit silhouette by the window. a wooden-floored living room with a low table in the middle where everyone sits on the floor; a large window straight ahead with a wide sill, showing arcade rooftops and a distant line of sea; on the left wall a cluttered shelf of pickle jars, old photo albums and knotted fishing-net decorations, with a warm floor lamp; on the right wall a TV cabinet with an old TV and a crockery cupboard; framed old photo on the wall; behind, doorways to the stairs, a small kitchen and the balcony. Front: large wood-framed window with a wide sill; arcade rooftops, a distant line of sea and the far lighthouse outside; right: TV cabinet with an old TV, crockery cupboard; family photos on the wall (a framed newspaper clipping added in scene 24); back: doorway to the stairs and the small kitchen; glass sliding door to the balcony at back-right; left: wooden shelf against the wall crammed with pickle jars, old photo albums, knotted fishing-net decorations; warm floor lamp; wall clock; above: wood-beamed ceiling with a ceiling lamp; ground: warm wooden floorboards, low table in the middle with floor cushions. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，室内暖黄，窗外的海是一条冷蓝色的线，窗边逆光剪影。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面左边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面右边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，室内暖黄，窗外的海是一条冷蓝色的线，窗边逆光剪影。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面左边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面右边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，室内暖黄，窗外的海是一条冷蓝色的线，窗边逆光剪影。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面左边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面右边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），夜晚，室内暖黄，窗外的海是一条冷蓝色的线，窗边逆光剪影。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面左边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面右边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S07-D｜台风夜（第17天）**（第21场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），台风夜，室内暖黄灯光，窗外狂风暴雨，闪电把室内照得惨白，电视发出蓝光。木地板客厅，中央一张矮桌，大家席地而坐；正面是大窗（窗台宽，可趴猫），窗外是骑楼屋檐和远处一线海；左墙靠墙置物架（腌菜罐、旧相册、渔网装饰）与落地灯；右墙是电视柜（旧电视）和碗柜；墙上挂旧照片与后来的剪报相框；背面是通往楼梯/厨房/阳台的门。 正面：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；右侧：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；背面：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；左侧：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海；氛围：温暖、家、烟火气；全片“回到起点”的锚点空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family second-floor living room (low table, floor lamp, cluttered shelf, window to arcade roofs and sea), typhoon night, warm interior, raging storm outside the window, lightning flashes bleaching the room, bluish TV glow. a wooden-floored living room with a low table in the middle where everyone sits on the floor; a large window straight ahead with a wide sill, showing arcade rooftops and a distant line of sea; on the left wall a cluttered shelf of pickle jars, old photo albums and knotted fishing-net decorations, with a warm floor lamp; on the right wall a TV cabinet with an old TV and a crockery cupboard; framed old photo on the wall; behind, doorways to the stairs, a small kitchen and the balcony. Front: large wood-framed window with a wide sill; arcade rooftops, a distant line of sea and the far lighthouse outside; right: TV cabinet with an old TV, crockery cupboard; family photos on the wall (a framed newspaper clipping added in scene 24); back: doorway to the stairs and the small kitchen; glass sliding door to the balcony at back-right; left: wooden shelf against the wall crammed with pickle jars, old photo albums, knotted fishing-net decorations; warm floor lamp; wall clock; above: wood-beamed ceiling with a ceiling lamp; ground: warm wooden floorboards, low table in the middle with floor cushions. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），台风夜，室内暖黄灯光，窗外狂风暴雨，闪电把室内照得惨白，电视发出蓝光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面左边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面右边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-D 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），台风夜，室内暖黄灯光，窗外狂风暴雨，闪电把室内照得惨白，电视发出蓝光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面左边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面右边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-D 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），台风夜，室内暖黄灯光，窗外狂风暴雨，闪电把室内照得惨白，电视发出蓝光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面左边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面右边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-D 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），台风夜，室内暖黄灯光，窗外狂风暴雨，闪电把室内照得惨白，电视发出蓝光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面左边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面右边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-D 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S07-E｜一个月后·傍晚最暖**（第24场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），傍晚，暖黄灯光加窗外最后一缕夕阳，画面全片最暖。木地板客厅，中央一张矮桌，大家席地而坐；正面是大窗（窗台宽，可趴猫），窗外是骑楼屋檐和远处一线海；左墙靠墙置物架（腌菜罐、旧相册、渔网装饰）与落地灯；右墙是电视柜（旧电视）和碗柜；墙上挂旧照片与后来的剪报相框；背面是通往楼梯/厨房/阳台的门。 正面：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；右侧：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；背面：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；左侧：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海；氛围：温暖、家、烟火气；全片“回到起点”的锚点空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family second-floor living room (low table, floor lamp, cluttered shelf, window to arcade roofs and sea), evening, warm lamps plus the last ray of sunset through the window, the warmest look in the film. a wooden-floored living room with a low table in the middle where everyone sits on the floor; a large window straight ahead with a wide sill, showing arcade rooftops and a distant line of sea; on the left wall a cluttered shelf of pickle jars, old photo albums and knotted fishing-net decorations, with a warm floor lamp; on the right wall a TV cabinet with an old TV and a crockery cupboard; framed old photo on the wall; behind, doorways to the stairs, a small kitchen and the balcony. Front: large wood-framed window with a wide sill; arcade rooftops, a distant line of sea and the far lighthouse outside; right: TV cabinet with an old TV, crockery cupboard; family photos on the wall (a framed newspaper clipping added in scene 24); back: doorway to the stairs and the small kitchen; glass sliding door to the balcony at back-right; left: wooden shelf against the wall crammed with pickle jars, old photo albums, knotted fishing-net decorations; warm floor lamp; wall clock; above: wood-beamed ceiling with a ceiling lamp; ground: warm wooden floorboards, low table in the middle with floor cushions. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），傍晚，暖黄灯光加窗外最后一缕夕阳，画面全片最暖。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面左边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面右边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-E 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），傍晚，暖黄灯光加窗外最后一缕夕阳，画面全片最暖。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面左边缘可见：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面右边缘可见：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-E 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），傍晚，暖黄灯光加窗外最后一缕夕阳，画面全片最暖。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：靠墙木置物架：腌菜罐、旧相册、渔网结装饰；暖黄落地灯；挂墙挂钟；画面左边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；画面右边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-E 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼客厅（矮桌·落地灯·置物架·窗外骑楼与海），傍晚，暖黄灯光加窗外最后一缕夕阳，画面全片最暖。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：电视柜与旧电视、碗柜；墙上挂家庭旧照片（第24场旁边多一个剪报相框）；画面左边缘可见：大木框窗，宽窗台，窗外骑楼屋檐与远处一线海、远处老灯塔；画面右边缘可见：通往楼梯口的门与小厨房门；右后侧通往阳台的玻璃推拉门；上方：木梁天花，一盏吸顶灯；地面：温润木地板，中央矮桌，周围坐垫。色调：暖黄、橙、木棕、奶油白；窗外冷蓝的海。布局与360°全景 S07-E 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S08 夏家二楼阳台

*Xia family second-floor balcony*

- **使用场次**：第24场
- **原文出处**：第24场：「饭后，知遥和周砚站在阳台上。台风过后的澄港，天空洗过一样干净，晚霞铺满了整片海。远处的老灯塔安静地亮着。」
- **空间描述**：客厅外的小阳台，铁艺栏杆，晾衣架，几盆花草；面朝骑楼屋顶和大海，远处老灯塔。
- **布局**：
  - 正面：铁艺栏杆外：骑楼屋顶、海湾、晚霞与远处老灯塔
  - 右：邻家屋顶与天线，可见隔壁老楼
  - 背面：通回客厅的玻璃推拉门，门内暖光
  - 左：晾衣架与盆栽
  - 顶：开阔天空，海鸥
  - 地：水泥地面，排水口
- **色调**：橘粉晚霞、金色、剪影暗紫　**氛围**：宁静、圆满
- 注：阳台陈设为[设计补充]。

**S08-A｜台风后晚霞·逆光**（第24场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼阳台，傍晚逆光，晚霞铺满整片海，海风，人物位置成剪影。客厅外的小阳台，铁艺栏杆，晾衣架，几盆花草；面朝骑楼屋顶和大海，远处老灯塔。 正面：铁艺栏杆外：骑楼屋顶、海湾、晚霞与远处老灯塔；右侧：邻家屋顶与天线，可见隔壁老楼；背面：通回客厅的玻璃推拉门，门内暖光；左侧：晾衣架与盆栽；上方：开阔天空，海鸥；地面：水泥地面，排水口。色调：橘粉晚霞、金色、剪影暗紫；氛围：宁静、圆满。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Xia family second-floor balcony, evening backlight, sunset clouds over the whole sea, sea breeze, silhouette lighting. a small balcony off the living room with wrought-iron railing, a laundry rack and a few potted plants, facing arcade rooftops and the sea with the old lighthouse in the distance. Front: beyond the iron railing: arcade rooftops, the bay, sunset clouds and the distant lighthouse; right: neighbouring rooftops and antennas, the old building next door; back: glass sliding door back to the warm-lit living room; left: laundry rack and potted plants; above: open sky with seagulls; ground: concrete floor with a drain. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼阳台，傍晚逆光，晚霞铺满整片海，海风，人物位置成剪影。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：铁艺栏杆外：骑楼屋顶、海湾、晚霞与远处老灯塔；画面左边缘可见：晾衣架与盆栽；画面右边缘可见：邻家屋顶与天线，可见隔壁老楼；上方：开阔天空，海鸥；地面：水泥地面，排水口。色调：橘粉晚霞、金色、剪影暗紫。布局与360°全景 S08-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼阳台，傍晚逆光，晚霞铺满整片海，海风，人物位置成剪影。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通回客厅的玻璃推拉门，门内暖光；画面左边缘可见：邻家屋顶与天线，可见隔壁老楼；画面右边缘可见：晾衣架与盆栽；上方：开阔天空，海鸥；地面：水泥地面，排水口。色调：橘粉晚霞、金色、剪影暗紫。布局与360°全景 S08-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼阳台，傍晚逆光，晚霞铺满整片海，海风，人物位置成剪影。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：晾衣架与盆栽；画面左边缘可见：通回客厅的玻璃推拉门，门内暖光；画面右边缘可见：铁艺栏杆外：骑楼屋顶、海湾、晚霞与远处老灯塔；上方：开阔天空，海鸥；地面：水泥地面，排水口。色调：橘粉晚霞、金色、剪影暗紫。布局与360°全景 S08-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，夏家二楼阳台，傍晚逆光，晚霞铺满整片海，海风，人物位置成剪影。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：邻家屋顶与天线，可见隔壁老楼；画面左边缘可见：铁艺栏杆外：骑楼屋顶、海湾、晚霞与远处老灯塔；画面右边缘可见：通回客厅的玻璃推拉门，门内暖光；上方：开阔天空，海鸥；地面：水泥地面，排水口。色调：橘粉晚霞、金色、剪影暗紫。布局与360°全景 S08-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S09 知遥卧室（书桌·台灯·便利贴墙·窗对周砚家）

*Zhiyao's bedroom (desk, desk lamp, sticky-note wall, window facing Zhou Yan's window)*

- **使用场次**：第5、6、9、13、16、18、20场
- **原文出处**：第5场：「知遥跑回房间，站在窗边往下看。隔壁楼二层的窗口，周砚正站在窗前……知遥“唰”地拉上窗帘。」；第6场：「深夜，台灯下。知遥穿着睡衣，抱着浅蓝色作文本……书桌上空、床上空空荡荡」；第13场：「书桌上的台灯开着暖光。墙上贴着她写的便利贴，书架上塞满小说。窗外是隔壁楼的窗口。」；第18场：「知遥关上门，背靠着门滑坐在地上……露出真实的木地板和窗外的月光」；第18场：「看向墙上的日历：9月14日」；第20场：「她把手机架在书桌上，打开前置摄像头。」
- **空间描述**：少女小卧室：正面是窗（带窗帘），窗外隔窄巷对着周砚家二楼窗口；窗下是书桌和台灯，两侧可坐两人；左墙书架塞满小说、墙上贴满便利贴和日历；右墙是单人床；背面是房门。
- **布局**：
  - 正面：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒
  - 右：单人床，浅色床单，枕边小玩偶[设计补充]
  - 背面：木房门（可背靠滑坐），门后挂书包
  - 左：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历
  - 顶：简单吸顶灯
  - 地：木地板，小地毯
- **色调**：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝　**氛围**：私密、安全；镜头外的空间
- 注：家具朝向为[设计补充]；书桌、台灯、便利贴、书架小说、窗对周砚家、日历、木地板、月光均为剧本原文。
- 注：第16场结尾“当晚8:00”看潮声App的地点剧本未写，暂放在卧室[设计补充]。

**S09-A｜深夜台灯**（第5、6、9、13、16、18场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），深夜，只开书桌台灯的暖光，窗外夜色，远处海浪。少女小卧室：正面是窗（带窗帘），窗外隔窄巷对着周砚家二楼窗口；窗下是书桌和台灯，两侧可坐两人；左墙书架塞满小说、墙上贴满便利贴和日历；右墙是单人床；背面是房门。 正面：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；右侧：单人床，浅色床单，枕边小玩偶；背面：木房门（可背靠滑坐），门后挂书包；左侧：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝；氛围：私密、安全；镜头外的空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Zhiyao's bedroom (desk, desk lamp, sticky-note wall, window facing Zhou Yan's window), late night, only the warm desk lamp, dark night outside the window. a small teenage girl's bedroom: window with curtains straight ahead, across a narrow alley it faces Zhou Yan's second-floor window; desk with a warm desk lamp under the window, room for two people on either side; on the left a bookshelf packed with novels and a wall covered in sticky notes and a calendar; a single bed on the right; the bedroom door behind. Front: window with light curtains; across a narrow alley the neighbouring building's second-floor window (Zhou Yan's); desk under the window with a desk lamp and pen holder; right: single bed with pale bedding, small plush toy by the pillow [design]; back: wooden bedroom door, schoolbag hanging on it; left: bookshelf crammed with novels; wall covered in handwritten sticky notes and a hanging calendar; above: simple ceiling light; ground: wooden floor with a small rug. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），深夜，只开书桌台灯的暖光，窗外夜色，远处海浪。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；画面左边缘可见：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；画面右边缘可见：单人床，浅色床单，枕边小玩偶；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），深夜，只开书桌台灯的暖光，窗外夜色，远处海浪。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：木房门（可背靠滑坐），门后挂书包；画面左边缘可见：单人床，浅色床单，枕边小玩偶；画面右边缘可见：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），深夜，只开书桌台灯的暖光，窗外夜色，远处海浪。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；画面左边缘可见：木房门（可背靠滑坐），门后挂书包；画面右边缘可见：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），深夜，只开书桌台灯的暖光，窗外夜色，远处海浪。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：单人床，浅色床单，枕边小玩偶；画面左边缘可见：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；画面右边缘可见：木房门（可背靠滑坐），门后挂书包；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S09-B｜深夜·关灯月光（弹幕退潮后）**（第18场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），夜，房间灯未开，窗外月光洒在木地板上，冷蓝静谧。少女小卧室：正面是窗（带窗帘），窗外隔窄巷对着周砚家二楼窗口；窗下是书桌和台灯，两侧可坐两人；左墙书架塞满小说、墙上贴满便利贴和日历；右墙是单人床；背面是房门。 正面：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；右侧：单人床，浅色床单，枕边小玩偶；背面：木房门（可背靠滑坐），门后挂书包；左侧：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝；氛围：私密、安全；镜头外的空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Zhiyao's bedroom (desk, desk lamp, sticky-note wall, window facing Zhou Yan's window), night, room lights off, moonlight through the window onto the wooden floor, cold blue and still. a small teenage girl's bedroom: window with curtains straight ahead, across a narrow alley it faces Zhou Yan's second-floor window; desk with a warm desk lamp under the window, room for two people on either side; on the left a bookshelf packed with novels and a wall covered in sticky notes and a calendar; a single bed on the right; the bedroom door behind. Front: window with light curtains; across a narrow alley the neighbouring building's second-floor window (Zhou Yan's); desk under the window with a desk lamp and pen holder; right: single bed with pale bedding, small plush toy by the pillow [design]; back: wooden bedroom door, schoolbag hanging on it; left: bookshelf crammed with novels; wall covered in handwritten sticky notes and a hanging calendar; above: simple ceiling light; ground: wooden floor with a small rug. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），夜，房间灯未开，窗外月光洒在木地板上，冷蓝静谧。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；画面左边缘可见：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；画面右边缘可见：单人床，浅色床单，枕边小玩偶；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），夜，房间灯未开，窗外月光洒在木地板上，冷蓝静谧。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：木房门（可背靠滑坐），门后挂书包；画面左边缘可见：单人床，浅色床单，枕边小玩偶；画面右边缘可见：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），夜，房间灯未开，窗外月光洒在木地板上，冷蓝静谧。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；画面左边缘可见：木房门（可背靠滑坐），门后挂书包；画面右边缘可见：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），夜，房间灯未开，窗外月光洒在木地板上，冷蓝静谧。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：单人床，浅色床单，枕边小玩偶；画面左边缘可见：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；画面右边缘可见：木房门（可背靠滑坐），门后挂书包；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S09-C｜白天（录视频）**（第20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），白天自然光从窗户照进，干净明亮。少女小卧室：正面是窗（带窗帘），窗外隔窄巷对着周砚家二楼窗口；窗下是书桌和台灯，两侧可坐两人；左墙书架塞满小说、墙上贴满便利贴和日历；右墙是单人床；背面是房门。 正面：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；右侧：单人床，浅色床单，枕边小玩偶；背面：木房门（可背靠滑坐），门后挂书包；左侧：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝；氛围：私密、安全；镜头外的空间。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Zhiyao's bedroom (desk, desk lamp, sticky-note wall, window facing Zhou Yan's window), clean natural daylight through the window. a small teenage girl's bedroom: window with curtains straight ahead, across a narrow alley it faces Zhou Yan's second-floor window; desk with a warm desk lamp under the window, room for two people on either side; on the left a bookshelf packed with novels and a wall covered in sticky notes and a calendar; a single bed on the right; the bedroom door behind. Front: window with light curtains; across a narrow alley the neighbouring building's second-floor window (Zhou Yan's); desk under the window with a desk lamp and pen holder; right: single bed with pale bedding, small plush toy by the pillow [design]; back: wooden bedroom door, schoolbag hanging on it; left: bookshelf crammed with novels; wall covered in handwritten sticky notes and a hanging calendar; above: simple ceiling light; ground: wooden floor with a small rug. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），白天自然光从窗户照进，干净明亮。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；画面左边缘可见：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；画面右边缘可见：单人床，浅色床单，枕边小玩偶；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），白天自然光从窗户照进，干净明亮。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：木房门（可背靠滑坐），门后挂书包；画面左边缘可见：单人床，浅色床单，枕边小玩偶；画面右边缘可见：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），白天自然光从窗户照进，干净明亮。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：书架塞满小说；墙上贴满手写便利贴与一本挂墙日历；画面左边缘可见：木房门（可背靠滑坐），门后挂书包；画面右边缘可见：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，知遥卧室（书桌·台灯·便利贴墙·窗对周砚家），白天自然光从窗户照进，干净明亮。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：单人床，浅色床单，枕边小玩偶；画面左边缘可见：窗户与浅色窗帘；窗外隔窄巷是隔壁老楼二楼周砚家的窗；窗下书桌、台灯、笔筒；画面右边缘可见：木房门（可背靠滑坐），门后挂书包；上方：简单吸顶灯；地面：木地板，小地毯。色调：暖黄台灯、奶油白、浅蓝点缀；夜窗冷蓝。布局与360°全景 S09-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S10 周砚家（隔壁老楼二层·一室一厅·小厨房）

*Zhou Yan's apartment (second floor of the old building next door, one bedroom, tiny kitchen)*

- **使用场次**：第5、13、14、18、20场
- **原文出处**：第14场：「周砚家很小，一室一厅，收拾得很整齐，但空。冰箱门上贴满了黄色便利贴」；第14场：「周砚系着围裙在小厨房里煎蛋……把两碗面端到小桌上」；第14场：「书架上：一个敞开的鞋盒里，堆着十几块游泳比赛的奖牌」；第14场：「书桌上压着一张手写的日历，从9月1日到9月17日」；第20场：「周砚坐在没开灯的房间里，手机屏幕的光照着他的脸……看向窗外隔壁的窗口」
- **空间描述**：很小很空的一室一厅：正面是窗（对着知遥卧室窗）；左侧是开放小厨房（单灶、冰箱贴满黄色便利贴）；中间一张小饭桌两把椅子；右侧是书桌（压着手写日历）与书架（鞋盒奖牌）；背面是入户门与通卧室的门。
- **布局**：
  - 正面：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗
  - 右：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）
  - 背面：入户门（门边鞋柜），通卧室的门
  - 左：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴
  - 顶：一根偏冷的白色日光灯管
  - 地：浅色地砖，小饭桌和两把椅子（椅背可搭外套）
- **色调**：偏冷白光，冰箱上便利贴是唯一暖黄　**氛围**：整齐、空、孤独但被惦记
- 注：家具位置为[设计补充]；冰箱便利贴、小厨房、小桌、鞋盒奖牌、手写日历、窗对知遥家为原文。

**S10-A｜夜·冷白日光灯**（第14场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚，偏冷的白色日光灯，冰箱上黄色便利贴是唯一暖色。很小很空的一室一厅：正面是窗（对着知遥卧室窗）；左侧是开放小厨房（单灶、冰箱贴满黄色便利贴）；中间一张小饭桌两把椅子；右侧是书桌（压着手写日历）与书架（鞋盒奖牌）；背面是入户门与通卧室的门。 正面：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；右侧：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；背面：入户门（门边鞋柜），通卧室的门；左侧：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄；氛围：整齐、空、孤独但被惦记。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Zhou Yan's apartment (second floor of the old building next door, one bedroom, tiny kitchen), night, cool white fluorescent light, the yellow sticky notes the only warm color. a tiny, sparse one-bedroom flat: window straight ahead facing Zhiyao's bedroom window; a small open kitchen on the left with a single burner and a fridge covered in yellow sticky notes; a small dining table with two chairs in the middle; on the right a desk with a handwritten calendar under the glass and a bookshelf holding an open shoebox of medals; entrance door and bedroom door behind. Front: window facing, across a narrow alley, Zhiyao's bedroom window in the Xia house; right: desk with a handwritten 1–17 September calendar under its glass top; bookshelf with an open shoebox of a dozen swim medals; back: entrance door with a shoe cabinet, door to the bedroom; left: small open kitchen: single gas burner, frying pan, sink; white fridge door covered in yellow sticky notes; above: one cool white fluorescent tube; ground: pale floor tiles, small dining table with two chairs (jacket over the chair back). equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚，偏冷的白色日光灯，冰箱上黄色便利贴是唯一暖色。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；画面左边缘可见：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；画面右边缘可见：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚，偏冷的白色日光灯，冰箱上黄色便利贴是唯一暖色。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：入户门（门边鞋柜），通卧室的门；画面左边缘可见：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；画面右边缘可见：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚，偏冷的白色日光灯，冰箱上黄色便利贴是唯一暖色。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；画面左边缘可见：入户门（门边鞋柜），通卧室的门；画面右边缘可见：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚，偏冷的白色日光灯，冰箱上黄色便利贴是唯一暖色。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；画面左边缘可见：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；画面右边缘可见：入户门（门边鞋柜），通卧室的门；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S10-B｜夜·不开灯，仅手机屏光**（第20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚房间不开灯，只有手机屏幕的蓝白光，窗外雨越来越大，对面窗口暖光。很小很空的一室一厅：正面是窗（对着知遥卧室窗）；左侧是开放小厨房（单灶、冰箱贴满黄色便利贴）；中间一张小饭桌两把椅子；右侧是书桌（压着手写日历）与书架（鞋盒奖牌）；背面是入户门与通卧室的门。 正面：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；右侧：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；背面：入户门（门边鞋柜），通卧室的门；左侧：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄；氛围：整齐、空、孤独但被惦记。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Zhou Yan's apartment (second floor of the old building next door, one bedroom, tiny kitchen), night, room lights off, only bluish phone-screen glow, rain increasing outside, warm light in the window opposite. a tiny, sparse one-bedroom flat: window straight ahead facing Zhiyao's bedroom window; a small open kitchen on the left with a single burner and a fridge covered in yellow sticky notes; a small dining table with two chairs in the middle; on the right a desk with a handwritten calendar under the glass and a bookshelf holding an open shoebox of medals; entrance door and bedroom door behind. Front: window facing, across a narrow alley, Zhiyao's bedroom window in the Xia house; right: desk with a handwritten 1–17 September calendar under its glass top; bookshelf with an open shoebox of a dozen swim medals; back: entrance door with a shoe cabinet, door to the bedroom; left: small open kitchen: single gas burner, frying pan, sink; white fridge door covered in yellow sticky notes; above: one cool white fluorescent tube; ground: pale floor tiles, small dining table with two chairs (jacket over the chair back). equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚房间不开灯，只有手机屏幕的蓝白光，窗外雨越来越大，对面窗口暖光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；画面左边缘可见：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；画面右边缘可见：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚房间不开灯，只有手机屏幕的蓝白光，窗外雨越来越大，对面窗口暖光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：入户门（门边鞋柜），通卧室的门；画面左边缘可见：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；画面右边缘可见：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚房间不开灯，只有手机屏幕的蓝白光，窗外雨越来越大，对面窗口暖光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；画面左边缘可见：入户门（门边鞋柜），通卧室的门；画面右边缘可见：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），夜晚房间不开灯，只有手机屏幕的蓝白光，窗外雨越来越大，对面窗口暖光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；画面左边缘可见：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；画面右边缘可见：入户门（门边鞋柜），通卧室的门；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S10-C｜外景·从知遥窗口看过来的窗**（第5、13、18、20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），从对面看：老楼二层一扇窗，夜里亮灯或不亮灯。很小很空的一室一厅：正面是窗（对着知遥卧室窗）；左侧是开放小厨房（单灶、冰箱贴满黄色便利贴）；中间一张小饭桌两把椅子；右侧是书桌（压着手写日历）与书架（鞋盒奖牌）；背面是入户门与通卧室的门。 正面：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；右侧：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；背面：入户门（门边鞋柜），通卧室的门；左侧：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄；氛围：整齐、空、孤独但被惦记。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Zhou Yan's apartment (second floor of the old building next door, one bedroom, tiny kitchen), exterior view from across the alley: one second-floor window of an old building, lit or unlit at night. a tiny, sparse one-bedroom flat: window straight ahead facing Zhiyao's bedroom window; a small open kitchen on the left with a single burner and a fridge covered in yellow sticky notes; a small dining table with two chairs in the middle; on the right a desk with a handwritten calendar under the glass and a bookshelf holding an open shoebox of medals; entrance door and bedroom door behind. Front: window facing, across a narrow alley, Zhiyao's bedroom window in the Xia house; right: desk with a handwritten 1–17 September calendar under its glass top; bookshelf with an open shoebox of a dozen swim medals; back: entrance door with a shoe cabinet, door to the bedroom; left: small open kitchen: single gas burner, frying pan, sink; white fridge door covered in yellow sticky notes; above: one cool white fluorescent tube; ground: pale floor tiles, small dining table with two chairs (jacket over the chair back). equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），从对面看：老楼二层一扇窗，夜里亮灯或不亮灯。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；画面左边缘可见：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；画面右边缘可见：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），从对面看：老楼二层一扇窗，夜里亮灯或不亮灯。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：入户门（门边鞋柜），通卧室的门；画面左边缘可见：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；画面右边缘可见：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），从对面看：老楼二层一扇窗，夜里亮灯或不亮灯。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：开放小厨房：单眼燃气灶、平底锅、水池；白色冰箱门上贴满黄色便利贴；画面左边缘可见：入户门（门边鞋柜），通卧室的门；画面右边缘可见：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，周砚家（隔壁老楼二层·一室一厅·小厨房），从对面看：老楼二层一扇窗，夜里亮灯或不亮灯。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：书桌（压着9/1–9/17手写日历）、书架（敞开的鞋盒里十几块奖牌）；画面左边缘可见：窗户，窗外隔窄巷对着夏家二楼知遥卧室的窗；画面右边缘可见：入户门（门边鞋柜），通卧室的门；上方：一根偏冷的白色日光灯管；地面：浅色地砖，小饭桌和两把椅子（椅背可搭外套）。色调：偏冷白光，冰箱上便利贴是唯一暖黄。布局与360°全景 S10-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S11 两楼之间的窄巷（两扇二楼窗口相对）

*Narrow alley between the two buildings (two second-floor windows facing each other)*

- **使用场次**：第5、13、18、20场
- **原文出处**：第5场：「隔壁楼二层的窗口，周砚正站在窗前，同样在看她。两人隔着一条窄巷对视。」；第18场：「窗外，隔壁楼周砚家的窗口没有亮灯。」；第20场：「他抬起头，看向窗外隔壁的窗口。知遥正站在那里，对他挥了挥手。」
- **空间描述**：夏家与周砚家老楼之间一条很窄的巷子，两栋楼二楼窗口正对，距离约四五米。
- **布局**：
  - 正面：周砚家二楼窗口（老楼外墙、防盗窗）
  - 右：窄巷延伸向后方，晾衣绳、空调外机
  - 背面：知遥卧室窗口（夏家外墙）
  - 左：窄巷延伸向街道，远处路灯
  - 顶：一线夜空
  - 地：巷底湿地面（从二楼高度俯视）
- **色调**：夜蓝、窗内暖光　**氛围**：对望、试探、心动
- 注：全景机位放在窄巷中间二楼高度（悬空）为[设计补充]，方便两侧窗口互拍。

**S11-A｜夜·两窗对望**（第5、13、18、20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，两楼之间的窄巷（两扇二楼窗口相对），夜晚，两扇窗透出暖光（第18场周砚窗不亮），第20场窗外下雨。夏家与周砚家老楼之间一条很窄的巷子，两栋楼二楼窗口正对，距离约四五米。 正面：周砚家二楼窗口（老楼外墙、防盗窗）；右侧：窄巷延伸向后方，晾衣绳、空调外机；背面：知遥卧室窗口（夏家外墙）；左侧：窄巷延伸向街道，远处路灯；上方：一线夜空；地面：巷底湿地面（从二楼高度俯视）。色调：夜蓝、窗内暖光；氛围：对望、试探、心动。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Narrow alley between the two buildings (two second-floor windows facing each other), night, warm light from both windows (Zhou's unlit in scene 18; rain in scene 20). a very narrow alley between the Xia house and Zhou Yan's old building; their second-floor windows face each other about four or five metres apart. Front: Zhou Yan's second-floor window (old building wall, window bars); right: alley running back, laundry lines, AC units; back: Zhiyao's bedroom window (Xia house wall); left: alley running toward the street, distant street lamp; above: a strip of night sky; ground: wet alley floor seen from second-floor height. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，两楼之间的窄巷（两扇二楼窗口相对），夜晚，两扇窗透出暖光（第18场周砚窗不亮），第20场窗外下雨。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：周砚家二楼窗口（老楼外墙、防盗窗）；画面左边缘可见：窄巷延伸向街道，远处路灯；画面右边缘可见：窄巷延伸向后方，晾衣绳、空调外机；上方：一线夜空；地面：巷底湿地面（从二楼高度俯视）。色调：夜蓝、窗内暖光。布局与360°全景 S11-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，两楼之间的窄巷（两扇二楼窗口相对），夜晚，两扇窗透出暖光（第18场周砚窗不亮），第20场窗外下雨。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：知遥卧室窗口（夏家外墙）；画面左边缘可见：窄巷延伸向后方，晾衣绳、空调外机；画面右边缘可见：窄巷延伸向街道，远处路灯；上方：一线夜空；地面：巷底湿地面（从二楼高度俯视）。色调：夜蓝、窗内暖光。布局与360°全景 S11-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，两楼之间的窄巷（两扇二楼窗口相对），夜晚，两扇窗透出暖光（第18场周砚窗不亮），第20场窗外下雨。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：窄巷延伸向街道，远处路灯；画面左边缘可见：知遥卧室窗口（夏家外墙）；画面右边缘可见：周砚家二楼窗口（老楼外墙、防盗窗）；上方：一线夜空；地面：巷底湿地面（从二楼高度俯视）。色调：夜蓝、窗内暖光。布局与360°全景 S11-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，两楼之间的窄巷（两扇二楼窗口相对），夜晚，两扇窗透出暖光（第18场周砚窗不亮），第20场窗外下雨。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：窄巷延伸向后方，晾衣绳、空调外机；画面左边缘可见：周砚家二楼窗口（老楼外墙、防盗窗）；画面右边缘可见：知遥卧室窗口（夏家外墙）；上方：一线夜空；地面：巷底湿地面（从二楼高度俯视）。色调：夜蓝、窗内暖光。布局与360°全景 S11-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S12 澄港第七中学·高二（3）班教室

*Chenggang No.7 Middle School, Class 3 Grade 11 classroom*

- **使用场次**：第3、7、13、20场
- **原文出处**：第3场：「教室里吵吵嚷嚷，好几部手机在课桌底下传来传去。」；第3场：「你坐……夏知遥旁边，靠窗那个空位。」；第3场：「周砚（站在讲台边……）」；第3场：「窗外，远处天空有一道极淡的云带。」；第7场：「教室后排，一个同学正举着手机拍窗外的晚霞」；第20场：「朵朵站在教室讲台上，红着眼对全班说」；第13场：「两人在教室里，隔着一张课桌……同时偷偷比了个“耶”」
- **空间描述**：坡道老校园里的普通高中教室：正面黑板与讲台；左侧一排大窗（白色窗帘，可远望港口），知遥和周砚的座位在靠窗；右侧是走廊一侧的窗与前后门；背面是后墙黑板报与储物柜。
- **布局**：
  - 正面：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭
  - 右：走廊侧窗户与前门
  - 背面：后墙黑板报（空白，文字后期）、储物柜、后门
  - 左：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌
  - 顶：日光灯管与吊扇
  - 地：水磨石地面，整齐的课桌椅
- **色调**：上午白亮日光、浅绿墙裙、木色课桌　**氛围**：吵闹、被围观（手机像鱼群）
- 注：第7场时间写“下午第二节课后”，但同学拍“窗外的晚霞”，光线取下午偏晚的暖橙[设计补充]，请确认。

**S12-A｜上午日光（开学日）**（第3、13场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，上午明亮日光，窗帘被风吹起，远处天空一道极淡的云带。坡道老校园里的普通高中教室：正面黑板与讲台；左侧一排大窗（白色窗帘，可远望港口），知遥和周砚的座位在靠窗；右侧是走廊一侧的窗与前后门；背面是后墙黑板报与储物柜。 正面：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；右侧：走廊侧窗户与前门；背面：后墙黑板报（空白，文字后期）、储物柜、后门；左侧：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌；氛围：吵闹、被围观（手机像鱼群）。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Chenggang No.7 Middle School, Class 3 Grade 11 classroom, bright morning daylight, curtains lifting in the breeze, a faint band of cloud in the far sky. an ordinary high-school classroom in an old hillside campus: blackboard and teacher's podium in front; a row of large windows with white curtains on the left looking far over the harbor, Zhiyao's and Zhou Yan's seats by the window; corridor-side windows and front/back doors on the right; back wall with a chalk bulletin board and lockers. Front: blackboard, podium and teacher's desk, clock and PA speaker above the board; right: corridor-side windows and the front door; back: rear chalk bulletin board (blank, text in post), lockers, back door; left: row of large windows with white curtains blowing, the harbor and sea visible far away; desks by the window; above: fluorescent tubes and ceiling fans; ground: terrazzo floor with rows of desks and chairs. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，上午明亮日光，窗帘被风吹起，远处天空一道极淡的云带。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；画面左边缘可见：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；画面右边缘可见：走廊侧窗户与前门；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，上午明亮日光，窗帘被风吹起，远处天空一道极淡的云带。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：后墙黑板报（空白，文字后期）、储物柜、后门；画面左边缘可见：走廊侧窗户与前门；画面右边缘可见：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，上午明亮日光，窗帘被风吹起，远处天空一道极淡的云带。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；画面左边缘可见：后墙黑板报（空白，文字后期）、储物柜、后门；画面右边缘可见：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，上午明亮日光，窗帘被风吹起，远处天空一道极淡的云带。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：走廊侧窗户与前门；画面左边缘可见：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；画面右边缘可见：后墙黑板报（空白，文字后期）、储物柜、后门；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S12-B｜下午课后·窗外晚霞**（第7、20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，下午课后，窗外泛起晚霞的暖橙光斜射入室。坡道老校园里的普通高中教室：正面黑板与讲台；左侧一排大窗（白色窗帘，可远望港口），知遥和周砚的座位在靠窗；右侧是走廊一侧的窗与前后门；背面是后墙黑板报与储物柜。 正面：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；右侧：走廊侧窗户与前门；背面：后墙黑板报（空白，文字后期）、储物柜、后门；左侧：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌；氛围：吵闹、被围观（手机像鱼群）。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Chenggang No.7 Middle School, Class 3 Grade 11 classroom, after class in the afternoon, warm orange sunset glow slanting in from the windows. an ordinary high-school classroom in an old hillside campus: blackboard and teacher's podium in front; a row of large windows with white curtains on the left looking far over the harbor, Zhiyao's and Zhou Yan's seats by the window; corridor-side windows and front/back doors on the right; back wall with a chalk bulletin board and lockers. Front: blackboard, podium and teacher's desk, clock and PA speaker above the board; right: corridor-side windows and the front door; back: rear chalk bulletin board (blank, text in post), lockers, back door; left: row of large windows with white curtains blowing, the harbor and sea visible far away; desks by the window; above: fluorescent tubes and ceiling fans; ground: terrazzo floor with rows of desks and chairs. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，下午课后，窗外泛起晚霞的暖橙光斜射入室。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；画面左边缘可见：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；画面右边缘可见：走廊侧窗户与前门；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，下午课后，窗外泛起晚霞的暖橙光斜射入室。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：后墙黑板报（空白，文字后期）、储物柜、后门；画面左边缘可见：走廊侧窗户与前门；画面右边缘可见：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，下午课后，窗外泛起晚霞的暖橙光斜射入室。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：一排大窗，白色窗帘被风吹动，窗外远望港口与海；靠窗双人课桌；画面左边缘可见：后墙黑板报（空白，文字后期）、储物柜、后门；画面右边缘可见：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港第七中学·高二（3）班教室，下午课后，窗外泛起晚霞的暖橙光斜射入室。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：走廊侧窗户与前门；画面左边缘可见：黑板、讲台、讲桌、黑板上方挂钟与广播喇叭；画面右边缘可见：后墙黑板报（空白，文字后期）、储物柜、后门；上方：日光灯管与吊扇；地面：水磨石地面，整齐的课桌椅。色调：上午白亮日光、浅绿墙裙、木色课桌。布局与360°全景 S12-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S13 第七中学·教学楼走廊（校报投稿箱／会议室门外）

*School corridor (newspaper submission box / outside the meeting room)*

- **使用场次**：第7、17场
- **原文出处**：第7场：「走廊，投稿箱前。宋佳怡正要把稿纸塞进去，一只手按住了投稿箱的口。」；第7场：「走廊尽头，周砚靠在窗边，手插在藏青外套口袋里」；第17场：「会议室门上的玻璃窗外，宋佳怡的脸一闪，躲开了。」；第17场：「门外，宋佳怡靠在走廊墙边」
- **空间描述**：长直走廊：一侧是教室门与墙（墙上挂木制校报投稿箱），另一侧是一排开向操场/港口的窗；走廊尽头是窗。
- **布局**：
  - 正面：走廊纵深，尽头一扇窗（周砚靠窗处）
  - 右：一排窗户，窗外树与港口方向天空
  - 背面：走廊另一端，楼梯口
  - 左：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）
  - 顶：日光灯
  - 地：水磨石地面
- **色调**：暖橙斜阳（第7场）/冷白（第17场）　**氛围**：围观、对峙
- 注：第7场“拧开桌上借来的签字笔”——走廊里有张桌子[设计补充]：投稿箱下放一张值日桌。

**S13-A｜下午课后斜阳**（第7场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），下午课后，窗外斜阳把走廊染成暖橙。长直走廊：一侧是教室门与墙（墙上挂木制校报投稿箱），另一侧是一排开向操场/港口的窗；走廊尽头是窗。 正面：走廊纵深，尽头一扇窗（周砚靠窗处）；右侧：一排窗户，窗外树与港口方向天空；背面：走廊另一端，楼梯口；左侧：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）；氛围：围观、对峙。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School corridor (newspaper submission box / outside the meeting room), afternoon after class, slanting sun turning the corridor warm orange. a long straight corridor: one side classroom doors and wall with a wooden school-newspaper submission box mounted on it, the other side a row of windows; a window at the far end. Front: corridor depth with a window at the far end (where Zhou Yan leans); right: row of windows, trees and harbor sky outside; back: the other end of the corridor and the stairwell; left: wall: wooden newspaper submission box with slot (blank label), notice board, classroom doors; in scene 17 the meeting-room door with a glass panel; above: fluorescent lights; ground: terrazzo floor. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），下午课后，窗外斜阳把走廊染成暖橙。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：走廊纵深，尽头一扇窗（周砚靠窗处）；画面左边缘可见：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；画面右边缘可见：一排窗户，窗外树与港口方向天空；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），下午课后，窗外斜阳把走廊染成暖橙。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：走廊另一端，楼梯口；画面左边缘可见：一排窗户，窗外树与港口方向天空；画面右边缘可见：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），下午课后，窗外斜阳把走廊染成暖橙。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；画面左边缘可见：走廊另一端，楼梯口；画面右边缘可见：走廊纵深，尽头一扇窗（周砚靠窗处）；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），下午课后，窗外斜阳把走廊染成暖橙。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：一排窗户，窗外树与港口方向天空；画面左边缘可见：走廊纵深，尽头一扇窗（周砚靠窗处）；画面右边缘可见：走廊另一端，楼梯口；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S13-B｜上午·冷色**（第17场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），上午，冷白色调，安静。长直走廊：一侧是教室门与墙（墙上挂木制校报投稿箱），另一侧是一排开向操场/港口的窗；走廊尽头是窗。 正面：走廊纵深，尽头一扇窗（周砚靠窗处）；右侧：一排窗户，窗外树与港口方向天空；背面：走廊另一端，楼梯口；左侧：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）；氛围：围观、对峙。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School corridor (newspaper submission box / outside the meeting room), morning, cool white tones, quiet. a long straight corridor: one side classroom doors and wall with a wooden school-newspaper submission box mounted on it, the other side a row of windows; a window at the far end. Front: corridor depth with a window at the far end (where Zhou Yan leans); right: row of windows, trees and harbor sky outside; back: the other end of the corridor and the stairwell; left: wall: wooden newspaper submission box with slot (blank label), notice board, classroom doors; in scene 17 the meeting-room door with a glass panel; above: fluorescent lights; ground: terrazzo floor. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），上午，冷白色调，安静。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：走廊纵深，尽头一扇窗（周砚靠窗处）；画面左边缘可见：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；画面右边缘可见：一排窗户，窗外树与港口方向天空；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），上午，冷白色调，安静。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：走廊另一端，楼梯口；画面左边缘可见：一排窗户，窗外树与港口方向天空；画面右边缘可见：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），上午，冷白色调，安静。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：墙面：木制校报投稿箱（投信口，标签空白）、公告栏、教室门；第17场为会议室门（门上玻璃窗）；画面左边缘可见：走廊另一端，楼梯口；画面右边缘可见：走廊纵深，尽头一扇窗（周砚靠窗处）；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼走廊（校报投稿箱／会议室门外），上午，冷白色调，安静。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：一排窗户，窗外树与港口方向天空；画面左边缘可见：走廊纵深，尽头一扇窗（周砚靠窗处）；画面右边缘可见：走廊另一端，楼梯口；上方：日光灯；地面：水磨石地面。色调：暖橙斜阳（第7场）/冷白（第17场）。布局与360°全景 S13-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S14 第七中学·教学楼天台（水箱·老式弹簧门·物业监控）

*School rooftop (water tank, old spring door, CCTV)*

- **使用场次**：第10场
- **原文出处**：第10场：「知遥一个人坐在水箱阴影下吃便当……远处是整片港口，老灯塔立在防波堤尽头。」；第10场：「天台门是老式弹簧门，被风“砰”地吹上，从里面锁死了。」；第10场：「拉着她躲进水箱下面那一窄条屋檐」；第10场：「天台角落里有一个物业装的监控摄像头，正对着这里。」
- **空间描述**：水泥天台：一侧是楼梯间小屋和老式铁皮弹簧门；中央偏一侧是架高的水箱，水箱下有一窄条屋檐可避雨；四周矮护墙，远眺整片港口与防波堤尽头的老灯塔；角落立杆上有监控。
- **布局**：
  - 正面：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线
  - 右：天台角落立杆上的物业监控摄像头，晾衣铁架[设计补充]
  - 背面：楼梯间小屋与老式铁皮弹簧门
  - 左：架高的水箱，水箱下一窄条屋檐与阴影
  - 顶：开阔天空
  - 地：灰色水泥地面，排水口
- **色调**：正午白亮→积雨云灰蓝→雨后灰白　**氛围**：开阔→突然被困→亲密
- 注：水箱、门、监控相对位置为[设计补充]（剧本：监控“正对着这里”=水箱屋檐）。

**S14-A｜正午烈日**（第10场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），午休时阳光明晃晃，水箱投下浓重阴影。水泥天台：一侧是楼梯间小屋和老式铁皮弹簧门；中央偏一侧是架高的水箱，水箱下有一窄条屋檐可避雨；四周矮护墙，远眺整片港口与防波堤尽头的老灯塔；角落立杆上有监控。 正面：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；右侧：天台角落立杆上的物业监控摄像头，晾衣铁架；背面：楼梯间小屋与老式铁皮弹簧门；左侧：架高的水箱，水箱下一窄条屋檐与阴影；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白；氛围：开阔→突然被困→亲密。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School rooftop (water tank, old spring door, CCTV), glaring noon sun, deep shadow under the water tank. a concrete rooftop: a small stairwell hut with an old metal spring door on one side; a raised water tank with a narrow strip of eave beneath it to shelter from rain; low parapet walls all around; panoramic view of the whole harbor and the old lighthouse at the end of the breakwater; a CCTV camera on a pole in the corner. Front: beyond the parapet: the whole harbor, fishing boats, the breakwater with the red-white lighthouse at its end, the horizon; right: CCTV camera on a corner pole facing the tank, metal drying rack [design]; back: stairwell hut with an old metal spring door; left: raised water tank with a narrow strip of eave and shade beneath; above: open sky; ground: grey concrete with drains. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），午休时阳光明晃晃，水箱投下浓重阴影。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；画面左边缘可见：架高的水箱，水箱下一窄条屋檐与阴影；画面右边缘可见：天台角落立杆上的物业监控摄像头，晾衣铁架；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），午休时阳光明晃晃，水箱投下浓重阴影。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：楼梯间小屋与老式铁皮弹簧门；画面左边缘可见：天台角落立杆上的物业监控摄像头，晾衣铁架；画面右边缘可见：架高的水箱，水箱下一窄条屋檐与阴影；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），午休时阳光明晃晃，水箱投下浓重阴影。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：架高的水箱，水箱下一窄条屋檐与阴影；画面左边缘可见：楼梯间小屋与老式铁皮弹簧门；画面右边缘可见：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），午休时阳光明晃晃，水箱投下浓重阴影。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：天台角落立杆上的物业监控摄像头，晾衣铁架；画面左边缘可见：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；画面右边缘可见：楼梯间小屋与老式铁皮弹簧门；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S14-B｜突降暴雨**（第10场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），积雨云从海上压过来，天色骤暗，瓢泼大雨，雨幕灰白。水泥天台：一侧是楼梯间小屋和老式铁皮弹簧门；中央偏一侧是架高的水箱，水箱下有一窄条屋檐可避雨；四周矮护墙，远眺整片港口与防波堤尽头的老灯塔；角落立杆上有监控。 正面：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；右侧：天台角落立杆上的物业监控摄像头，晾衣铁架；背面：楼梯间小屋与老式铁皮弹簧门；左侧：架高的水箱，水箱下一窄条屋檐与阴影；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白；氛围：开阔→突然被困→亲密。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School rooftop (water tank, old spring door, CCTV), cumulonimbus rolling in from the sea, sudden darkness, torrential rain, grey-white rain curtains. a concrete rooftop: a small stairwell hut with an old metal spring door on one side; a raised water tank with a narrow strip of eave beneath it to shelter from rain; low parapet walls all around; panoramic view of the whole harbor and the old lighthouse at the end of the breakwater; a CCTV camera on a pole in the corner. Front: beyond the parapet: the whole harbor, fishing boats, the breakwater with the red-white lighthouse at its end, the horizon; right: CCTV camera on a corner pole facing the tank, metal drying rack [design]; back: stairwell hut with an old metal spring door; left: raised water tank with a narrow strip of eave and shade beneath; above: open sky; ground: grey concrete with drains. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），积雨云从海上压过来，天色骤暗，瓢泼大雨，雨幕灰白。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；画面左边缘可见：架高的水箱，水箱下一窄条屋檐与阴影；画面右边缘可见：天台角落立杆上的物业监控摄像头，晾衣铁架；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），积雨云从海上压过来，天色骤暗，瓢泼大雨，雨幕灰白。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：楼梯间小屋与老式铁皮弹簧门；画面左边缘可见：天台角落立杆上的物业监控摄像头，晾衣铁架；画面右边缘可见：架高的水箱，水箱下一窄条屋檐与阴影；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），积雨云从海上压过来，天色骤暗，瓢泼大雨，雨幕灰白。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：架高的水箱，水箱下一窄条屋檐与阴影；画面左边缘可见：楼梯间小屋与老式铁皮弹簧门；画面右边缘可见：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），积雨云从海上压过来，天色骤暗，瓢泼大雨，雨幕灰白。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：天台角落立杆上的物业监控摄像头，晾衣铁架；画面左边缘可见：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；画面右边缘可见：楼梯间小屋与老式铁皮弹簧门；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S14-C｜雨停**（第10场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），雨停，地面积水反光，天光灰白转亮。水泥天台：一侧是楼梯间小屋和老式铁皮弹簧门；中央偏一侧是架高的水箱，水箱下有一窄条屋檐可避雨；四周矮护墙，远眺整片港口与防波堤尽头的老灯塔；角落立杆上有监控。 正面：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；右侧：天台角落立杆上的物业监控摄像头，晾衣铁架；背面：楼梯间小屋与老式铁皮弹簧门；左侧：架高的水箱，水箱下一窄条屋檐与阴影；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白；氛围：开阔→突然被困→亲密。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School rooftop (water tank, old spring door, CCTV), rain stopped, puddles reflecting, grey light brightening. a concrete rooftop: a small stairwell hut with an old metal spring door on one side; a raised water tank with a narrow strip of eave beneath it to shelter from rain; low parapet walls all around; panoramic view of the whole harbor and the old lighthouse at the end of the breakwater; a CCTV camera on a pole in the corner. Front: beyond the parapet: the whole harbor, fishing boats, the breakwater with the red-white lighthouse at its end, the horizon; right: CCTV camera on a corner pole facing the tank, metal drying rack [design]; back: stairwell hut with an old metal spring door; left: raised water tank with a narrow strip of eave and shade beneath; above: open sky; ground: grey concrete with drains. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），雨停，地面积水反光，天光灰白转亮。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；画面左边缘可见：架高的水箱，水箱下一窄条屋檐与阴影；画面右边缘可见：天台角落立杆上的物业监控摄像头，晾衣铁架；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），雨停，地面积水反光，天光灰白转亮。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：楼梯间小屋与老式铁皮弹簧门；画面左边缘可见：天台角落立杆上的物业监控摄像头，晾衣铁架；画面右边缘可见：架高的水箱，水箱下一窄条屋檐与阴影；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），雨停，地面积水反光，天光灰白转亮。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：架高的水箱，水箱下一窄条屋檐与阴影；画面左边缘可见：楼梯间小屋与老式铁皮弹簧门；画面右边缘可见：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·教学楼天台（水箱·老式弹簧门·物业监控），雨停，地面积水反光，天光灰白转亮。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：天台角落立杆上的物业监控摄像头，晾衣铁架；画面左边缘可见：矮护墙外：整片港口、渔船、防波堤与尽头的红白老灯塔、海平线；画面右边缘可见：楼梯间小屋与老式铁皮弹簧门；上方：开阔天空；地面：灰色水泥地面，排水口。色调：正午白亮→积雨云灰蓝→雨后灰白。布局与360°全景 S14-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S15 第七中学·操场跑道

*School running track*

- **使用场次**：第13场
- **原文出处**：第13场：「体育课：周砚的弹幕B提醒“第10天她在跑道摔伤膝盖”，他提前把跑道上的一颗碎石踢开。知遥平安跑完 800 米」
- **空间描述**：坡顶校园的红色塑胶跑道与绿茵场，看台台阶，远处可见海。
- **布局**：
  - 正面：跑道直道延伸，远处终点线
  - 右：水泥看台台阶，远处海
  - 背面：跑道弯道与教学楼
  - 左：绿茵足球场
  - 顶：晴空
  - 地：红色塑胶跑道白线
- **色调**：红、绿、白、蓝天　**氛围**：轻快喜剧（漫画分格蒙太奇）
- 注：全部布局为[设计补充]，剧本只提到跑道、碎石、800米。

**S15-A｜白天体育课**（第13场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·操场跑道，晴朗白天，明快。坡顶校园的红色塑胶跑道与绿茵场，看台台阶，远处可见海。 正面：跑道直道延伸，远处终点线；右侧：水泥看台台阶，远处海；背面：跑道弯道与教学楼；左侧：绿茵足球场；上方：晴空；地面：红色塑胶跑道白线。色调：红、绿、白、蓝天；氛围：轻快喜剧（漫画分格蒙太奇）。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School running track, sunny daytime, bright and cheerful. red rubber running track and green field on the hilltop campus, concrete bleacher steps, sea visible in the distance. Front: the straight of the track stretching to the finish line; right: concrete bleacher steps, sea beyond; back: track curve and the school building; left: green football field; above: clear sky; ground: red rubber track with white lanes. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·操场跑道，晴朗白天，明快。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：跑道直道延伸，远处终点线；画面左边缘可见：绿茵足球场；画面右边缘可见：水泥看台台阶，远处海；上方：晴空；地面：红色塑胶跑道白线。色调：红、绿、白、蓝天。布局与360°全景 S15-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·操场跑道，晴朗白天，明快。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：跑道弯道与教学楼；画面左边缘可见：水泥看台台阶，远处海；画面右边缘可见：绿茵足球场；上方：晴空；地面：红色塑胶跑道白线。色调：红、绿、白、蓝天。布局与360°全景 S15-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·操场跑道，晴朗白天，明快。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：绿茵足球场；画面左边缘可见：跑道弯道与教学楼；画面右边缘可见：跑道直道延伸，远处终点线；上方：晴空；地面：红色塑胶跑道白线。色调：红、绿、白、蓝天。布局与360°全景 S15-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·操场跑道，晴朗白天，明快。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：水泥看台台阶，远处海；画面左边缘可见：跑道直道延伸，远处终点线；画面右边缘可见：跑道弯道与教学楼；上方：晴空；地面：红色塑胶跑道白线。色调：红、绿、白、蓝天。布局与360°全景 S15-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S16 第七中学·楼梯口（课间）

*School stairwell landing*

- **使用场次**：第13场
- **原文出处**：第13场：「第11天他在楼梯被人故意撞，书包里的东西撒了一地……她提前把楼梯口那个故意伸脚的男生叫走问作业。」
- **空间描述**：教学楼楼梯口，宽楼梯，扶手，墙上安全标识（空白）。
- **布局**：
  - 正面：向下的楼梯段
  - 右：墙面，窗
  - 背面：走廊入口
  - 左：扶手栏杆
  - 顶：日光灯
  - 地：水磨石台阶
- **色调**：白天冷白　**氛围**：课间热闹
- 注：全部布局为[设计补充]。

**S16-A｜白天课间**（第13场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·楼梯口（课间），白天课间，窗光。教学楼楼梯口，宽楼梯，扶手，墙上安全标识（空白）。 正面：向下的楼梯段；右侧：墙面，窗；背面：走廊入口；左侧：扶手栏杆；上方：日光灯；地面：水磨石台阶。色调：白天冷白；氛围：课间热闹。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School stairwell landing, daytime break, window light. a school stairwell landing with wide stairs, handrails and blank safety signs. Front: stairs going down; right: wall with a window; back: corridor entrance; left: handrail; above: fluorescent light; ground: terrazzo steps. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·楼梯口（课间），白天课间，窗光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：向下的楼梯段；画面左边缘可见：扶手栏杆；画面右边缘可见：墙面，窗；上方：日光灯；地面：水磨石台阶。色调：白天冷白。布局与360°全景 S16-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·楼梯口（课间），白天课间，窗光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：走廊入口；画面左边缘可见：墙面，窗；画面右边缘可见：扶手栏杆；上方：日光灯；地面：水磨石台阶。色调：白天冷白。布局与360°全景 S16-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·楼梯口（课间），白天课间，窗光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：扶手栏杆；画面左边缘可见：走廊入口；画面右边缘可见：向下的楼梯段；上方：日光灯；地面：水磨石台阶。色调：白天冷白。布局与360°全景 S16-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学·楼梯口（课间），白天课间，窗光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：墙面，窗；画面左边缘可见：向下的楼梯段；画面右边缘可见：走廊入口；上方：日光灯；地面：水磨石台阶。色调：白天冷白。布局与360°全景 S16-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S17 第七中学会议室（长桌·窗帘半拉·角落监控）

*School meeting room (long table, half-drawn curtains, corner CCTV)*

- **使用场次**：第17场
- **原文出处**：第17场：「会议室，长桌。窗帘半拉，阳光切成一条条。桌上放着一台笔记本电脑」；第17场：「会议室角落里装着一个监控。」；第17场：「夏红梅和知遥坐在靠门的位置。」；第17场：「会议室门上的玻璃窗外」
- **空间描述**：长方形会议室：中间一张长会议桌；正面是窗（百叶/布窗帘半拉，阳光成条）；周砚与周静坐一侧、钱主任与老何坐对面，夏家母女坐靠门一端；桌上笔记本电脑屏幕朝向众人；角落高处监控；墙上空调。
- **布局**：
  - 正面：窗户，窗帘半拉，阳光切成一条条落在桌上
  - 右：墙面：白板/锦旗框（空白）[设计补充]、饮水机
  - 背面：会议室门（门上有玻璃小窗），门旁两把椅子
  - 左：墙面：挂式空调、角落高处监控摄像头
  - 顶：方格吊顶与日光灯
  - 地：灰色地胶，长会议桌两侧椅子
- **色调**：冷色调、灰白、条状暖阳　**氛围**：压抑、对称、审判
- 注：座次为剧本原文；墙面陈设为[设计补充]。

**S17-A｜上午10点·冷色对称**（第17场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学会议室（长桌·窗帘半拉·角落监控），上午，冷色调，窗帘缝里的阳光切成条，空调低频嗡鸣的压抑感。长方形会议室：中间一张长会议桌；正面是窗（百叶/布窗帘半拉，阳光成条）；周砚与周静坐一侧、钱主任与老何坐对面，夏家母女坐靠门一端；桌上笔记本电脑屏幕朝向众人；角落高处监控；墙上空调。 正面：窗户，窗帘半拉，阳光切成一条条落在桌上；右侧：墙面：白板/锦旗框（空白）、饮水机；背面：会议室门（门上有玻璃小窗），门旁两把椅子；左侧：墙面：挂式空调、角落高处监控摄像头；上方：方格吊顶与日光灯；地面：灰色地胶，长会议桌两侧椅子。色调：冷色调、灰白、条状暖阳；氛围：压抑、对称、审判。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School meeting room (long table, half-drawn curtains, corner CCTV), morning, cold palette, stripes of sun through curtain gaps, oppressive. a rectangular meeting room with a long table in the middle; windows straight ahead with curtains half-drawn so sunlight falls in stripes; Zhou Yan and his mother on one side, the director and the homeroom teacher on the other, the Xia mother and daughter at the end near the door; a laptop on the table facing the room; a CCTV camera high in a corner; wall-mounted air conditioner. Front: windows with half-drawn curtains, sunlight cut into stripes across the table; right: wall: whiteboard and framed pennants (blank) [design], water dispenser; back: meeting-room door with a small glass panel, two chairs by it; left: wall: wall-mounted AC unit, CCTV camera high in the corner; above: grid ceiling with fluorescent panels; ground: grey vinyl floor, chairs on both sides of the long table. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学会议室（长桌·窗帘半拉·角落监控），上午，冷色调，窗帘缝里的阳光切成条，空调低频嗡鸣的压抑感。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窗户，窗帘半拉，阳光切成一条条落在桌上；画面左边缘可见：墙面：挂式空调、角落高处监控摄像头；画面右边缘可见：墙面：白板/锦旗框（空白）、饮水机；上方：方格吊顶与日光灯；地面：灰色地胶，长会议桌两侧椅子。色调：冷色调、灰白、条状暖阳。布局与360°全景 S17-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学会议室（长桌·窗帘半拉·角落监控），上午，冷色调，窗帘缝里的阳光切成条，空调低频嗡鸣的压抑感。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：会议室门（门上有玻璃小窗），门旁两把椅子；画面左边缘可见：墙面：白板/锦旗框（空白）、饮水机；画面右边缘可见：墙面：挂式空调、角落高处监控摄像头；上方：方格吊顶与日光灯；地面：灰色地胶，长会议桌两侧椅子。色调：冷色调、灰白、条状暖阳。布局与360°全景 S17-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学会议室（长桌·窗帘半拉·角落监控），上午，冷色调，窗帘缝里的阳光切成条，空调低频嗡鸣的压抑感。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：墙面：挂式空调、角落高处监控摄像头；画面左边缘可见：会议室门（门上有玻璃小窗），门旁两把椅子；画面右边缘可见：窗户，窗帘半拉，阳光切成一条条落在桌上；上方：方格吊顶与日光灯；地面：灰色地胶，长会议桌两侧椅子。色调：冷色调、灰白、条状暖阳。布局与360°全景 S17-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学会议室（长桌·窗帘半拉·角落监控），上午，冷色调，窗帘缝里的阳光切成条，空调低频嗡鸣的压抑感。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：墙面：白板/锦旗框（空白）、饮水机；画面左边缘可见：窗户，窗帘半拉，阳光切成一条条落在桌上；画面右边缘可见：会议室门（门上有玻璃小窗），门旁两把椅子；上方：方格吊顶与日光灯；地面：灰色地胶，长会议桌两侧椅子。色调：冷色调、灰白、条状暖阳。布局与360°全景 S17-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S18 第七中学后门与门外长坡道（两侧老榕树）

*School back gate and the long downhill slope lined with old banyans*

- **使用场次**：第16、17场
- **原文出处**：第16场：「后门没什么人，只有一条往下的长坡道，两侧是老榕树。」；第16场：「整个人夸张地摔倒在坡道上」；第16场：「正门那边保安太凶，咱们走后门」；第17场：「走出校门，知遥的手机亮了一下」
- **空间描述**：校园后门（铁栅门、门柱）外一条向下的长坡道，两侧老榕树气根垂挂，坡道下方通向街区。
- **布局**：
  - 正面：长坡道向下延伸，尽头街区与远处海
  - 右：老榕树、路灯杆、护栏
  - 背面：学校后门：铁栅门与门柱、门内教学楼
  - 左：老榕树、气根、矮石墙
  - 顶：榕树树冠间漏下的天空
  - 地：水泥坡道，落叶
- **色调**：傍晚暖光+榕树斑驳阴影　**氛围**：躲不开、围观
- 注：学校正门在第16场被提及、第17场“走出校门”，剧本无描写，S18-B 为[设计补充]，可不出图。

**S18-A｜放学·下午5:10**（第16场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），下午五点，斜阳透过榕树叶，斑驳光影。校园后门（铁栅门、门柱）外一条向下的长坡道，两侧老榕树气根垂挂，坡道下方通向街区。 正面：长坡道向下延伸，尽头街区与远处海；右侧：老榕树、路灯杆、护栏；背面：学校后门：铁栅门与门柱、门内教学楼；左侧：老榕树、气根、矮石墙；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影；氛围：躲不开、围观。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School back gate and the long downhill slope lined with old banyans, 5 pm, low sun through banyan leaves, dappled light. the school's back gate (iron bar gate between pillars) opening onto a long downhill slope with old banyan trees and hanging aerial roots on both sides, leading down to the streets. Front: the long slope descending to the streets and distant sea; right: old banyans, lamp post, railing; back: the back gate: iron gate and pillars, school building beyond; left: old banyan trees, aerial roots, low stone wall; above: sky through the banyan canopy; ground: concrete slope with fallen leaves. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），下午五点，斜阳透过榕树叶，斑驳光影。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：长坡道向下延伸，尽头街区与远处海；画面左边缘可见：老榕树、气根、矮石墙；画面右边缘可见：老榕树、路灯杆、护栏；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），下午五点，斜阳透过榕树叶，斑驳光影。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：学校后门：铁栅门与门柱、门内教学楼；画面左边缘可见：老榕树、路灯杆、护栏；画面右边缘可见：老榕树、气根、矮石墙；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），下午五点，斜阳透过榕树叶，斑驳光影。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：老榕树、气根、矮石墙；画面左边缘可见：学校后门：铁栅门与门柱、门内教学楼；画面右边缘可见：长坡道向下延伸，尽头街区与远处海；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），下午五点，斜阳透过榕树叶，斑驳光影。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：老榕树、路灯杆、护栏；画面左边缘可见：长坡道向下延伸，尽头街区与远处海；画面右边缘可见：学校后门：铁栅门与门柱、门内教学楼；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S18-B｜正门（仅提及）**（第17场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），上午，学校正门，保安亭。校园后门（铁栅门、门柱）外一条向下的长坡道，两侧老榕树气根垂挂，坡道下方通向街区。 正面：长坡道向下延伸，尽头街区与远处海；右侧：老榕树、路灯杆、护栏；背面：学校后门：铁栅门与门柱、门内教学楼；左侧：老榕树、气根、矮石墙；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影；氛围：躲不开、围观。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, School back gate and the long downhill slope lined with old banyans, morning, main school gate with guard booth [design]. the school's back gate (iron bar gate between pillars) opening onto a long downhill slope with old banyan trees and hanging aerial roots on both sides, leading down to the streets. Front: the long slope descending to the streets and distant sea; right: old banyans, lamp post, railing; back: the back gate: iron gate and pillars, school building beyond; left: old banyan trees, aerial roots, low stone wall; above: sky through the banyan canopy; ground: concrete slope with fallen leaves. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），上午，学校正门，保安亭。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：长坡道向下延伸，尽头街区与远处海；画面左边缘可见：老榕树、气根、矮石墙；画面右边缘可见：老榕树、路灯杆、护栏；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），上午，学校正门，保安亭。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：学校后门：铁栅门与门柱、门内教学楼；画面左边缘可见：老榕树、路灯杆、护栏；画面右边缘可见：老榕树、气根、矮石墙；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），上午，学校正门，保安亭。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：老榕树、气根、矮石墙；画面左边缘可见：学校后门：铁栅门与门柱、门内教学楼；画面右边缘可见：长坡道向下延伸，尽头街区与远处海；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，第七中学后门与门外长坡道（两侧老榕树），上午，学校正门，保安亭。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：老榕树、路灯杆、护栏；画面左边缘可见：长坡道向下延伸，尽头街区与远处海；画面右边缘可见：学校后门：铁栅门与门柱、门内教学楼；上方：榕树树冠间漏下的天空；地面：水泥坡道，落叶。色调：傍晚暖光+榕树斑驳阴影。布局与360°全景 S18-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S19 骑楼小巷（补习班回家路·巷口小超市监控·窄巷）

*Arcade lanes on the way home from cram school (mini-mart CCTV at alley mouth, narrow alley)*

- **使用场次**：第8场
- **原文出处**：第8场：「补习班下课，知遥背着书包走在骑楼下。夕阳把柱子的影子拉得很长。」；第8场：「巷口一家小超市门口装着监控。」；第8场：「窄巷里，知遥猛地转身，背靠墙」；第8场：「一辆送外卖的电动车逆行冲进窄巷」
- **空间描述**：两段相连：①骑楼拱廊下的人行道，柱子投下长影；②巷口一家小超市（门口挂监控）旁拐进的窄巷，两侧是墙，宽度仅容电动车通过。全景机位放在窄巷口。
- **布局**：
  - 正面：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）
  - 右：老墙、水管、贴纸广告（空白）
  - 背面：骑楼拱廊人行道，长长的柱影，远处跟随的路
  - 左：巷口小超市门面（招牌空白），门楣上的监控摄像头
  - 顶：骑楼檐口与一线天空
  - 地：石板/水泥路面
- **色调**：夕阳橙、长影紫　**氛围**：被跟踪的不安→角度决定真相
- 注：小超市与窄巷相对位置为[设计补充]。

**S19-A｜傍晚6:10夕阳**（第8场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），傍晚夕阳，橙色低光，影子拉得很长。两段相连：①骑楼拱廊下的人行道，柱子投下长影；②巷口一家小超市（门口挂监控）旁拐进的窄巷，两侧是墙，宽度仅容电动车通过。全景机位放在窄巷口。 正面：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；右侧：老墙、水管、贴纸广告（空白）；背面：骑楼拱廊人行道，长长的柱影，远处跟随的路；左侧：巷口小超市门面（招牌空白），门楣上的监控摄像头；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫；氛围：被跟踪的不安→角度决定真相。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Arcade lanes on the way home from cram school (mini-mart CCTV at alley mouth, narrow alley), 6 pm sunset, low orange light, long shadows. two connected parts: (1) the arcade walkway with long shadows from its pillars; (2) a narrow alley turning off beside a small mini-mart whose entrance has a CCTV camera, walls on both sides, just wide enough for a scooter. Panorama camera at the alley mouth. Front: the narrow alley receding, walls on both sides, a corner at the end where the scooter bursts out; right: old wall, pipes, blank flyers; back: the arcade walkway with long pillar shadows; left: mini-mart frontage at the alley mouth (blank sign), CCTV camera above its door; above: arcade eaves and a strip of sky; ground: stone and concrete paving. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），傍晚夕阳，橙色低光，影子拉得很长。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；画面左边缘可见：巷口小超市门面（招牌空白），门楣上的监控摄像头；画面右边缘可见：老墙、水管、贴纸广告（空白）；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），傍晚夕阳，橙色低光，影子拉得很长。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：骑楼拱廊人行道，长长的柱影，远处跟随的路；画面左边缘可见：老墙、水管、贴纸广告（空白）；画面右边缘可见：巷口小超市门面（招牌空白），门楣上的监控摄像头；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），傍晚夕阳，橙色低光，影子拉得很长。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：巷口小超市门面（招牌空白），门楣上的监控摄像头；画面左边缘可见：骑楼拱廊人行道，长长的柱影，远处跟随的路；画面右边缘可见：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），傍晚夕阳，橙色低光，影子拉得很长。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：老墙、水管、贴纸广告（空白）；画面左边缘可见：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；画面右边缘可见：骑楼拱廊人行道，长长的柱影，远处跟随的路；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S19-B｜监控俯拍黑白画面**（第8场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），监控视角：俯拍黑白粗颗粒画面。两段相连：①骑楼拱廊下的人行道，柱子投下长影；②巷口一家小超市（门口挂监控）旁拐进的窄巷，两侧是墙，宽度仅容电动车通过。全景机位放在窄巷口。 正面：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；右侧：老墙、水管、贴纸广告（空白）；背面：骑楼拱廊人行道，长长的柱影，远处跟随的路；左侧：巷口小超市门面（招牌空白），门楣上的监控摄像头；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫；氛围：被跟踪的不安→角度决定真相。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Arcade lanes on the way home from cram school (mini-mart CCTV at alley mouth, narrow alley), CCTV view: high-angle black-and-white grainy footage. two connected parts: (1) the arcade walkway with long shadows from its pillars; (2) a narrow alley turning off beside a small mini-mart whose entrance has a CCTV camera, walls on both sides, just wide enough for a scooter. Panorama camera at the alley mouth. Front: the narrow alley receding, walls on both sides, a corner at the end where the scooter bursts out; right: old wall, pipes, blank flyers; back: the arcade walkway with long pillar shadows; left: mini-mart frontage at the alley mouth (blank sign), CCTV camera above its door; above: arcade eaves and a strip of sky; ground: stone and concrete paving. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），监控视角：俯拍黑白粗颗粒画面。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；画面左边缘可见：巷口小超市门面（招牌空白），门楣上的监控摄像头；画面右边缘可见：老墙、水管、贴纸广告（空白）；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），监控视角：俯拍黑白粗颗粒画面。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：骑楼拱廊人行道，长长的柱影，远处跟随的路；画面左边缘可见：老墙、水管、贴纸广告（空白）；画面右边缘可见：巷口小超市门面（招牌空白），门楣上的监控摄像头；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），监控视角：俯拍黑白粗颗粒画面。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：巷口小超市门面（招牌空白），门楣上的监控摄像头；画面左边缘可见：骑楼拱廊人行道，长长的柱影，远处跟随的路；画面右边缘可见：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，骑楼小巷（补习班回家路·巷口小超市监控·窄巷），监控视角：俯拍黑白粗颗粒画面。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：老墙、水管、贴纸广告（空白）；画面左边缘可见：窄巷纵深，两侧墙，尽头拐角（电动车从这里冲出）；画面右边缘可见：骑楼拱廊人行道，长长的柱影，远处跟随的路；上方：骑楼檐口与一线天空；地面：石板/水泥路面。色调：夕阳橙、长影紫。布局与360°全景 S19-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S20 通往海边的坡道／灯塔堤路口

*Slope down to the sea / junction to the lighthouse breakwater*

- **使用场次**：第8场
- **原文出处**：第8场：「黄雨衣蹦蹦跳跳消失在通往海边的坡道尽头。（这一段没有监控，没有弹幕。）」；第8场：「地点：从补习班回家的骑楼小巷 → 灯塔堤路口」
- **空间描述**：巷口外一条通往海边的下坡路，尽头是海和防波堤的入口。
- **布局**：
  - 正面：下坡尽头：海面与防波堤入口、远处灯塔
  - 右：护栏与海岸礁石
  - 背面：坡道上方的巷口与骑楼
  - 左：矮墙与渔具棚
  - 顶：暮色天空
  - 地：下坡水泥路
- **色调**：暮色橙紫　**氛围**：无镜头、安静
- 注：细节为[设计补充]。

**S20-A｜黄昏**（第8场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，通往海边的坡道／灯塔堤路口，黄昏，天快黑，暮色。巷口外一条通往海边的下坡路，尽头是海和防波堤的入口。 正面：下坡尽头：海面与防波堤入口、远处灯塔；右侧：护栏与海岸礁石；背面：坡道上方的巷口与骑楼；左侧：矮墙与渔具棚；上方：暮色天空；地面：下坡水泥路。色调：暮色橙紫；氛围：无镜头、安静。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Slope down to the sea / junction to the lighthouse breakwater, dusk, nearly dark. a downhill road from the alley mouth to the sea, ending at the entrance of the breakwater. Front: bottom of the slope: the sea, breakwater entrance, lighthouse; right: railing and shoreline rocks; back: alley mouth and arcades uphill; left: low wall and fishing-gear shed; above: dusk sky; ground: sloping concrete road. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，通往海边的坡道／灯塔堤路口，黄昏，天快黑，暮色。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：下坡尽头：海面与防波堤入口、远处灯塔；画面左边缘可见：矮墙与渔具棚；画面右边缘可见：护栏与海岸礁石；上方：暮色天空；地面：下坡水泥路。色调：暮色橙紫。布局与360°全景 S20-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，通往海边的坡道／灯塔堤路口，黄昏，天快黑，暮色。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：坡道上方的巷口与骑楼；画面左边缘可见：护栏与海岸礁石；画面右边缘可见：矮墙与渔具棚；上方：暮色天空；地面：下坡水泥路。色调：暮色橙紫。布局与360°全景 S20-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，通往海边的坡道／灯塔堤路口，黄昏，天快黑，暮色。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：矮墙与渔具棚；画面左边缘可见：坡道上方的巷口与骑楼；画面右边缘可见：下坡尽头：海面与防波堤入口、远处灯塔；上方：暮色天空；地面：下坡水泥路。色调：暮色橙紫。布局与360°全景 S20-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，通往海边的坡道／灯塔堤路口，黄昏，天快黑，暮色。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：护栏与海岸礁石；画面左边缘可见：下坡尽头：海面与防波堤入口、远处灯塔；画面右边缘可见：坡道上方的巷口与骑楼；上方：暮色天空；地面：下坡水泥路。色调：暮色橙紫。布局与360°全景 S20-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S21 澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘）

*Old lighthouse breakwater, full length (open sea and tetrapods on the left, typhoon shelter on the right)*

- **使用场次**：第1、12、15、22场
- **原文出处**：第12场：「防波堤像一条灰白色的长臂伸进海里。堤的左边是外海，浪一层层拍在消波块上，碎成白沫；右边是平静的避风塘，停着十几条小渔船。尽头是红白相间的老灯塔」；第22场：「堤中段停着一辆白色面包车，车顶上架着补光灯。」；第1场：「画框里是夜色、暴雨和翻起白沫的墨绿色浪头。」；第15场：「从这里看过去，堤像一条细线，把海分成两半。」
- **空间描述**：一条灰白色水泥长堤伸进海里（以面向灯塔为正方向）：左侧外海，堆满消波块；右侧避风塘，停十几条小渔船；堤面宽度可停面包车；尽头是红白相间的老灯塔。
- **布局**：
  - 正面：堤面纵深，尽头红白相间老灯塔与塔下石台阶
  - 右：避风塘：平静水面，十几条小渔船，远处码头
  - 背面：堤的根部，岸上的渔港与澄港城区坡地
  - 左：外海：浪拍消波块碎成白沫，开阔海平线
  - 顶：天空
  - 地：灰白水泥堤面，低矮护墩[设计补充]
- **色调**：灰白堤、红白灯塔、外海墨绿、避风塘蓝　**氛围**：两侧对立的地理：外海=死，避风塘=有救
- 注：左外海/右避风塘以“面向灯塔”为准，剧本第12、22场一致。
- 注：第22场“通往灯塔的那一段堤面已经被浪淹了一半”为变体C的状态。
- 注：已有参考：locations/sheet_澄港老灯塔防波堤.jpg。

**S21-A｜日落前（第9天 17:40）**（第12场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），日落前，夕阳将沉入海平线，金橙逆光，灯塔亮起第一束光。一条灰白色水泥长堤伸进海里（以面向灯塔为正方向）：左侧外海，堆满消波块；右侧避风塘，停十几条小渔船；堤面宽度可停面包车；尽头是红白相间的老灯塔。 正面：堤面纵深，尽头红白相间老灯塔与塔下石台阶；右侧：避风塘：平静水面，十几条小渔船，远处码头；背面：堤的根部，岸上的渔港与澄港城区坡地；左侧：外海：浪拍消波块碎成白沫，开阔海平线；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝；氛围：两侧对立的地理：外海=死，避风塘=有救。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Old lighthouse breakwater, full length (open sea and tetrapods on the left, typhoon shelter on the right), just before sunset, the sun touching the horizon, golden-orange backlight, lighthouse beam switching on. a long grey-white concrete breakwater stretching into the sea (facing the lighthouse as forward): open sea with piled concrete tetrapods on the left; calm typhoon-shelter harbor with a dozen small fishing boats on the right; the deck is wide enough for a van; the red-and-white striped old lighthouse at its end. Front: the breakwater deck receding to the red-and-white lighthouse and the stone steps at its base; right: typhoon shelter: calm water, a dozen small fishing boats, the distant pier; back: the root of the breakwater, the fishing port and hillside town; left: open sea: waves smashing into tetrapods in white foam, open horizon; above: sky; ground: grey-white concrete deck with low bollards [design]. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），日落前，夕阳将沉入海平线，金橙逆光，灯塔亮起第一束光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：堤面纵深，尽头红白相间老灯塔与塔下石台阶；画面左边缘可见：外海：浪拍消波块碎成白沫，开阔海平线；画面右边缘可见：避风塘：平静水面，十几条小渔船，远处码头；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），日落前，夕阳将沉入海平线，金橙逆光，灯塔亮起第一束光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：堤的根部，岸上的渔港与澄港城区坡地；画面左边缘可见：避风塘：平静水面，十几条小渔船，远处码头；画面右边缘可见：外海：浪拍消波块碎成白沫，开阔海平线；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），日落前，夕阳将沉入海平线，金橙逆光，灯塔亮起第一束光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：外海：浪拍消波块碎成白沫，开阔海平线；画面左边缘可见：堤的根部，岸上的渔港与澄港城区坡地；画面右边缘可见：堤面纵深，尽头红白相间老灯塔与塔下石台阶；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），日落前，夕阳将沉入海平线，金橙逆光，灯塔亮起第一束光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：避风塘：平静水面，十几条小渔船，远处码头；画面左边缘可见：堤面纵深，尽头红白相间老灯塔与塔下石台阶；画面右边缘可见：堤的根部，岸上的渔港与澄港城区坡地；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S21-B｜黄昏远景（从码头看）**（第15场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），黄昏远景，堤如一条细线，海面铺满碎金。一条灰白色水泥长堤伸进海里（以面向灯塔为正方向）：左侧外海，堆满消波块；右侧避风塘，停十几条小渔船；堤面宽度可停面包车；尽头是红白相间的老灯塔。 正面：堤面纵深，尽头红白相间老灯塔与塔下石台阶；右侧：避风塘：平静水面，十几条小渔船，远处码头；背面：堤的根部，岸上的渔港与澄港城区坡地；左侧：外海：浪拍消波块碎成白沫，开阔海平线；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝；氛围：两侧对立的地理：外海=死，避风塘=有救。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Old lighthouse breakwater, full length (open sea and tetrapods on the left, typhoon shelter on the right), dusk distant view, the breakwater a thin line, sea covered in broken gold. a long grey-white concrete breakwater stretching into the sea (facing the lighthouse as forward): open sea with piled concrete tetrapods on the left; calm typhoon-shelter harbor with a dozen small fishing boats on the right; the deck is wide enough for a van; the red-and-white striped old lighthouse at its end. Front: the breakwater deck receding to the red-and-white lighthouse and the stone steps at its base; right: typhoon shelter: calm water, a dozen small fishing boats, the distant pier; back: the root of the breakwater, the fishing port and hillside town; left: open sea: waves smashing into tetrapods in white foam, open horizon; above: sky; ground: grey-white concrete deck with low bollards [design]. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），黄昏远景，堤如一条细线，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：堤面纵深，尽头红白相间老灯塔与塔下石台阶；画面左边缘可见：外海：浪拍消波块碎成白沫，开阔海平线；画面右边缘可见：避风塘：平静水面，十几条小渔船，远处码头；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），黄昏远景，堤如一条细线，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：堤的根部，岸上的渔港与澄港城区坡地；画面左边缘可见：避风塘：平静水面，十几条小渔船，远处码头；画面右边缘可见：外海：浪拍消波块碎成白沫，开阔海平线；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），黄昏远景，堤如一条细线，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：外海：浪拍消波块碎成白沫，开阔海平线；画面左边缘可见：堤的根部，岸上的渔港与澄港城区坡地；画面右边缘可见：堤面纵深，尽头红白相间老灯塔与塔下石台阶；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），黄昏远景，堤如一条细线，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：避风塘：平静水面，十几条小渔船，远处码头；画面左边缘可见：堤面纵深，尽头红白相间老灯塔与塔下石台阶；画面右边缘可见：堤的根部，岸上的渔港与澄港城区坡地；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S21-C｜台风夜（第17天 21:38–21:47）**（第1、22场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），台风夜，暴雨如钢针，外海浪墙三四层楼高砸在消波块上，避风塘也在翻涌，灯塔光在雨幕里一圈圈扫过，闪电白、冷蓝、墨绿。一条灰白色水泥长堤伸进海里（以面向灯塔为正方向）：左侧外海，堆满消波块；右侧避风塘，停十几条小渔船；堤面宽度可停面包车；尽头是红白相间的老灯塔。 正面：堤面纵深，尽头红白相间老灯塔与塔下石台阶；右侧：避风塘：平静水面，十几条小渔船，远处码头；背面：堤的根部，岸上的渔港与澄港城区坡地；左侧：外海：浪拍消波块碎成白沫，开阔海平线；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝；氛围：两侧对立的地理：外海=死，避风塘=有救。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Old lighthouse breakwater, full length (open sea and tetrapods on the left, typhoon shelter on the right), typhoon night, rain like steel needles, three-to-four-storey wave walls smashing the tetrapods on the open-sea side, the shelter side churning too, lighthouse beam sweeping through the rain, lightning white, cold blue and dark green. a long grey-white concrete breakwater stretching into the sea (facing the lighthouse as forward): open sea with piled concrete tetrapods on the left; calm typhoon-shelter harbor with a dozen small fishing boats on the right; the deck is wide enough for a van; the red-and-white striped old lighthouse at its end. Front: the breakwater deck receding to the red-and-white lighthouse and the stone steps at its base; right: typhoon shelter: calm water, a dozen small fishing boats, the distant pier; back: the root of the breakwater, the fishing port and hillside town; left: open sea: waves smashing into tetrapods in white foam, open horizon; above: sky; ground: grey-white concrete deck with low bollards [design]. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），台风夜，暴雨如钢针，外海浪墙三四层楼高砸在消波块上，避风塘也在翻涌，灯塔光在雨幕里一圈圈扫过，闪电白、冷蓝、墨绿。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：堤面纵深，尽头红白相间老灯塔与塔下石台阶；画面左边缘可见：外海：浪拍消波块碎成白沫，开阔海平线；画面右边缘可见：避风塘：平静水面，十几条小渔船，远处码头；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），台风夜，暴雨如钢针，外海浪墙三四层楼高砸在消波块上，避风塘也在翻涌，灯塔光在雨幕里一圈圈扫过，闪电白、冷蓝、墨绿。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：堤的根部，岸上的渔港与澄港城区坡地；画面左边缘可见：避风塘：平静水面，十几条小渔船，远处码头；画面右边缘可见：外海：浪拍消波块碎成白沫，开阔海平线；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），台风夜，暴雨如钢针，外海浪墙三四层楼高砸在消波块上，避风塘也在翻涌，灯塔光在雨幕里一圈圈扫过，闪电白、冷蓝、墨绿。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：外海：浪拍消波块碎成白沫，开阔海平线；画面左边缘可见：堤的根部，岸上的渔港与澄港城区坡地；画面右边缘可见：堤面纵深，尽头红白相间老灯塔与塔下石台阶；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，澄港老灯塔防波堤·堤面全段（左外海消波块／右避风塘），台风夜，暴雨如钢针，外海浪墙三四层楼高砸在消波块上，避风塘也在翻涌，灯塔光在雨幕里一圈圈扫过，闪电白、冷蓝、墨绿。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：避风塘：平静水面，十几条小渔船，远处码头；画面左边缘可见：堤面纵深，尽头红白相间老灯塔与塔下石台阶；画面右边缘可见：堤的根部，岸上的渔港与澄港城区坡地；上方：天空；地面：灰白水泥堤面，低矮护墩。色调：灰白堤、红白灯塔、外海墨绿、避风塘蓝。布局与360°全景 S21-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S22 老灯塔底部（石缝·石台阶·小石台）

*Base of the old lighthouse (rock crevice, stone steps, small ledge)*

- **使用场次**：第12、22、25场
- **原文出处**：第12场：「一只胖橘猫蹲在灯塔底下的石缝口……周砚已经坐在台阶上了」；第8场：「住在灯塔底下的石头缝里」；第22场：「他被困在高处台阶下的一小块石台上」；第22场：「把他往灯塔下那几级通往高处平台的石台阶上推」
- **空间描述**：红白灯塔塔基：塔基旁礁石间有一道石缝（猫窝）；几级石台阶贴着塔身通往高处观景平台；台阶下有一小块石台。
- **布局**：
  - 正面：塔身与贴塔身向上的几级石台阶
  - 右：避风塘一侧，礁石间的石缝口（猫窝），小石台
  - 背面：回望堤面纵深与岸上城市
  - 左：外海一侧礁石、消波块
  - 顶：灯塔塔身上部与灯室
  - 地：湿石面
- **色调**：红白塔身、灰石、海色　**氛围**：无镜头的秘密基地／台风夜的绝境
- 注：石缝在避风塘一侧为[设计补充]；第25场“豆豆和橘猫”静帧未写地点，暂放此处[设计补充]。

**S22-A｜日落前**（第12场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），日落前金色逆光，海风。红白灯塔塔基：塔基旁礁石间有一道石缝（猫窝）；几级石台阶贴着塔身通往高处观景平台；台阶下有一小块石台。 正面：塔身与贴塔身向上的几级石台阶；右侧：避风塘一侧，礁石间的石缝口（猫窝），小石台；背面：回望堤面纵深与岸上城市；左侧：外海一侧礁石、消波块；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色；氛围：无镜头的秘密基地／台风夜的绝境。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Base of the old lighthouse (rock crevice, stone steps, small ledge), golden backlight before sunset, sea breeze. the base of the red-and-white lighthouse: a crevice between rocks beside it (the cat's den); a few stone steps along the tower lead up to the high viewing platform; a small stone ledge below the steps. Front: the tower and the stone steps climbing along it; right: shelter side, the crevice between rocks (cat's den) and a small ledge; back: looking back along the breakwater toward town; left: open-sea side rocks and tetrapods; above: upper tower and lamp room; ground: wet stone. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），日落前金色逆光，海风。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：塔身与贴塔身向上的几级石台阶；画面左边缘可见：外海一侧礁石、消波块；画面右边缘可见：避风塘一侧，礁石间的石缝口（猫窝），小石台；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），日落前金色逆光，海风。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：回望堤面纵深与岸上城市；画面左边缘可见：避风塘一侧，礁石间的石缝口（猫窝），小石台；画面右边缘可见：外海一侧礁石、消波块；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），日落前金色逆光，海风。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：外海一侧礁石、消波块；画面左边缘可见：回望堤面纵深与岸上城市；画面右边缘可见：塔身与贴塔身向上的几级石台阶；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），日落前金色逆光，海风。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：避风塘一侧，礁石间的石缝口（猫窝），小石台；画面左边缘可见：塔身与贴塔身向上的几级石台阶；画面右边缘可见：回望堤面纵深与岸上城市；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S22-B｜台风夜·被浪淹半**（第22场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），台风夜，暴雨，堤面被浪淹了一半，灯塔光扫过。红白灯塔塔基：塔基旁礁石间有一道石缝（猫窝）；几级石台阶贴着塔身通往高处观景平台；台阶下有一小块石台。 正面：塔身与贴塔身向上的几级石台阶；右侧：避风塘一侧，礁石间的石缝口（猫窝），小石台；背面：回望堤面纵深与岸上城市；左侧：外海一侧礁石、消波块；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色；氛围：无镜头的秘密基地／台风夜的绝境。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Base of the old lighthouse (rock crevice, stone steps, small ledge), typhoon night, torrential rain, half-flooded deck, lighthouse beam sweeping. the base of the red-and-white lighthouse: a crevice between rocks beside it (the cat's den); a few stone steps along the tower lead up to the high viewing platform; a small stone ledge below the steps. Front: the tower and the stone steps climbing along it; right: shelter side, the crevice between rocks (cat's den) and a small ledge; back: looking back along the breakwater toward town; left: open-sea side rocks and tetrapods; above: upper tower and lamp room; ground: wet stone. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），台风夜，暴雨，堤面被浪淹了一半，灯塔光扫过。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：塔身与贴塔身向上的几级石台阶；画面左边缘可见：外海一侧礁石、消波块；画面右边缘可见：避风塘一侧，礁石间的石缝口（猫窝），小石台；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），台风夜，暴雨，堤面被浪淹了一半，灯塔光扫过。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：回望堤面纵深与岸上城市；画面左边缘可见：避风塘一侧，礁石间的石缝口（猫窝），小石台；画面右边缘可见：外海一侧礁石、消波块；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），台风夜，暴雨，堤面被浪淹了一半，灯塔光扫过。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：外海一侧礁石、消波块；画面左边缘可见：回望堤面纵深与岸上城市；画面右边缘可见：塔身与贴塔身向上的几级石台阶；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），台风夜，暴雨，堤面被浪淹了一半，灯塔光扫过。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：避风塘一侧，礁石间的石缝口（猫窝），小石台；画面左边缘可见：塔身与贴塔身向上的几级石台阶；画面右边缘可见：回望堤面纵深与岸上城市；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S22-C｜片尾手绘静帧**（第25场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），手绘插画风静帧，晴朗。红白灯塔塔基：塔基旁礁石间有一道石缝（猫窝）；几级石台阶贴着塔身通往高处观景平台；台阶下有一小块石台。 正面：塔身与贴塔身向上的几级石台阶；右侧：避风塘一侧，礁石间的石缝口（猫窝），小石台；背面：回望堤面纵深与岸上城市；左侧：外海一侧礁石、消波块；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色；氛围：无镜头的秘密基地／台风夜的绝境。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Base of the old lighthouse (rock crevice, stone steps, small ledge), hand-drawn illustration still, sunny. the base of the red-and-white lighthouse: a crevice between rocks beside it (the cat's den); a few stone steps along the tower lead up to the high viewing platform; a small stone ledge below the steps. Front: the tower and the stone steps climbing along it; right: shelter side, the crevice between rocks (cat's den) and a small ledge; back: looking back along the breakwater toward town; left: open-sea side rocks and tetrapods; above: upper tower and lamp room; ground: wet stone. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：塔身与贴塔身向上的几级石台阶；画面左边缘可见：外海一侧礁石、消波块；画面右边缘可见：避风塘一侧，礁石间的石缝口（猫窝），小石台；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：回望堤面纵深与岸上城市；画面左边缘可见：避风塘一侧，礁石间的石缝口（猫窝），小石台；画面右边缘可见：外海一侧礁石、消波块；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：外海一侧礁石、消波块；画面左边缘可见：回望堤面纵深与岸上城市；画面右边缘可见：塔身与贴塔身向上的几级石台阶；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，老灯塔底部（石缝·石台阶·小石台），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：避风塘一侧，礁石间的石缝口（猫窝），小石台；画面左边缘可见：塔身与贴塔身向上的几级石台阶；画面右边缘可见：回望堤面纵深与岸上城市；上方：灯塔塔身上部与灯室；地面：湿石面。色调：红白塔身、灰石、海色。布局与360°全景 S22-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S23 灯塔高处观景平台（栏杆）

*Lighthouse upper viewing platform (railing)*

- **使用场次**：第12、22场
- **原文出处**：第12场：「塔下有几级石台阶通往高处的观景平台。」；第22场：「豆豆手脚并用往上爬，爬到了高处的观景平台，抱住了栏杆。」；第22场：「柯一鸣跳下车顶，跑上台阶，一把抱起豆豆」
- **空间描述**：灯塔中段的环形小平台，铁栏杆，可俯瞰堤面与两侧海。
- **布局**：
  - 正面：栏杆外俯瞰外海
  - 右：俯瞰避风塘
  - 背面：灯塔塔身与通向台阶的开口
  - 左：俯瞰堤面与面包车
  - 顶：灯室与旋转光束
  - 地：铁格栅/石平台
- **色调**：冷蓝、雨白、灯塔光　**氛围**：安全的高处
- 注：平台结构为[设计补充]。

**S23-A｜台风夜**（第22场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，灯塔高处观景平台（栏杆），台风夜，雨幕，灯塔光束从头顶扫过。灯塔中段的环形小平台，铁栏杆，可俯瞰堤面与两侧海。 正面：栏杆外俯瞰外海；右侧：俯瞰避风塘；背面：灯塔塔身与通向台阶的开口；左侧：俯瞰堤面与面包车；上方：灯室与旋转光束；地面：铁格栅/石平台。色调：冷蓝、雨白、灯塔光；氛围：安全的高处。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Lighthouse upper viewing platform (railing), typhoon night, rain curtains, lighthouse beam sweeping overhead. a small ring platform partway up the lighthouse with an iron railing, overlooking the deck and both seas. Front: overlooking the open sea beyond the railing; right: overlooking the typhoon shelter; back: tower wall and opening to the steps; left: overlooking the deck and the van; above: lamp room with rotating beam; ground: iron grating / stone platform. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，灯塔高处观景平台（栏杆），台风夜，雨幕，灯塔光束从头顶扫过。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：栏杆外俯瞰外海；画面左边缘可见：俯瞰堤面与面包车；画面右边缘可见：俯瞰避风塘；上方：灯室与旋转光束；地面：铁格栅/石平台。色调：冷蓝、雨白、灯塔光。布局与360°全景 S23-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，灯塔高处观景平台（栏杆），台风夜，雨幕，灯塔光束从头顶扫过。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：灯塔塔身与通向台阶的开口；画面左边缘可见：俯瞰避风塘；画面右边缘可见：俯瞰堤面与面包车；上方：灯室与旋转光束；地面：铁格栅/石平台。色调：冷蓝、雨白、灯塔光。布局与360°全景 S23-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，灯塔高处观景平台（栏杆），台风夜，雨幕，灯塔光束从头顶扫过。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：俯瞰堤面与面包车；画面左边缘可见：灯塔塔身与通向台阶的开口；画面右边缘可见：栏杆外俯瞰外海；上方：灯室与旋转光束；地面：铁格栅/石平台。色调：冷蓝、雨白、灯塔光。布局与360°全景 S23-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，灯塔高处观景平台（栏杆），台风夜，雨幕，灯塔光束从头顶扫过。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：俯瞰避风塘；画面左边缘可见：栏杆外俯瞰外海；画面右边缘可见：灯塔塔身与通向台阶的开口；上方：灯室与旋转光束；地面：铁格栅/石平台。色调：冷蓝、雨白、灯塔光。布局与360°全景 S23-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S24 渔港（回港渔船·桅杆·海鸥）

*Fishing port (boats returning, masts, seagulls)*

- **使用场次**：第1、15场
- **原文出处**：第15场：「两人沿着渔港慢慢走。夕阳把整片海染成橘红色，渔船一条条回港，海鸥在桅杆间盘旋。」；第1场：「海鸥飞过，渔船回港。」
- **空间描述**：沿岸步道，一侧是成排停靠的渔船与桅杆，一侧是渔具仓库、冰鲜摊棚。
- **布局**：
  - 正面：沿岸步道延伸向避风塘码头
  - 右：渔具仓库、渔网堆、冰鲜摊棚
  - 背面：步道回望城区
  - 左：海面：成排渔船、桅杆、回港船只，远处防波堤
  - 顶：黄昏天空与体积云，海鸥
  - 地：湿水泥步道、缆桩
- **色调**：橘红、碎金、深蓝　**氛围**：甜、开阔（新海诚式天空）
- 注：布局为[设计补充]。

**S24-A｜黄昏橘红**（第15场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），黄昏，高饱和天空与体积云，海面铺满碎金。沿岸步道，一侧是成排停靠的渔船与桅杆，一侧是渔具仓库、冰鲜摊棚。 正面：沿岸步道延伸向避风塘码头；右侧：渔具仓库、渔网堆、冰鲜摊棚；背面：步道回望城区；左侧：海面：成排渔船、桅杆、回港船只，远处防波堤；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝；氛围：甜、开阔（新海诚式天空）。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Fishing port (boats returning, masts, seagulls), dusk, highly saturated sky with volumetric clouds, sea covered in broken gold. a waterfront walkway with rows of moored fishing boats and masts on one side and fishing-gear sheds and seafood stalls on the other. Front: waterfront walk leading to the typhoon-shelter pier; right: gear sheds, net piles, seafood stall awnings; back: walkway looking back to town; left: water: rows of fishing boats and masts, boats coming in, breakwater beyond; above: dusk sky with volumetric clouds, seagulls; ground: wet concrete walkway with bollards. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），黄昏，高饱和天空与体积云，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：沿岸步道延伸向避风塘码头；画面左边缘可见：海面：成排渔船、桅杆、回港船只，远处防波堤；画面右边缘可见：渔具仓库、渔网堆、冰鲜摊棚；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），黄昏，高饱和天空与体积云，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：步道回望城区；画面左边缘可见：渔具仓库、渔网堆、冰鲜摊棚；画面右边缘可见：海面：成排渔船、桅杆、回港船只，远处防波堤；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），黄昏，高饱和天空与体积云，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：海面：成排渔船、桅杆、回港船只，远处防波堤；画面左边缘可见：步道回望城区；画面右边缘可见：沿岸步道延伸向避风塘码头；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），黄昏，高饱和天空与体积云，海面铺满碎金。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：渔具仓库、渔网堆、冰鲜摊棚；画面左边缘可见：沿岸步道延伸向避风塘码头；画面右边缘可见：步道回望城区；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S24-B｜清晨回港**（第1场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），清晨金色，渔船回港。沿岸步道，一侧是成排停靠的渔船与桅杆，一侧是渔具仓库、冰鲜摊棚。 正面：沿岸步道延伸向避风塘码头；右侧：渔具仓库、渔网堆、冰鲜摊棚；背面：步道回望城区；左侧：海面：成排渔船、桅杆、回港船只，远处防波堤；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝；氛围：甜、开阔（新海诚式天空）。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Fishing port (boats returning, masts, seagulls), golden morning, boats returning. a waterfront walkway with rows of moored fishing boats and masts on one side and fishing-gear sheds and seafood stalls on the other. Front: waterfront walk leading to the typhoon-shelter pier; right: gear sheds, net piles, seafood stall awnings; back: walkway looking back to town; left: water: rows of fishing boats and masts, boats coming in, breakwater beyond; above: dusk sky with volumetric clouds, seagulls; ground: wet concrete walkway with bollards. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），清晨金色，渔船回港。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：沿岸步道延伸向避风塘码头；画面左边缘可见：海面：成排渔船、桅杆、回港船只，远处防波堤；画面右边缘可见：渔具仓库、渔网堆、冰鲜摊棚；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），清晨金色，渔船回港。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：步道回望城区；画面左边缘可见：渔具仓库、渔网堆、冰鲜摊棚；画面右边缘可见：海面：成排渔船、桅杆、回港船只，远处防波堤；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），清晨金色，渔船回港。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：海面：成排渔船、桅杆、回港船只，远处防波堤；画面左边缘可见：步道回望城区；画面右边缘可见：沿岸步道延伸向避风塘码头；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，渔港（回港渔船·桅杆·海鸥），清晨金色，渔船回港。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：渔具仓库、渔网堆、冰鲜摊棚；画面左边缘可见：沿岸步道延伸向避风塘码头；画面右边缘可见：步道回望城区；上方：黄昏天空与体积云，海鸥；地面：湿水泥步道、缆桩。色调：橘红、碎金、深蓝。布局与360°全景 S24-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S25 避风塘码头（泊位·入口渔政监控）

*Typhoon-shelter pier (berths, fisheries CCTV at the entrance)*

- **使用场次**：第15、23、25场
- **原文出处**：第15场：「一排小渔船随着波浪轻轻晃。最角落里停着一条旧旧的小机动船」；第15场：「码头入口装着一个渔政监控」；第15场：「两人在路灯下对视」；第23场：「海生号缓缓驶回码头。岸边，朵朵、外婆、浑身湿透的豆豆……还有……周静，站在雨里，等着。」；第25场：「夏红梅站在码头上，这一次不是在等，而是在笑着挥手。」
- **空间描述**：伸入避风塘的木/水泥栈桥码头，一排小渔船靠泊，最角落是海生号；码头入口有立杆渔政监控和路灯。
- **布局**：
  - 正面：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）
  - 右：岸边缆桩、渔具、遮雨棚
  - 背面：码头入口：立杆渔政监控、路灯、通往渔港步道
  - 左：避风塘水面与远处防波堤（细线）及灯塔
  - 顶：天空
  - 地：木栈板与缆绳
- **色调**：黄昏金/雨夜冷蓝　**氛围**：等待与归来
- 注：栈桥材质与监控位置为[设计补充]。

**S25-A｜黄昏→入夜路灯**（第15场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），黄昏转入夜，路灯亮起。伸入避风塘的木/水泥栈桥码头，一排小渔船靠泊，最角落是海生号；码头入口有立杆渔政监控和路灯。 正面：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；右侧：岸边缆桩、渔具、遮雨棚；背面：码头入口：立杆渔政监控、路灯、通往渔港步道；左侧：避风塘水面与远处防波堤（细线）及灯塔；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝；氛围：等待与归来。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Typhoon-shelter pier (berths, fisheries CCTV at the entrance), dusk turning to night, street lamp on. a wooden and concrete jetty reaching into the typhoon shelter with a row of small fishing boats berthed, the Haisheng in the far corner; at the jetty entrance a pole with a fisheries CCTV camera and a street lamp. Front: the jetty out over the water, a row of small boats, the old little motorboat (Haisheng) in the corner; right: shore bollards, gear, a rain shelter; back: jetty entrance: fisheries CCTV pole, street lamp, path to the port; left: shelter water and the distant breakwater (a thin line) with the lighthouse; above: sky; ground: wooden planks and mooring ropes. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），黄昏转入夜，路灯亮起。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；画面左边缘可见：避风塘水面与远处防波堤（细线）及灯塔；画面右边缘可见：岸边缆桩、渔具、遮雨棚；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），黄昏转入夜，路灯亮起。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：码头入口：立杆渔政监控、路灯、通往渔港步道；画面左边缘可见：岸边缆桩、渔具、遮雨棚；画面右边缘可见：避风塘水面与远处防波堤（细线）及灯塔；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），黄昏转入夜，路灯亮起。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：避风塘水面与远处防波堤（细线）及灯塔；画面左边缘可见：码头入口：立杆渔政监控、路灯、通往渔港步道；画面右边缘可见：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），黄昏转入夜，路灯亮起。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：岸边缆桩、渔具、遮雨棚；画面左边缘可见：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；画面右边缘可见：码头入口：立杆渔政监控、路灯、通往渔港步道；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S25-B｜台风夜·雨中等待**（第23场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），台风夜，大雨，码头灯光昏暗，救援艇警灯闪烁。伸入避风塘的木/水泥栈桥码头，一排小渔船靠泊，最角落是海生号；码头入口有立杆渔政监控和路灯。 正面：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；右侧：岸边缆桩、渔具、遮雨棚；背面：码头入口：立杆渔政监控、路灯、通往渔港步道；左侧：避风塘水面与远处防波堤（细线）及灯塔；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝；氛围：等待与归来。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Typhoon-shelter pier (berths, fisheries CCTV at the entrance), typhoon night, heavy rain, dim pier lights, rescue boat warning lights flashing. a wooden and concrete jetty reaching into the typhoon shelter with a row of small fishing boats berthed, the Haisheng in the far corner; at the jetty entrance a pole with a fisheries CCTV camera and a street lamp. Front: the jetty out over the water, a row of small boats, the old little motorboat (Haisheng) in the corner; right: shore bollards, gear, a rain shelter; back: jetty entrance: fisheries CCTV pole, street lamp, path to the port; left: shelter water and the distant breakwater (a thin line) with the lighthouse; above: sky; ground: wooden planks and mooring ropes. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），台风夜，大雨，码头灯光昏暗，救援艇警灯闪烁。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；画面左边缘可见：避风塘水面与远处防波堤（细线）及灯塔；画面右边缘可见：岸边缆桩、渔具、遮雨棚；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），台风夜，大雨，码头灯光昏暗，救援艇警灯闪烁。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：码头入口：立杆渔政监控、路灯、通往渔港步道；画面左边缘可见：岸边缆桩、渔具、遮雨棚；画面右边缘可见：避风塘水面与远处防波堤（细线）及灯塔；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），台风夜，大雨，码头灯光昏暗，救援艇警灯闪烁。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：避风塘水面与远处防波堤（细线）及灯塔；画面左边缘可见：码头入口：立杆渔政监控、路灯、通往渔港步道；画面右边缘可见：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），台风夜，大雨，码头灯光昏暗，救援艇警灯闪烁。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：岸边缆桩、渔具、遮雨棚；画面左边缘可见：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；画面右边缘可见：码头入口：立杆渔政监控、路灯、通往渔港步道；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S25-C｜片尾手绘静帧·晴**（第25场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），手绘插画风静帧，晴朗。伸入避风塘的木/水泥栈桥码头，一排小渔船靠泊，最角落是海生号；码头入口有立杆渔政监控和路灯。 正面：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；右侧：岸边缆桩、渔具、遮雨棚；背面：码头入口：立杆渔政监控、路灯、通往渔港步道；左侧：避风塘水面与远处防波堤（细线）及灯塔；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝；氛围：等待与归来。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Typhoon-shelter pier (berths, fisheries CCTV at the entrance), hand-drawn illustration still, sunny. a wooden and concrete jetty reaching into the typhoon shelter with a row of small fishing boats berthed, the Haisheng in the far corner; at the jetty entrance a pole with a fisheries CCTV camera and a street lamp. Front: the jetty out over the water, a row of small boats, the old little motorboat (Haisheng) in the corner; right: shore bollards, gear, a rain shelter; back: jetty entrance: fisheries CCTV pole, street lamp, path to the port; left: shelter water and the distant breakwater (a thin line) with the lighthouse; above: sky; ground: wooden planks and mooring ropes. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；画面左边缘可见：避风塘水面与远处防波堤（细线）及灯塔；画面右边缘可见：岸边缆桩、渔具、遮雨棚；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：码头入口：立杆渔政监控、路灯、通往渔港步道；画面左边缘可见：岸边缆桩、渔具、遮雨棚；画面右边缘可见：避风塘水面与远处防波堤（细线）及灯塔；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：避风塘水面与远处防波堤（细线）及灯塔；画面左边缘可见：码头入口：立杆渔政监控、路灯、通往渔港步道；画面右边缘可见：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘码头（泊位·入口渔政监控），手绘插画风静帧，晴朗。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：岸边缆桩、渔具、遮雨棚；画面左边缘可见：栈桥伸向水面，一排小渔船，最角落的旧小机动船（海生号）；画面右边缘可见：码头入口：立杆渔政监控、路灯、通往渔港步道；上方：天空；地面：木栈板与缆绳。色调：黄昏金/雨夜冷蓝。布局与360°全景 S25-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S26 海生号船上（船头·甲板·船尾舵位）

*Aboard the Haisheng (bow, deck, stern helm)*

- **使用场次**：第15、23、25场
- **原文出处**：第15场：「两人跳上船，坐在船头。」；第15场：「两人的影子在船板上并在一起」；第23场：「船尾，夏红梅浑身湿透，一只手死死握着舵柄，一只手握着探照灯」；第23场：「知遥被拖上了甲板」；第25场：「海生号重新漆过的船头」
- **空间描述**：小机动渔船船上视角：船头三角甲板（可坐两人），中部小舱/机舱盖，船尾舵柄与手持探照灯；船舷低，挂旧救生圈。
- **布局**：
  - 正面：船头三角甲板，船头外侧漆白字（后期加字）
  - 右：右舷：低船舷，水面
  - 背面：船尾：舵柄、挂外机[设计补充]、手持探照灯
  - 左：左舷：低船舷、缆绳、挂着的旧救生圈
  - 顶：天空
  - 地：斑驳木甲板
- **色调**：斑驳蓝白漆、木色　**氛围**：父亲的船：停了十年→救命
- 注：船型细节为[设计补充]，见道具 P81 海生号。

**S26-A｜黄昏泊位**（第15场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），黄昏，船随波轻晃，夕阳在船板上拉出两人的影子。小机动渔船船上视角：船头三角甲板（可坐两人），中部小舱/机舱盖，船尾舵柄与手持探照灯；船舷低，挂旧救生圈。 正面：船头三角甲板，船头外侧漆白字（后期加字）；右侧：右舷：低船舷，水面；背面：船尾：舵柄、挂外机、手持探照灯；左侧：左舷：低船舷、缆绳、挂着的旧救生圈；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色；氛围：父亲的船：停了十年→救命。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Aboard the Haisheng (bow, deck, stern helm), dusk, boat gently rocking, sunset casting long shadows on the deck. on board a small motor fishing boat: a triangular bow deck where two can sit, a small cabin/engine hatch amidships, a tiller and handheld searchlight at the stern; low gunwales with an old life ring hanging. Front: triangular bow deck, white painted name on the outer bow (text in post); right: starboard: low gunwale, water; back: stern: tiller, outboard [design], handheld searchlight; left: port side: low gunwale, ropes, old life ring; above: sky; ground: weathered wooden deck. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），黄昏，船随波轻晃，夕阳在船板上拉出两人的影子。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：船头三角甲板，船头外侧漆白字（后期加字）；画面左边缘可见：左舷：低船舷、缆绳、挂着的旧救生圈；画面右边缘可见：右舷：低船舷，水面；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），黄昏，船随波轻晃，夕阳在船板上拉出两人的影子。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：船尾：舵柄、挂外机、手持探照灯；画面左边缘可见：右舷：低船舷，水面；画面右边缘可见：左舷：低船舷、缆绳、挂着的旧救生圈；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），黄昏，船随波轻晃，夕阳在船板上拉出两人的影子。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左舷：低船舷、缆绳、挂着的旧救生圈；画面左边缘可见：船尾：舵柄、挂外机、手持探照灯；画面右边缘可见：船头三角甲板，船头外侧漆白字（后期加字）；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），黄昏，船随波轻晃，夕阳在船板上拉出两人的影子。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右舷：低船舷，水面；画面左边缘可见：船头三角甲板，船头外侧漆白字（后期加字）；画面右边缘可见：船尾：舵柄、挂外机、手持探照灯；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S26-B｜台风夜·探照灯**（第23场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），台风夜，暴雨，船在浪里颠簸，雪白探照灯光柱劈开雨幕（体积光）。小机动渔船船上视角：船头三角甲板（可坐两人），中部小舱/机舱盖，船尾舵柄与手持探照灯；船舷低，挂旧救生圈。 正面：船头三角甲板，船头外侧漆白字（后期加字）；右侧：右舷：低船舷，水面；背面：船尾：舵柄、挂外机、手持探照灯；左侧：左舷：低船舷、缆绳、挂着的旧救生圈；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色；氛围：父亲的船：停了十年→救命。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Aboard the Haisheng (bow, deck, stern helm), typhoon night, torrential rain, boat pitching, a snow-white searchlight beam cutting the rain (volumetric). on board a small motor fishing boat: a triangular bow deck where two can sit, a small cabin/engine hatch amidships, a tiller and handheld searchlight at the stern; low gunwales with an old life ring hanging. Front: triangular bow deck, white painted name on the outer bow (text in post); right: starboard: low gunwale, water; back: stern: tiller, outboard [design], handheld searchlight; left: port side: low gunwale, ropes, old life ring; above: sky; ground: weathered wooden deck. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），台风夜，暴雨，船在浪里颠簸，雪白探照灯光柱劈开雨幕（体积光）。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：船头三角甲板，船头外侧漆白字（后期加字）；画面左边缘可见：左舷：低船舷、缆绳、挂着的旧救生圈；画面右边缘可见：右舷：低船舷，水面；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），台风夜，暴雨，船在浪里颠簸，雪白探照灯光柱劈开雨幕（体积光）。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：船尾：舵柄、挂外机、手持探照灯；画面左边缘可见：右舷：低船舷，水面；画面右边缘可见：左舷：低船舷、缆绳、挂着的旧救生圈；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），台风夜，暴雨，船在浪里颠簸，雪白探照灯光柱劈开雨幕（体积光）。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左舷：低船舷、缆绳、挂着的旧救生圈；画面左边缘可见：船尾：舵柄、挂外机、手持探照灯；画面右边缘可见：船头三角甲板，船头外侧漆白字（后期加字）；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），台风夜，暴雨，船在浪里颠簸，雪白探照灯光柱劈开雨幕（体积光）。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右舷：低船舷，水面；画面左边缘可见：船头三角甲板，船头外侧漆白字（后期加字）；画面右边缘可见：船尾：舵柄、挂外机、手持探照灯；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S26-C｜片尾·重新漆过**（第25场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），手绘静帧，船头重新漆过，崭新明亮。小机动渔船船上视角：船头三角甲板（可坐两人），中部小舱/机舱盖，船尾舵柄与手持探照灯；船舷低，挂旧救生圈。 正面：船头三角甲板，船头外侧漆白字（后期加字）；右侧：右舷：低船舷，水面；背面：船尾：舵柄、挂外机、手持探照灯；左侧：左舷：低船舷、缆绳、挂着的旧救生圈；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色；氛围：父亲的船：停了十年→救命。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Aboard the Haisheng (bow, deck, stern helm), hand-drawn still, freshly repainted bow. on board a small motor fishing boat: a triangular bow deck where two can sit, a small cabin/engine hatch amidships, a tiller and handheld searchlight at the stern; low gunwales with an old life ring hanging. Front: triangular bow deck, white painted name on the outer bow (text in post); right: starboard: low gunwale, water; back: stern: tiller, outboard [design], handheld searchlight; left: port side: low gunwale, ropes, old life ring; above: sky; ground: weathered wooden deck. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），手绘静帧，船头重新漆过，崭新明亮。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：船头三角甲板，船头外侧漆白字（后期加字）；画面左边缘可见：左舷：低船舷、缆绳、挂着的旧救生圈；画面右边缘可见：右舷：低船舷，水面；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-C 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），手绘静帧，船头重新漆过，崭新明亮。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：船尾：舵柄、挂外机、手持探照灯；画面左边缘可见：右舷：低船舷，水面；画面右边缘可见：左舷：低船舷、缆绳、挂着的旧救生圈；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-C 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），手绘静帧，船头重新漆过，崭新明亮。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：左舷：低船舷、缆绳、挂着的旧救生圈；画面左边缘可见：船尾：舵柄、挂外机、手持探照灯；画面右边缘可见：船头三角甲板，船头外侧漆白字（后期加字）；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-C 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，海生号船上（船头·甲板·船尾舵位），手绘静帧，船头重新漆过，崭新明亮。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：右舷：低船舷，水面；画面左边缘可见：船头三角甲板，船头外侧漆白字（后期加字）；画面右边缘可见：船尾：舵柄、挂外机、手持探照灯；上方：天空；地面：斑驳木甲板。色调：斑驳蓝白漆、木色。布局与360°全景 S26-C 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S27 避风塘水面与水下（台风夜）

*Typhoon-shelter water surface and underwater (typhoon night)*

- **使用场次**：第1、23场
- **原文出处**：第1场：「水下，墨黑，气泡往上翻。一抹大红色的蝴蝶结缓缓沉下去」；第1场：「最后一个镜头从水下仰拍海面，闪电把水面照成一块碎裂的玻璃。」；第23场：「避风塘虽然比外海平静，但台风夜的水依然冰冷、翻涌，漂满了断掉的缆绳和泡沫箱。」；第23场：「四周一片漆黑，根本看不清岸在哪里。」
- **空间描述**：①水面：漆黑翻涌的水，漂着断缆和泡沫箱，远处有探照灯与灯塔光；②水下：墨黑，气泡上翻，水面被闪电照成碎玻璃。
- **布局**：
  - 正面：水面远处：海生号探照灯光柱（第23场）/灯塔光
  - 右：漆黑水面与雨
  - 背面：防波堤黑影与浪
  - 左：漂浮的断缆绳与泡沫箱
  - 顶：暴雨夜空，闪电
  - 地：水下墨黑深处
- **色调**：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）　**氛围**：绝境→希望
- 注：第1场原本未来中落水点：剧本第三节规则8+第23场弹幕可推断同为避风塘一侧；第1场原文只写“海”，二者用同一资产。

**S27-A｜水面·台风夜**（第23场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），台风夜水面，暴雨，漆黑翻涌，远处探照灯。①水面：漆黑翻涌的水，漂着断缆和泡沫箱，远处有探照灯与灯塔光；②水下：墨黑，气泡上翻，水面被闪电照成碎玻璃。 正面：水面远处：海生号探照灯光柱（第23场）/灯塔光；右侧：漆黑水面与雨；背面：防波堤黑影与浪；左侧：漂浮的断缆绳与泡沫箱；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）；氛围：绝境→希望。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Typhoon-shelter water surface and underwater (typhoon night), typhoon night water surface, torrential rain, pitch-black churning, distant searchlight. (1) surface: pitch-black churning water strewn with broken ropes and foam boxes, a searchlight and the lighthouse beam in the distance; (2) underwater: ink-black, bubbles rising, the surface above lit by lightning like shattered glass. Front: far across the water: the Haisheng's searchlight beam (scene 23) / lighthouse beam; right: black water and rain; back: the black silhouette of the breakwater and waves; left: floating broken ropes and foam boxes; above: stormy night sky, lightning; ground: ink-black depths. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），台风夜水面，暴雨，漆黑翻涌，远处探照灯。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：水面远处：海生号探照灯光柱（第23场）/灯塔光；画面左边缘可见：漂浮的断缆绳与泡沫箱；画面右边缘可见：漆黑水面与雨；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），台风夜水面，暴雨，漆黑翻涌，远处探照灯。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：防波堤黑影与浪；画面左边缘可见：漆黑水面与雨；画面右边缘可见：漂浮的断缆绳与泡沫箱；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），台风夜水面，暴雨，漆黑翻涌，远处探照灯。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：漂浮的断缆绳与泡沫箱；画面左边缘可见：防波堤黑影与浪；画面右边缘可见：水面远处：海生号探照灯光柱（第23场）/灯塔光；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），台风夜水面，暴雨，漆黑翻涌，远处探照灯。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：漆黑水面与雨；画面左边缘可见：水面远处：海生号探照灯光柱（第23场）/灯塔光；画面右边缘可见：防波堤黑影与浪；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S27-B｜水下·墨黑**（第1、23场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），水下墨黑，气泡上翻，仰望水面被闪电照亮成碎玻璃。①水面：漆黑翻涌的水，漂着断缆和泡沫箱，远处有探照灯与灯塔光；②水下：墨黑，气泡上翻，水面被闪电照成碎玻璃。 正面：水面远处：海生号探照灯光柱（第23场）/灯塔光；右侧：漆黑水面与雨；背面：防波堤黑影与浪；左侧：漂浮的断缆绳与泡沫箱；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）；氛围：绝境→希望。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Typhoon-shelter water surface and underwater (typhoon night), underwater ink-black, rising bubbles, looking up at a surface lit by lightning like shattered glass. (1) surface: pitch-black churning water strewn with broken ropes and foam boxes, a searchlight and the lighthouse beam in the distance; (2) underwater: ink-black, bubbles rising, the surface above lit by lightning like shattered glass. Front: far across the water: the Haisheng's searchlight beam (scene 23) / lighthouse beam; right: black water and rain; back: the black silhouette of the breakwater and waves; left: floating broken ropes and foam boxes; above: stormy night sky, lightning; ground: ink-black depths. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），水下墨黑，气泡上翻，仰望水面被闪电照亮成碎玻璃。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：水面远处：海生号探照灯光柱（第23场）/灯塔光；画面左边缘可见：漂浮的断缆绳与泡沫箱；画面右边缘可见：漆黑水面与雨；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），水下墨黑，气泡上翻，仰望水面被闪电照亮成碎玻璃。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：防波堤黑影与浪；画面左边缘可见：漆黑水面与雨；画面右边缘可见：漂浮的断缆绳与泡沫箱；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），水下墨黑，气泡上翻，仰望水面被闪电照亮成碎玻璃。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：漂浮的断缆绳与泡沫箱；画面左边缘可见：防波堤黑影与浪；画面右边缘可见：水面远处：海生号探照灯光柱（第23场）/灯塔光；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，避风塘水面与水下（台风夜），水下墨黑，气泡上翻，仰望水面被闪电照亮成碎玻璃。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：漆黑水面与雨；画面左边缘可见：水面远处：海生号探照灯光柱（第23场）/灯塔光；画面右边缘可见：防波堤黑影与浪；上方：暴雨夜空，闪电；地面：水下墨黑深处。色调：墨黑、冷蓝、闪电白、唯一的红（蝴蝶结）。布局与360°全景 S27-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S28 旧城区24小时便利店（货架·收银台·烟柜·冷柜）

*24-hour convenience store in the old district (shelves, counter, cigarette cabinet, fridges)*

- **使用场次**：第19场
- **原文出处**：第19场：「便利店，白色冷光，货架整齐。收银台后面站着一个瘦小的男生……正在整理烟柜。」；第19场：「冷柜的压缩机“嗡”地响起来。」；第19场：「便利店自动门的“欢迎光临”电子音」；第19场：「店里有监控」；第19场：「知遥走出便利店，天空飘起细雨。」
- **空间描述**：小型便利店：正面是收银台（像一道界线），台后烟柜；左侧整齐货架；右侧一排冷柜；背面是玻璃自动门，门外是旧城区夜街；天花角落监控。
- **布局**：
  - 正面：收银台，台后烟柜，旁边通往员工休息室的门
  - 右：一排冷柜，发出冷光
  - 背面：玻璃自动门，门外夜街与路灯
  - 左：整齐货架（零食、日用品，包装无字）
  - 顶：白色冷光灯带，角落监控
  - 地：白色地砖反光
- **色调**：冷白、浅蓝、对称　**氛围**：孤独深夜、坦白
- 注：店名招牌后期加字（剧本要求虚构中文店名）。

**S28-A｜深夜11:30冷白**（第19场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），深夜，冷白顶光，对称构图，门外黑夜。小型便利店：正面是收银台（像一道界线），台后烟柜；左侧整齐货架；右侧一排冷柜；背面是玻璃自动门，门外是旧城区夜街；天花角落监控。 正面：收银台，台后烟柜，旁边通往员工休息室的门；右侧：一排冷柜，发出冷光；背面：玻璃自动门，门外夜街与路灯；左侧：整齐货架（零食、日用品，包装无字）；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称；氛围：孤独深夜、坦白。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, 24-hour convenience store in the old district (shelves, counter, cigarette cabinet, fridges), 11:30 pm, cold white top light, symmetrical, black night outside. a small convenience store: the checkout counter straight ahead like a boundary line with a cigarette cabinet behind it; neat shelves on the left; a row of drink fridges on the right; glass automatic door behind, the old district's night street outside; CCTV in a ceiling corner. Front: checkout counter, cigarette cabinet behind it, door to the staff room beside; right: a row of glowing drink fridges; back: glass automatic door, night street and lamps outside; left: neat shelves of snacks and goods (packaging without text); above: white fluorescent strips, CCTV in the corner; ground: glossy white tiles. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），深夜，冷白顶光，对称构图，门外黑夜。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：收银台，台后烟柜，旁边通往员工休息室的门；画面左边缘可见：整齐货架（零食、日用品，包装无字）；画面右边缘可见：一排冷柜，发出冷光；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），深夜，冷白顶光，对称构图，门外黑夜。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：玻璃自动门，门外夜街与路灯；画面左边缘可见：一排冷柜，发出冷光；画面右边缘可见：整齐货架（零食、日用品，包装无字）；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），深夜，冷白顶光，对称构图，门外黑夜。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：整齐货架（零食、日用品，包装无字）；画面左边缘可见：玻璃自动门，门外夜街与路灯；画面右边缘可见：收银台，台后烟柜，旁边通往员工休息室的门；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），深夜，冷白顶光，对称构图，门外黑夜。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：一排冷柜，发出冷光；画面左边缘可见：收银台，台后烟柜，旁边通往员工休息室的门；画面右边缘可见：玻璃自动门，门外夜街与路灯；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S28-B｜门外·细雨**（第19场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），便利店门外，夜街，细雨，远处灯塔光一明一灭。小型便利店：正面是收银台（像一道界线），台后烟柜；左侧整齐货架；右侧一排冷柜；背面是玻璃自动门，门外是旧城区夜街；天花角落监控。 正面：收银台，台后烟柜，旁边通往员工休息室的门；右侧：一排冷柜，发出冷光；背面：玻璃自动门，门外夜街与路灯；左侧：整齐货架（零食、日用品，包装无字）；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称；氛围：孤独深夜、坦白。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, 24-hour convenience store in the old district (shelves, counter, cigarette cabinet, fridges), outside the store, night street, fine drizzle, distant lighthouse blinking. a small convenience store: the checkout counter straight ahead like a boundary line with a cigarette cabinet behind it; neat shelves on the left; a row of drink fridges on the right; glass automatic door behind, the old district's night street outside; CCTV in a ceiling corner. Front: checkout counter, cigarette cabinet behind it, door to the staff room beside; right: a row of glowing drink fridges; back: glass automatic door, night street and lamps outside; left: neat shelves of snacks and goods (packaging without text); above: white fluorescent strips, CCTV in the corner; ground: glossy white tiles. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），便利店门外，夜街，细雨，远处灯塔光一明一灭。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：收银台，台后烟柜，旁边通往员工休息室的门；画面左边缘可见：整齐货架（零食、日用品，包装无字）；画面右边缘可见：一排冷柜，发出冷光；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），便利店门外，夜街，细雨，远处灯塔光一明一灭。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：玻璃自动门，门外夜街与路灯；画面左边缘可见：一排冷柜，发出冷光；画面右边缘可见：整齐货架（零食、日用品，包装无字）；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），便利店门外，夜街，细雨，远处灯塔光一明一灭。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：整齐货架（零食、日用品，包装无字）；画面左边缘可见：玻璃自动门，门外夜街与路灯；画面右边缘可见：收银台，台后烟柜，旁边通往员工休息室的门；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧城区24小时便利店（货架·收银台·烟柜·冷柜），便利店门外，夜街，细雨，远处灯塔光一明一灭。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：一排冷柜，发出冷光；画面左边缘可见：收银台，台后烟柜，旁边通往员工休息室的门；画面右边缘可见：玻璃自动门，门外夜街与路灯；上方：白色冷光灯带，角落监控；地面：白色地砖反光。色调：冷白、浅蓝、对称。布局与360°全景 S28-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S29 便利店员工休息室

*Convenience store staff room*

- **使用场次**：第20场
- **原文出处**：第20场：「同一时间，便利店里，许小满在休息室按下了发送键。」
- **空间描述**：狭小休息室：储物柜、折叠椅、小桌、堆放的货箱。
- **布局**：
  - 正面：小桌与折叠椅
  - 右：堆放的货箱
  - 背面：通往卖场的门
  - 左：员工储物柜
  - 顶：一根日光灯
  - 地：灰地砖
- **色调**：冷白　**氛围**：一个人做决定
- 注：全部为[设计补充]。

**S29-A｜白天/傍晚**（第20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，便利店员工休息室，冷白灯光。狭小休息室：储物柜、折叠椅、小桌、堆放的货箱。 正面：小桌与折叠椅；右侧：堆放的货箱；背面：通往卖场的门；左侧：员工储物柜；上方：一根日光灯；地面：灰地砖。色调：冷白；氛围：一个人做决定。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Convenience store staff room, cold white light. a cramped staff room: lockers, folding chair, small table, stacked stock boxes. Front: small table and folding chair; right: stacked boxes; back: door to the shop floor; left: staff lockers; above: one fluorescent tube; ground: grey tiles. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，便利店员工休息室，冷白灯光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：小桌与折叠椅；画面左边缘可见：员工储物柜；画面右边缘可见：堆放的货箱；上方：一根日光灯；地面：灰地砖。色调：冷白。布局与360°全景 S29-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，便利店员工休息室，冷白灯光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：通往卖场的门；画面左边缘可见：堆放的货箱；画面右边缘可见：员工储物柜；上方：一根日光灯；地面：灰地砖。色调：冷白。布局与360°全景 S29-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，便利店员工休息室，冷白灯光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：员工储物柜；画面左边缘可见：通往卖场的门；画面右边缘可见：小桌与折叠椅；上方：一根日光灯；地面：灰地砖。色调：冷白。布局与360°全景 S29-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，便利店员工休息室，冷白灯光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：堆放的货箱；画面左边缘可见：小桌与折叠椅；画面右边缘可见：通往卖场的门；上方：一根日光灯；地面：灰地砖。色调：冷白。布局与360°全景 S29-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S30 旧学校走廊尽头（闪回·器材室附近·消防栓拐角）

*Old school corridor end (flashback, near the equipment room, fire hydrant corner)*

- **使用场次**：第14场
- **原文出处**：第14场：「放学后我去器材室还泳镜，看到三个人把许小满堵在角落里。」；第14场：「昏暗的走廊尽头，三个高大的身影围着一个瘦小的男生。」；第14场：「走廊拐角，一个穿冲锋衣的年轻男人举着手机，躲在消防栓后面拍。」
- **空间描述**：另一所学校的走廊尽头：角落（霸凌发生处），一侧器材室门，走廊拐角有红色消防栓箱。
- **布局**：
  - 正面：走廊尽头墙角（霸凌处）
  - 右：窗户，放学后的暗光
  - 背面：走廊拐角，红色消防栓箱（柯一鸣躲藏处）
  - 左：器材室门
  - 顶：坏了一根的日光灯
  - 地：旧水磨石
- **色调**：褪色蓝灰滤镜、颗粒噪点　**氛围**：压抑的回忆，无弹幕
- 注：学校建筑为[设计补充]，需与第七中学区分（不同墙裙色）。

**S30-A｜闪回·褪色蓝灰**（第14场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧学校走廊尽头（闪回·器材室附近·消防栓拐角），闪回，褪色的蓝灰色调与颗粒噪点，昏暗。另一所学校的走廊尽头：角落（霸凌发生处），一侧器材室门，走廊拐角有红色消防栓箱。 正面：走廊尽头墙角（霸凌处）；右侧：窗户，放学后的暗光；背面：走廊拐角，红色消防栓箱（柯一鸣躲藏处）；左侧：器材室门；上方：坏了一根的日光灯；地面：旧水磨石。色调：褪色蓝灰滤镜、颗粒噪点；氛围：压抑的回忆，无弹幕。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Old school corridor end (flashback, near the equipment room, fire hydrant corner), flashback, faded blue-grey grade with film grain, dim. the end of a corridor in another school: the corner where the bullying happens, an equipment-room door on one side, a red fire-hydrant cabinet at the corridor bend. Front: the dead-end corner of the corridor; right: windows, dim after-school light; back: corridor bend with a red fire-hydrant cabinet (where Ke hides); left: equipment room door; above: fluorescent lights, one broken; ground: old terrazzo. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧学校走廊尽头（闪回·器材室附近·消防栓拐角），闪回，褪色的蓝灰色调与颗粒噪点，昏暗。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：走廊尽头墙角（霸凌处）；画面左边缘可见：器材室门；画面右边缘可见：窗户，放学后的暗光；上方：坏了一根的日光灯；地面：旧水磨石。色调：褪色蓝灰滤镜、颗粒噪点。布局与360°全景 S30-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧学校走廊尽头（闪回·器材室附近·消防栓拐角），闪回，褪色的蓝灰色调与颗粒噪点，昏暗。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：走廊拐角，红色消防栓箱（柯一鸣躲藏处）；画面左边缘可见：窗户，放学后的暗光；画面右边缘可见：器材室门；上方：坏了一根的日光灯；地面：旧水磨石。色调：褪色蓝灰滤镜、颗粒噪点。布局与360°全景 S30-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧学校走廊尽头（闪回·器材室附近·消防栓拐角），闪回，褪色的蓝灰色调与颗粒噪点，昏暗。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：器材室门；画面左边缘可见：走廊拐角，红色消防栓箱（柯一鸣躲藏处）；画面右边缘可见：走廊尽头墙角（霸凌处）；上方：坏了一根的日光灯；地面：旧水磨石。色调：褪色蓝灰滤镜、颗粒噪点。布局与360°全景 S30-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，旧学校走廊尽头（闪回·器材室附近·消防栓拐角），闪回，褪色的蓝灰色调与颗粒噪点，昏暗。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：窗户，放学后的暗光；画面左边缘可见：走廊尽头墙角（霸凌处）；画面右边缘可见：走廊拐角，红色消防栓箱（柯一鸣躲藏处）；上方：坏了一根的日光灯；地面：旧水磨石。色调：褪色蓝灰滤镜、颗粒噪点。布局与360°全景 S30-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S31 柯一鸣工作室（霓虹灯牌·电脑）

*Ke Yiming's studio (neon sign, computer)*

- **使用场次**：第17、20场
- **原文出处**：第17场：「屏幕里是柯一鸣的视频连线，他背后挂着“一鸣惊瓜”的霓虹灯牌。」；第20场：「柯一鸣的工作室里，他对着电脑屏幕上满屏的“摆拍”“道歉”“举报”，摔了耳麦。」
- **空间描述**：自媒体工作室：电脑桌与双屏、补光灯、麦克风支架、背后墙上霓虹灯牌（文字后期）、器材架（稳定器、相机）。
- **布局**：
  - 正面：电脑桌、双显示器、补光灯、麦克风支架
  - 右：窗帘紧闭的窗、懒人沙发
  - 背面：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉
  - 左：器材架：稳定器、相机、耳机
  - 顶：RGB灯带
  - 地：深色地毯，线缆
- **色调**：霓虹粉紫、屏幕蓝　**氛围**：流量、浮躁
- 注：第17场连线背景与第20场工作室为同一空间是[设计补充]。

**S31-A｜视频连线背景**（第17场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），霓虹灯牌亮着，屏幕光。自媒体工作室：电脑桌与双屏、补光灯、麦克风支架、背后墙上霓虹灯牌（文字后期）、器材架（稳定器、相机）。 正面：电脑桌、双显示器、补光灯、麦克风支架；右侧：窗帘紧闭的窗、懒人沙发；背面：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；左侧：器材架：稳定器、相机、耳机；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝；氛围：流量、浮躁。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Ke Yiming's studio (neon sign, computer), neon sign lit, screen glow. a content-creator studio: desk with dual monitors, ring light, mic arm, a neon sign on the back wall (text added in post), gear shelf with gimbals and cameras. Front: desk with dual monitors, ring light, mic arm; right: closed curtains, bean bag; back: back wall: neon sign (blank tube shape, text in post), acoustic foam; left: gear shelf: gimbals, cameras, earbuds; above: RGB light strips; ground: dark carpet, cables. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），霓虹灯牌亮着，屏幕光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：电脑桌、双显示器、补光灯、麦克风支架；画面左边缘可见：器材架：稳定器、相机、耳机；画面右边缘可见：窗帘紧闭的窗、懒人沙发；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），霓虹灯牌亮着，屏幕光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；画面左边缘可见：窗帘紧闭的窗、懒人沙发；画面右边缘可见：器材架：稳定器、相机、耳机；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），霓虹灯牌亮着，屏幕光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：器材架：稳定器、相机、耳机；画面左边缘可见：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；画面右边缘可见：电脑桌、双显示器、补光灯、麦克风支架；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），霓虹灯牌亮着，屏幕光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：窗帘紧闭的窗、懒人沙发；画面左边缘可见：电脑桌、双显示器、补光灯、麦克风支架；画面右边缘可见：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S31-B｜夜·满屏差评**（第20场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），夜，只有屏幕和霓虹光。自媒体工作室：电脑桌与双屏、补光灯、麦克风支架、背后墙上霓虹灯牌（文字后期）、器材架（稳定器、相机）。 正面：电脑桌、双显示器、补光灯、麦克风支架；右侧：窗帘紧闭的窗、懒人沙发；背面：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；左侧：器材架：稳定器、相机、耳机；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝；氛围：流量、浮躁。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Ke Yiming's studio (neon sign, computer), night, only screens and neon. a content-creator studio: desk with dual monitors, ring light, mic arm, a neon sign on the back wall (text added in post), gear shelf with gimbals and cameras. Front: desk with dual monitors, ring light, mic arm; right: closed curtains, bean bag; back: back wall: neon sign (blank tube shape, text in post), acoustic foam; left: gear shelf: gimbals, cameras, earbuds; above: RGB light strips; ground: dark carpet, cables. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），夜，只有屏幕和霓虹光。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：电脑桌、双显示器、补光灯、麦克风支架；画面左边缘可见：器材架：稳定器、相机、耳机；画面右边缘可见：窗帘紧闭的窗、懒人沙发；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），夜，只有屏幕和霓虹光。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；画面左边缘可见：窗帘紧闭的窗、懒人沙发；画面右边缘可见：器材架：稳定器、相机、耳机；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），夜，只有屏幕和霓虹光。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：器材架：稳定器、相机、耳机；画面左边缘可见：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；画面右边缘可见：电脑桌、双显示器、补光灯、麦克风支架；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，柯一鸣工作室（霓虹灯牌·电脑），夜，只有屏幕和霓虹光。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：窗帘紧闭的窗、懒人沙发；画面左边缘可见：电脑桌、双显示器、补光灯、麦克风支架；画面右边缘可见：背后墙：霓虹灯牌（空白灯管形状，文字后期）、吸音棉；上方：RGB灯带；地面：深色地毯，线缆。色调：霓虹粉紫、屏幕蓝。布局与360°全景 S31-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S32 片头OP抽象空间：海面上游动的手机屏幕

*Opening-title abstract space: phone screens swimming like fish over the sea*

- **使用场次**：第6场
- **原文出处**：第6场：「画面一：无数手机屏幕像鱼群一样在海面上游动，每块屏幕上都是同一张模糊的截图。」；第6场：「画面五：倒计时数字“17”从海面升起，碎成浪花。」；第6场：「画面四：红蝴蝶结和藏青外套在风里交错飞过」
- **空间描述**：开阔海面，无岸线；海面上方漂浮成群的手机屏幕（屏幕内容后期合成）。
- **布局**：
  - 正面：开阔海平线
  - 右：海面
  - 背面：开阔海平线
  - 左：海面
  - 顶：高饱和天空
  - 地：海面
- **色调**：高饱和蓝、白　**氛围**：疾走、被围观
- 注：手机屏、数字17作为VFX后期叠加，全景只做空海面。

**S32-A｜OP·白天**（第6场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，片头OP抽象空间：海面上游动的手机屏幕，明亮高饱和，快节奏。开阔海面，无岸线；海面上方漂浮成群的手机屏幕（屏幕内容后期合成）。 正面：开阔海平线；右侧：海面；背面：开阔海平线；左侧：海面；上方：高饱和天空；地面：海面。色调：高饱和蓝、白；氛围：疾走、被围观。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Opening-title abstract space: phone screens swimming like fish over the sea, bright, saturated. an open sea with no shoreline; schools of floating phone screens above the water (screen content composited in post). Front: open horizon; right: sea; back: open horizon; left: sea; above: saturated sky; ground: sea surface. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，片头OP抽象空间：海面上游动的手机屏幕，明亮高饱和，快节奏。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：开阔海平线；画面左边缘可见：海面；画面右边缘可见：海面；上方：高饱和天空；地面：海面。色调：高饱和蓝、白。布局与360°全景 S32-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，片头OP抽象空间：海面上游动的手机屏幕，明亮高饱和，快节奏。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：开阔海平线；画面左边缘可见：海面；画面右边缘可见：海面；上方：高饱和天空；地面：海面。色调：高饱和蓝、白。布局与360°全景 S32-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，片头OP抽象空间：海面上游动的手机屏幕，明亮高饱和，快节奏。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：海面；画面左边缘可见：开阔海平线；画面右边缘可见：开阔海平线；上方：高饱和天空；地面：海面。色调：高饱和蓝、白。布局与360°全景 S32-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，片头OP抽象空间：海面上游动的手机屏幕，明亮高饱和，快节奏。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：海面；画面左边缘可见：开阔海平线；画面右边缘可见：开阔海平线；上方：高饱和天空；地面：海面。色调：高饱和蓝、白。布局与360°全景 S32-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

### S33 游泳馆（泳池底·跳台·看台）

*Swimming hall (pool bottom, starting blocks, stands)*

- **使用场次**：第6、14、25场
- **原文出处**：第6场：「画面三：周砚在泳池底仰望水面，水面上浮满文字。」；第25场：「周砚站在跳台上，看台上一个举着纸牌而不是手机的许小满」；第14场：「比赛的时候，看台上会有人举着手机喊‘打人的那个’。我站在跳台上」
- **空间描述**：标准室内泳池：一端出发跳台，一侧阶梯看台，泳道线。
- **布局**：
  - 正面：泳池一端的出发跳台
  - 右：落地玻璃窗，日光
  - 背面：泳池另一端
  - 左：阶梯看台
  - 顶：钢结构屋顶与灯
  - 地：蓝色泳池与泳道线
- **色调**：水蓝、白　**氛围**：回到水里
- 注：全部为[设计补充]；第24场提到“下周市里的比赛”。

**S33-A｜水下仰望（OP）**（第6场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），池底仰望水面，光斑摇曳。标准室内泳池：一端出发跳台，一侧阶梯看台，泳道线。 正面：泳池一端的出发跳台；右侧：落地玻璃窗，日光；背面：泳池另一端；左侧：阶梯看台；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白；氛围：回到水里。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Swimming hall (pool bottom, starting blocks, stands), looking up from the pool bottom at rippling light. a standard indoor pool: starting blocks at one end, tiered stands on one side, lane ropes. Front: starting blocks at the end of the pool; right: floor-to-ceiling windows, daylight; back: the far end of the pool; left: tiered stands; above: steel truss roof with lights; ground: blue pool with lane ropes. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），池底仰望水面，光斑摇曳。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：泳池一端的出发跳台；画面左边缘可见：阶梯看台；画面右边缘可见：落地玻璃窗，日光；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-A 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），池底仰望水面，光斑摇曳。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：泳池另一端；画面左边缘可见：落地玻璃窗，日光；画面右边缘可见：阶梯看台；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-A 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），池底仰望水面，光斑摇曳。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：阶梯看台；画面左边缘可见：泳池另一端；画面右边缘可见：泳池一端的出发跳台；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-A 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），池底仰望水面，光斑摇曳。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：落地玻璃窗，日光；画面左边缘可见：泳池一端的出发跳台；画面右边缘可见：泳池另一端；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-A 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

**S33-B｜片尾手绘静帧**（第25场）

- 360°全景（中）：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），手绘插画风，明亮。标准室内泳池：一端出发跳台，一侧阶梯看台，泳道线。 正面：泳池一端的出发跳台；右侧：落地玻璃窗，日光；背面：泳池另一端；左侧：阶梯看台；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白；氛围：回到水里。等距柱状投影360°全景图，宽高比2:1，相机位于空间中央、视线高度约1.6米，地平线位于画面垂直正中；画面中心为正面，画面左侧四分之一处为左侧，右侧四分之一处为右侧，左右两端为背面并且无缝衔接，顶部为天花/天空，底部为地面；无人物，无动物，无文字，无字母，招牌留白，无水印，无字幕
- 360° panorama (EN): Japanese theatrical anime film background art, detailed hand-painted background, cel-shaded look, soft cinematic lighting, rich detail, Swimming hall (pool bottom, starting blocks, stands), hand-drawn still, bright. a standard indoor pool: starting blocks at one end, tiered stands on one side, lane ropes. Front: starting blocks at the end of the pool; right: floor-to-ceiling windows, daylight; back: the far end of the pool; left: tiered stands; above: steel truss roof with lights; ground: blue pool with lane ropes. equirectangular 360-degree panorama, 2:1 aspect ratio, camera at the center of the space at 1.6 m eye level, horizon exactly at vertical center; image center = front, left quarter = left side, right quarter = right side, both edges = back and wrap seamlessly, top = ceiling/sky, bottom = floor; no people, no animals, no text, no letters, blank signboards, no watermark, no subtitles
- 正面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），手绘插画风，明亮。镜头位于空间中央、视线高度1.6米，水平朝向正面，35mm标准视角，16:9横构图。画面中央：泳池一端的出发跳台；画面左边缘可见：阶梯看台；画面右边缘可见：落地玻璃窗，日光；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-B 完全一致。无人物，无文字，无水印
- 反面视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），手绘插画风，明亮。镜头位于空间中央、视线高度1.6米，水平朝向背面，35mm标准视角，16:9横构图。画面中央：泳池另一端；画面左边缘可见：落地玻璃窗，日光；画面右边缘可见：阶梯看台；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-B 完全一致。无人物，无文字，无水印
- 左视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），手绘插画风，明亮。镜头位于空间中央、视线高度1.6米，水平朝向左侧，35mm标准视角，16:9横构图。画面中央：阶梯看台；画面左边缘可见：泳池另一端；画面右边缘可见：泳池一端的出发跳台；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-B 完全一致。无人物，无文字，无水印
- 右视角：日式剧场版动画电影背景美术，精致手绘背景，赛璐珞质感，柔和电影光影，细节丰富，游泳馆（泳池底·跳台·看台），手绘插画风，明亮。镜头位于空间中央、视线高度1.6米，水平朝向右侧，35mm标准视角，16:9横构图。画面中央：落地玻璃窗，日光；画面左边缘可见：泳池一端的出发跳台；画面右边缘可见：泳池另一端；上方：钢结构屋顶与灯；地面：蓝色泳池与泳道线。色调：水蓝、白。布局与360°全景 S33-B 完全一致。无人物，无文字，无水印
- 四视角英文版见 assets.json。

## 二、道具

### P01 红蝴蝶结（缎面，尾端绣“遥”）　〔道具〕

- **英文**：Red satin hair bow with the character 遥 embroidered on the tail　**归属**：夏知遥（父亲夏海生所送）　**场次**：第1、2、3、6、7、10、12、15、16、17、18、20、21、22、23、24、25场
- **出处**：设定（第三~六节）：「大红色缎面，尾端绣着一个小小的“遥”字」；第3场：「他看了一眼尾端那个绣着的“遥”字」；第23场：「漆黑的海面上，一抹大红色。是知遥头上那个被母亲系得紧紧的红蝴蝶结。」
- **外观**：大号双环蝴蝶结，大红色缎面带光泽，两条垂尾约20cm，尾端用白色[设计补充]丝线绣一个小“遥”字；中心结扣包缎；系在后脑稍高处，正面看双环对称探出头顶。
- **状态变化**：第2场：妈妈替她系，“又快又紧”；第3场：系得太急，被风吹松滑落在过道；第7场：被手指一圈圈绕尾巴；第15场：海风吹松，周砚帮她系歪；第16场：被柯一鸣扯歪；第18场：自己解下重新系紧；第20场：妈妈最后一次替她系紧：“系紧点。”；第1场：原本未来：在水下沉落，缎带像金鱼摆动；第23场：湿透，在黑海面上被探照灯照到；水下被手腕旁的手抓住；第24场：正常系着，被绕在指尖
- 注：“遥”字刺绣颜色剧本未写，[设计补充]白色/金色二选一。
- 注：文字类刺绣AI可能写错，建议出图后手工修字或后期贴图。
- **转面图提示词**：道具设定图（多视角转面图），红蝴蝶结（缎面，尾端绣“遥”）：大号双环蝴蝶结，大红色缎面带光泽，两条垂尾约20cm，尾端用白色丝线绣一个小“遥”字；中心结扣包缎；系在后脑稍高处，正面看双环对称探出头顶。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：尾端刺绣“遥”字特写、中心结扣特写、缎面光泽与褶皱特写、湿透下垂状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Red satin hair bow with the character 遥 embroidered on the tail: large double-loop hair bow of glossy scarlet satin, two tails about 20 cm long, a tiny embroidered character on one tail end (white thread, design choice); wrapped satin knot; worn high on the back of the head so both loops show symmetrically above the head from the front. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the embroidered tail end, the center knot, satin sheen and folds, and the soaked drooping state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P02 周砚的藏青外套（拉链夹克）　〔道具〕

- **英文**：Zhou Yan's navy zip-up jacket　**归属**：周砚　**场次**：第1、2、3、4、6、7、10、13、17、21、22、23、24场
- **出处**：第3场：「藏青色夹克、白 T 恤」；第10场：「他脱下藏青外套，往知遥头上一罩」；第21场：「周砚把藏青外套拉链拉到顶」；第22场：「脱下自己的藏青外套裹住孩子」；第24场：「藏青外套搭在椅背上」
- **外观**：藏青色棉质立领拉链夹克，长度到胯，两侧斜插袋，左胸一枚小圆形徽章（见人物卡）；面料略哑光，袖口罗纹[设计补充]。
- **状态变化**：第4场：在家脱下，只穿白T；第10场：罩在知遥头上，他那半边湿透；第17场：出现在宋佳怡偷拍的照片里；第21场：拉链拉到顶；第22场：裹住豆豆；第23场：豆豆抱着它站在码头；第24场：搭在椅背上；第6场：OP：和红蝴蝶结在风里交错飞过
- 注：与服装 ZYN-L1 同一件；作为道具单独出图用于“罩头”“裹孩子”镜头。
- **转面图提示词**：道具设定图（多视角转面图），周砚的藏青外套（拉链夹克）：藏青色棉质立领拉链夹克，长度到胯，两侧斜插袋，左胸一枚小圆形徽章（见人物卡）；面料略哑光，袖口罗纹。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：拉链与领口特写、口袋特写、左胸小徽章特写、湿透深色状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhou Yan's navy zip-up jacket: navy cotton stand-collar zip jacket, hip length, two slanted pockets, a small round badge on the left chest (per character card); matte fabric, ribbed cuffs . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the zipper and collar, pocket, small chest badge, soaked darker state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P03 数字蜡烛“17”（烧剩一半）　〔道具〕

- **英文**：Number candle '17' (half burned)　**归属**：夏知遥　**场次**：第4、5、24场
- **出处**：第4场：「一张矮桌上摆着一个小蛋糕，插着数字蜡烛“17”。」；第5场：「她悄悄把那根烧剩一半的“17”蜡烛拔下来，用纸巾包好」；第24场：「相框底下压着那半根烧剩的数字蜡烛“17”。」
- **外观**：数字造型蜡烛“1”“7”连体（或两根）[设计补充：连体一根]，约8cm高，奶油白蜡身带金色细描边[设计补充]，烛芯黑。
- **状态变化**：第4场：燃烧，被两人同时吹灭，白烟拧成∞；第5场：烧剩一半，被纸巾包好攥在手心；第24场：压在剪报相框底下
- 注：剧本写“剧情数字蜡烛17”，是一根还是两根未写明，需确认。
- **转面图提示词**：道具设定图（多视角转面图），数字蜡烛“17”（烧剩一半）：数字造型蜡烛“1”“7”连体（或两根），约8cm高，奶油白蜡身带金色细描边，烛芯黑。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：新蜡烛/燃烧中火苗/烧剩一半熔蜡/纸巾包裹 四种状态特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Number candle '17' (half burned): number-shaped candle '17' as one piece , about 8 cm tall, cream-white wax with thin gold outline , black wick. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups: new, burning with flame, half-melted, wrapped in tissue. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P04 生日小蛋糕　〔道具〕

- **英文**：Small birthday cake　**归属**：夏家　**场次**：第4、5场
- **出处**：第4场：「一张矮桌上摆着一个小蛋糕」；第5场：「【弹幕A】这个蛋糕好可爱……呜呜呜」
- **外观**：直径约15cm奶油小蛋糕，白奶油抹面，顶部几颗草莓和奶油花[设计补充]。
- **状态变化**：第4场：完整，插蜡烛；第5场：吃过一部分[设计补充]
- **转面图提示词**：道具设定图（多视角转面图），生日小蛋糕：直径约15cm奶油小蛋糕，白奶油抹面，顶部几颗草莓和奶油花。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：顶部俯视、切口。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Small birthday cake: small 15 cm cream cake with white frosting, a few strawberries and piped cream on top . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: top view, cut slice. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P05 浅蓝色作文本（规则笔记本《弹幕法则》）　〔道具〕

- **英文**：Light-blue composition notebook (the 'Danmaku Rules' notebook)　**归属**：夏知遥　**场次**：第6、7、10、13、15、18场
- **出处**：设定（第三~六节）：「知遥的浅蓝色作文本，后半本被两人写成了《弹幕法则》。」；第6场：「抱着浅蓝色作文本，翻到最后一页」；第10场：「膝盖上摊着作文本」；第18场：「把纸的下沿往上一折。折痕刚好压住最后一个字“们”」
- **外观**：A5软皮作文本，浅蓝色封面（封面字样后期加），内页横格米白纸，手写蓝黑字迹；用旧后边角微卷。
- **状态变化**：第6场：最后一页写《弹幕到底是什么？》4条；第7场：加第5、6条；第10场：雨中被外套一起裹住；第13场：新一页改名《弹幕法则》1–8条；第18场：加第9条；最后一页写“我不该相信他们”并折起；第25场：片尾静帧画风“像知遥作文本里的插画”
- 注：本子内文字一律后期加，出图时空白横格。
- **转面图提示词**：道具设定图（多视角转面图），浅蓝色作文本（规则笔记本《弹幕法则》）：A5软皮作文本，浅蓝色封面（封面字样后期加），内页横格米白纸，手写蓝黑字迹；用旧后边角微卷。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：封面、翻开内页（手写列表，文字后期）、最后一页下沿折痕特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Light-blue composition notebook (the 'Danmaku Rules' notebook): A5 soft-cover composition notebook with a light-blue cover (cover text in post), cream lined pages with handwritten blue-black ink; corners slightly curled from use. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: cover, open spread with handwritten list (text in post), close-up of the folded bottom edge of the last page. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P06 《港口的早晨》稿纸（被涂改液改名）　〔道具〕

- **英文**：Essay manuscript 'Harbor Morning' (name covered with correction fluid)　**归属**：夏知遥　**场次**：第3、7、15、24场
- **出处**：第7场：「稿纸右上角的“夏知遥”三个字已经被涂改液盖住，旁边写着“宋佳怡”。」；第15场：「知遥给周砚看她写的《港口的早晨》，他认真读完，在最后一行下面画了一道线」；第24场：「第七中学校报的剪报：征文一等奖《港口的早晨》」
- **外观**：几页A4方格稿纸，钢笔字；右上角一块白色涂改液，上方后来手写名字。
- **状态变化**：第7场：名字被涂→知遥在涂改液上方写回自己的名字→投进投稿箱；第15场：最后一行下被画线，写“好看”；第24场：登报剪报装进相框
- **转面图提示词**：道具设定图（多视角转面图），《港口的早晨》稿纸（被涂改液改名）：几页A4方格稿纸，钢笔字；右上角一块白色涂改液，上方后来手写名字。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：右上角涂改液特写、笔尖写字特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Essay manuscript 'Harbor Morning' (name covered with correction fluid): a few sheets of A4 grid manuscript paper in fountain-pen handwriting; a patch of white correction fluid at the top right with a name later written above it. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the correction-fluid patch and the pen tip writing. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P07 涂改液与借来的签字笔　〔道具〕

- **英文**：Correction fluid and a borrowed gel pen　**归属**：宋佳怡（涂改液）/ 知遥（借笔）　**场次**：第7场
- **出处**：第7场：「拧开桌上借来的签字笔，在涂改液上方一笔一画写下自己的名字。」
- **外观**：笔形涂改液（白色笔身）；黑色按动/拧盖签字笔。
- **转面图提示词**：道具设定图（多视角转面图），涂改液与借来的签字笔：笔形涂改液（白色笔身）；黑色按动/拧盖签字笔。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：笔尖特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Correction fluid and a borrowed gel pen: pen-type correction fluid (white body); black capped gel pen. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: pen tip close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P08 校报投稿箱　〔道具〕

- **英文**：School newspaper submission box　**归属**：第七中学　**场次**：第7场
- **出处**：第7场：「一只手按住了投稿箱的口。」；第7场：「知遥把稿子投进投稿箱」
- **外观**：挂墙木箱约40×30×15cm，正面上方一条投信口，正面标签牌空白（后期加字），刷浅绿色漆，带小锁。
- **转面图提示词**：道具设定图（多视角转面图），校报投稿箱：挂墙木箱约40×30×15cm，正面上方一条投信口，正面标签牌空白（后期加字），刷浅绿色漆，带小锁。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：投信口特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, School newspaper submission box: wall-mounted wooden box about 40×30×15 cm, a slot at the top front, blank label plate (text in post), pale-green paint, small padlock. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: slot close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P09 褪色的蓝色游泳队徽章（浪花+“少年队”）　〔道具〕

- **英文**：Faded blue swim-team badge (wave motif, 'youth team')　**归属**：周砚　**场次**：第3、10、14、15、22场
- **出处**：第3场：「书包带上别着一枚褪色的蓝色游泳队徽章，图案是浪花和“少年队”字样。」；第10场：「拇指按了一下书包带上的徽章」；第15场：「拇指按着书包带上的游泳队徽章」
- **外观**：直径约3cm圆形珐琅别针徽章，褪色的蓝底，白色浪花图案，下方一条小弧形字带（文字后期）；边缘金属磨损。
- 注：characters.md 的周砚提示词另写“夹克左胸有小圆形徽章”，与此书包带徽章是否同一枚/两枚，需确认。
- **转面图提示词**：道具设定图（多视角转面图），褪色的蓝色游泳队徽章（浪花+“少年队”）：直径约3cm圆形珐琅别针徽章，褪色的蓝底，白色浪花图案，下方一条小弧形字带（文字后期）；边缘金属磨损。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：正面浪花图案特写、背面别针、别在书包带上状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Faded blue swim-team badge (wave motif, 'youth team'): round enamel pin about 3 cm, faded blue field with a white wave motif and a small curved text ribbon (text in post); worn metal rim. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups of the wave design, the pin back, pinned on the bag strap. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P10 周砚的黑色双肩包（单肩背）　〔道具〕

- **英文**：Zhou Yan's black backpack (worn on one shoulder)　**归属**：周砚　**场次**：第2、3、8、12、13、16、21场
- **出处**：第2场：「单肩背着黑色双肩包」；第3场：「他坐下，把书包挂在椅背上。」；第8场：「把单肩包从左肩换到右肩」；第12场：「单肩包放在脚边」；第21场：「单肩包扔在门口」
- **外观**：黑色尼龙双肩包，简洁无大logo，一侧肩带别蓝色游泳队徽章；略旧。
- **状态变化**：第21场：被扔在面馆门口
- **转面图提示词**：道具设定图（多视角转面图），周砚的黑色双肩包（单肩背）：黑色尼龙双肩包，简洁无大logo，一侧肩带别蓝色游泳队徽章；略旧。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：肩带与徽章特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhou Yan's black backpack (worn on one shoulder): plain black nylon backpack with no big logo, the swim badge pinned on one strap; slightly worn. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: strap and badge close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P11 知遥的书包（侧袋网兜被刮破）　〔道具〕

- **英文**：Zhiyao's schoolbag (side mesh pocket torn)　**归属**：夏知遥　**场次**：第7、8、18场
- **出处**：第8场：「后视镜刮破了她书包侧袋的网兜。」；第8场：「网兜被刮出一道长口子，刚好是她刚才腰部的高度」；第18场：「书包侧袋里，一张被揉皱的小纸条掉了出来」
- **外观**：深棕色[设计补充]双肩书包，两侧网兜侧袋。
- **状态变化**：第8场：被电动车后视镜刮出长口子；第18场：侧袋掉出宋佳怡纸条
- **转面图提示词**：道具设定图（多视角转面图），知遥的书包（侧袋网兜被刮破）：深棕色双肩书包，两侧网兜侧袋。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：完好侧袋/被刮出长口子的网兜特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhiyao's schoolbag (side mesh pocket torn): dark brown backpack with mesh side pockets. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-ups: intact mesh pocket and the long tear. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P12 知遥的手机　〔道具〕

- **英文**：Zhiyao's phone　**归属**：夏知遥　**场次**：第3、16、17、18、19、20、21、22场
- **出处**：第3场：「知遥的手机推送弹出」；第18场：「手机掉在地上……手机的前置摄像头还开着，红点亮着」；第20场：「她把手机架在书桌上，打开前置摄像头」；第22场：「知遥打开胸前防水袋里手机的直播」
- **外观**：普通直板智能手机，浅色[设计补充]简单手机壳；屏幕内容后期合成。
- **状态变化**：第18场：掉地，前置摄像头录像红点亮；第20场：架在书桌上录视频、发布；第21场：装进防水袋挂在胸前；第22场：直播→浸水黑屏只剩在线人数
- **转面图提示词**：道具设定图（多视角转面图），知遥的手机：普通直板智能手机，浅色简单手机壳；屏幕内容后期合成。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：正反面、屏幕亮起、浸水黑屏。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhiyao's phone: ordinary slab smartphone with a pale simple case ; screen content composited in post. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: front/back, lit screen, black after submerged. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P13 外卖用防水手机袋（挂胸前）　〔道具〕

- **英文**：Waterproof phone pouch used for deliveries (worn on chest)　**归属**：夏记面馆　**场次**：第21、22场
- **出处**：第21场：「知遥抓起门口外卖用的防水手机袋，把手机装进去，挂在胸前。」
- **外观**：透明PVC防水手机袋，顶部三道密封扣，挂绳；可透袋看到手机屏。
- **转面图提示词**：道具设定图（多视角转面图），外卖用防水手机袋（挂胸前）：透明PVC防水手机袋，顶部三道密封扣，挂绳；可透袋看到手机屏。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：密封扣特写、挂胸前状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Waterproof phone pouch used for deliveries (worn on chest): clear PVC waterproof phone pouch with triple zip-seal top and lanyard; screen visible through it. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the seal; worn on chest. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P14 林朵朵的手机　〔道具〕

- **英文**：Lin Duoduo's phone　**归属**：林朵朵　**场次**：第2、20、21场
- **出处**：第2场：「朵朵掏出手机，屏幕光照亮她的脸」；第21场：「朵朵（拨着电话，手在抖）」
- **外观**：粉色[设计补充]手机壳，挂小挂件。
- **转面图提示词**：道具设定图（多视角转面图），林朵朵的手机：粉色手机壳，挂小挂件。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：手机壳背面。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Lin Duoduo's phone: phone with a pink case and a small charm . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: case back. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P15 围观的手机群（同学/食客/路人）　〔道具〕

- **英文**：Crowd of phones held up by onlookers　**归属**：同学、食客、围观学生　**场次**：第3、6、7、16、20场
- **出处**：第3场：「所有手机同时翻面扣在桌上。」；第7场：「背景里同学们举着的手机像一圈探照灯」；第16场：「四周十几部手机，像十几只眼睛。」；第20场：「食客们举起手机」
- **外观**：各色手机，镜头一律朝向主体，闪光灯/摄像头作为“眼睛”意象。
- **转面图提示词**：道具设定图（多视角转面图），围观的手机群（同学/食客/路人）：各色手机，镜头一律朝向主体，闪光灯/摄像头作为“眼睛”意象。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：手机背面镜头特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Crowd of phones held up by onlookers: assorted phones with camera lenses facing the subject, lenses read as 'eyes'. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of rear camera lenses. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P16 柯一鸣的手机+手持稳定器　〔道具〕

- **英文**：Ke Yiming's phone on a handheld gimbal　**归属**：柯一鸣　**场次**：第1、14、16、22场
- **出处**：第16场：「举着手机稳定器，戴着无线耳麦」；第16场：「稳定器“哐当”一声砸在地上，镜头刚好朝上」；第14场：「一个穿冲锋衣的年轻男人举着手机，躲在消防栓后面拍」；第22场：「举着稳定器直播」
- **外观**：黑色三轴手机稳定器，夹一部大屏手机，手柄上带小补光灯[设计补充]。
- **状态变化**：第16场：摔在坡道上，镜头朝上
- 注：第14场闪回（一年前）只写“举着手机”，无稳定器。
- **转面图提示词**：道具设定图（多视角转面图），柯一鸣的手机+手持稳定器：黑色三轴手机稳定器，夹一部大屏手机，手柄上带小补光灯。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：三轴结构、手机夹、摔在地上镜头朝上状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Ke Yiming's phone on a handheld gimbal: black three-axis smartphone gimbal holding a large phone, small LED light on the handle . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: three-axis joints, phone clamp, dropped lens-up state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P17 柯一鸣的无线耳机（耳麦）　〔道具〕

- **英文**：Ke Yiming's wireless earbud mic　**归属**：柯一鸣　**场次**：第16、20、22场
- **出处**：设定（第三~六节）：「总戴一只无线耳麦。」；第20场：「摔了耳麦。」
- **外观**：黑色单只入耳式无线耳机带短麦杆，戴左耳（人物卡）。
- **状态变化**：第20场：被摔在桌上
- **转面图提示词**：道具设定图（多视角转面图），柯一鸣的无线耳机（耳麦）：黑色单只入耳式无线耳机带短麦杆，戴左耳（人物卡）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：耳机特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Ke Yiming's wireless earbud mic: single black in-ear wireless earbud with short mic stem, worn in the left ear (per card). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P18 白色面包车（车顶架补光灯）　〔交通工具〕

- **英文**：White van with flood lights on the roof　**归属**：柯一鸣　**场次**：第22场
- **出处**：第22场：「堤中段停着一辆白色面包车，车顶上架着补光灯。柯一鸣穿着雨衣站在车顶」
- **外观**：白色小型面包车，车顶行李架上架两盏方形补光灯，车身无字。
- **转面图提示词**：道具设定图（多视角转面图），白色面包车（车顶架补光灯）：白色小型面包车，车顶行李架上架两盏方形补光灯，车身无字。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：车顶补光灯特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, White van with flood lights on the roof: small white minivan, two square flood lights on the roof rack, no markings. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of roof lights. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P19 会议室笔记本电脑（视频连线）　〔道具〕

- **英文**：Laptop for the video call　**归属**：学校　**场次**：第17场
- **出处**：第17场：「桌上放着一台笔记本电脑，屏幕里是柯一鸣的视频连线」
- **外观**：银灰色普通笔记本电脑。
- **转面图提示词**：道具设定图（多视角转面图），会议室笔记本电脑（视频连线）：银灰色普通笔记本电脑。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：屏幕朝外状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Laptop for the video call: plain silver laptop. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: screen-facing view. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P20 打印的网络截图与文件夹　〔道具〕

- **英文**：Printed screenshots and a folder　**归属**：钱主任　**场次**：第17场
- **出处**：第17场：「钱主任（翻着打印出来的网络截图）」；第17场：「叹气，合上文件夹」
- **外观**：A4打印纸一叠（图像模糊，文字后期）+ 深蓝色文件夹。
- **转面图提示词**：道具设定图（多视角转面图），打印的网络截图与文件夹：A4打印纸一叠（图像模糊，文字后期）+ 深蓝色文件夹。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Printed screenshots and a folder: stack of A4 printouts (blurry images, text in post) and a dark-blue folder. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P21 许小满的旧手机（屏幕裂痕，03:12原视频）　〔道具〕

- **英文**：Xu Xiaoman's old phone (cracked screen, the 3:12 video)　**归属**：许小满　**场次**：第14、19、20场
- **出处**：第19场：「他从制服口袋里掏出一部旧手机，屏幕有一道裂痕。」；第19场：「屏幕上是一段视频，时长 03:12。」；第14场：「那天……我书包侧袋里的手机一直开着录像」
- **外观**：旧款小屏手机，屏幕左上到右下一道裂痕，边框磨损。
- **转面图提示词**：道具设定图（多视角转面图），许小满的旧手机（屏幕裂痕，03:12原视频）：旧款小屏手机，屏幕左上到右下一道裂痕，边框磨损。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：裂痕特写、屏幕亮起。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Xu Xiaoman's old phone (cracked screen, the 3:12 video): old small-screen phone with a diagonal crack across the screen, worn edges. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: crack close-up, lit screen. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P22 许小满的圆框眼镜　〔道具〕

- **英文**：Xu Xiaoman's round glasses　**归属**：许小满　**场次**：第14、19、24、25场
- **出处**：第14场：「一个男生抓起小满的眼镜，要往地上摔。」；第19场：「他摘下眼镜，用袖子胡乱擦了擦。」
- **外观**：瘦小黑色细圆框眼镜。
- **转面图提示词**：道具设定图（多视角转面图），许小满的圆框眼镜：瘦小黑色细圆框眼镜。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：正侧面。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Xu Xiaoman's round glasses: thin small black round-frame glasses. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: front and side. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P23 烟柜与烟盒　〔道具〕

- **英文**：Cigarette cabinet and packs　**归属**：便利店　**场次**：第19场
- **出处**：第19场：「正在整理烟柜。」；第19场：「小满手里的烟盒“啪”地掉在地上。」
- **外观**：收银台后玻璃烟柜，烟盒包装无字纯色块。
- **转面图提示词**：道具设定图（多视角转面图），烟柜与烟盒：收银台后玻璃烟柜，烟盒包装无字纯色块。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Cigarette cabinet and packs: glass cigarette cabinet behind the counter, packs as plain color blocks without text. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P24 面馆旧监控摄像头（楼梯拐角/收银台上方）　〔监控〕

- **英文**：Noodle shop's old CCTV cameras (stair landing / above counter)　**归属**：夏记面馆　**场次**：第6、11场
- **出处**：第6场：「楼梯拐角的墙上装着一个面馆防盗用的旧监控摄像头，红灯一闪一闪。」；第11场：「收银台上方的面馆监控红灯亮着。」
- **外观**：旧款米白色枪式摄像头，带支架，镜头下方一颗红色指示灯，外壳发黄。
- **转面图提示词**：道具设定图（多视角转面图），面馆旧监控摄像头（楼梯拐角/收银台上方）：旧款米白色枪式摄像头，带支架，镜头下方一颗红色指示灯，外壳发黄。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：红灯特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Noodle shop's old CCTV cameras (stair landing / above counter): old off-white bullet CCTV camera on a bracket with a red LED below the lens, yellowed housing. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: red LED close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P25 巷口小超市门口监控　〔监控〕

- **英文**：Mini-mart entrance CCTV　**归属**：小超市　**场次**：第8场
- **出处**：第8场：「巷口一家小超市门口装着监控。」
- **外观**：黑色半球/枪机，挂门楣。
- **转面图提示词**：道具设定图（多视角转面图），巷口小超市门口监控：黑色半球/枪机，挂门楣。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Mini-mart entrance CCTV: black bullet camera on the door lintel. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P26 天台物业监控　〔监控〕

- **英文**：Rooftop property CCTV　**归属**：物业　**场次**：第10场
- **出处**：第10场：「天台角落里有一个物业装的监控摄像头，正对着这里。」
- **外观**：白色枪机装在立杆上。
- **转面图提示词**：道具设定图（多视角转面图），天台物业监控：白色枪机装在立杆上。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Rooftop property CCTV: white bullet camera on a pole. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P27 会议室监控　〔监控〕

- **英文**：Meeting-room CCTV　**归属**：学校　**场次**：第17场
- **出处**：第17场：「会议室角落里装着一个监控。」
- **外观**：白色半球摄像头吊顶角落。
- **转面图提示词**：道具设定图（多视角转面图），会议室监控：白色半球摄像头吊顶角落。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Meeting-room CCTV: white dome camera in the ceiling corner. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P28 码头入口渔政监控　〔监控〕

- **英文**：Fisheries CCTV at the pier entrance　**归属**：渔政　**场次**：第15场
- **出处**：第15场：「码头入口装着一个渔政监控」
- **外观**：立杆上的灰色枪机加太阳能板[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），码头入口渔政监控：立杆上的灰色枪机加太阳能板。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Fisheries CCTV at the pier entrance: grey bullet camera on a pole with a small solar panel . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P29 便利店监控　〔监控〕

- **英文**：Convenience store CCTV　**归属**：便利店　**场次**：第19场
- **出处**：第19场：「店里有监控，但知遥已经关掉了弹幕」
- **外观**：天花角落白色半球。
- **转面图提示词**：道具设定图（多视角转面图），便利店监控：天花角落白色半球。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Convenience store CCTV: white ceiling dome. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P30 墙上旧照片：海生站在船头抱着系红蝴蝶结的小女孩　〔道具〕

- **英文**：Old wall photo: Haisheng on the boat bow holding a little girl with a red bow　**归属**：夏家　**场次**：第2、24场
- **出处**：第2场：「墙上挂着一张旧照片：一个皮肤黝黑的男人站在一条小渔船船头，船头漆着白字“海生”。男人怀里抱着一个系着红蝴蝶结的小女孩。」；第24场：「墙上，旧照片旁边多了一个相框」
- **外观**：约30×20cm木框彩色旧照片，色彩褪成暖黄；画面内容如原文（船名白字后期）。
- 注：剧本第2场旧照片在一楼面馆墙上；第24场“墙上，旧照片旁边”在二楼客厅。是同一张挂在两处，还是两张照片？需确认（本表设为两处各一张同底片）。
- **转面图提示词**：道具设定图（多视角转面图），墙上旧照片：海生站在船头抱着系红蝴蝶结的小女孩：约30×20cm木框彩色旧照片，色彩褪成暖黄；画面内容如原文（船名白字后期）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：照片画面单独出一张（夏海生船长装+小知遥），再做褪色相框版。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Old wall photo: Haisheng on the boat bow holding a little girl with a red bow: about 30×20 cm wooden-framed old color photo faded warm-yellow, content as described (boat name added in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: make the photo image itself (captain Haisheng + little Zhiyao), then a faded framed version. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P31 旧相册（十岁生日照）　〔道具〕

- **英文**：Old photo album (10th birthday photo)　**归属**：夏家　**场次**：第4、5场
- **出处**：第4场：「靠墙的置物架上堆满腌菜罐、旧相册」；第5场：「相册翻开的那一页，是她十岁生日的照片：同一个蝴蝶结，同一个客厅，爸爸还在。」
- **外观**：厚布面旧相册，深红色封面，覆膜内页。
- **状态变化**：第5场：掉在地上翻开
- **转面图提示词**：道具设定图（多视角转面图），旧相册（十岁生日照）：厚布面旧相册，深红色封面，覆膜内页。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：翻开的十岁生日照内页。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Old photo album (10th birthday photo): thick cloth-bound old album, dark red cover, plastic-sleeve pages. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: open page with the 10th-birthday photo. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P32 客厅置物架陈设（腌菜罐、渔网结装饰）　〔道具〕

- **英文**：Living-room shelf dressing (pickle jars, knotted fishing-net decorations)　**归属**：夏家　**场次**：第4、5、21、24场
- **出处**：第4场：「靠墙的置物架上堆满腌菜罐、旧相册、渔网结成的装饰。」
- **外观**：玻璃腌菜罐数个（萝卜、梅子色），挂墙渔网结与浮球装饰。
- **转面图提示词**：道具设定图（多视角转面图），客厅置物架陈设（腌菜罐、渔网结装饰）：玻璃腌菜罐数个（萝卜、梅子色），挂墙渔网结与浮球装饰。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Living-room shelf dressing (pickle jars, knotted fishing-net decorations): several glass pickle jars, a knotted fishing net with floats as wall decor. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P33 客厅矮桌　〔道具〕

- **英文**：Living-room low table　**归属**：夏家　**场次**：第4、5、18、21、24场
- **出处**：第4场：「一张矮桌上摆着一个小蛋糕」；第21场：「和第1天一模一样的矮桌」；第24场：「和第1天、第17天一模一样的矮桌」
- **外观**：长方形实木矮桌约120×70cm，高35cm，桌面有使用痕迹。
- 注：第18场“晚饭桌”未说是矮桌，按同一张[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），客厅矮桌：长方形实木矮桌约120×70cm，高35cm，桌面有使用痕迹。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Living-room low table: rectangular solid-wood low table about 120×70 cm, 35 cm high, used surface. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P34 外婆的炒勺与铁锅　〔道具〕

- **英文**：Grandma's wok and ladle　**归属**：陈秀英　**场次**：第2、11场
- **出处**：第2场：「外婆单手颠勺」
- **外观**：黑铁炒锅带木柄，长柄不锈钢炒勺。
- **转面图提示词**：道具设定图（多视角转面图），外婆的炒勺与铁锅：黑铁炒锅带木柄，长柄不锈钢炒勺。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Grandma's wok and ladle: black iron wok with a wooden handle, long steel ladle. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P35 面馆面碗（虾仁面）　〔道具〕

- **英文**：Noodle-shop bowl (shrimp noodles)　**归属**：夏记面馆　**场次**：第2、4、11、14、18、24、25场
- **出处**：第2场：「外婆给你下了碗虾仁面」；第2场：「知遥端着面碗」；第18场：「三个人，三碗面」
- **外观**：白瓷大面碗，碗沿一圈蓝边[设计补充，与“砚”碗统一]。
- **转面图提示词**：道具设定图（多视角转面图），面馆面碗（虾仁面）：白瓷大面碗，碗沿一圈蓝边。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：俯视盛面。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Noodle-shop bowl (shrimp noodles): white porcelain noodle bowl with a blue rim . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: top view with noodles. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P36 收银台电话　〔道具〕

- **英文**：Cashier-counter landline　**归属**：夏红梅　**场次**：第2场
- **出处**：第2场：「一边接电话订货。」
- **外观**：米色老式座机。
- **转面图提示词**：道具设定图（多视角转面图），收银台电话：米色老式座机。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Cashier-counter landline: beige old landline. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P37 瓷盘（摔碎）　〔道具〕

- **英文**：Porcelain plate (smashed)　**归属**：夏家　**场次**：第5场
- **出处**：第5场：「知遥手一抖，手里的瓷盘“哐当”摔碎在地上。」
- **外观**：白瓷蛋糕盘，碎片状态。
- **状态变化**：第5场：摔碎
- **转面图提示词**：道具设定图（多视角转面图），瓷盘（摔碎）：白瓷蛋糕盘，碎片状态。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：碎片。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Porcelain plate (smashed): white porcelain cake plate, intact and shattered. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: shards. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P38 薯片　〔道具〕

- **英文**：Potato chips　**归属**：朵朵、豆豆　**场次**：第4场
- **出处**：第4场：「朵朵和豆豆已经坐在地上抢薯片。」
- **外观**：袋装薯片（包装无字）。
- **转面图提示词**：道具设定图（多视角转面图），薯片：袋装薯片（包装无字）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Potato chips: bag of chips (no text). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P39 保鲜盒（装饺子）　〔道具〕

- **英文**：Food container (dumplings)　**归属**：周静/周砚　**场次**：第4、9场
- **出处**：第4场：「手里端着一个保鲜盒」；第9场：「我妈让我还保鲜盒」
- **外观**：透明塑料保鲜盒蓝色扣盖，内装饺子。
- **状态变化**：第9场：归还，空盒
- **转面图提示词**：道具设定图（多视角转面图），保鲜盒（装饺子）：透明塑料保鲜盒蓝色扣盖，内装饺子。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Food container (dumplings): clear plastic container with blue clip lid, dumplings inside. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P40 打火机　〔道具〕

- **英文**：Lighter　**归属**：陈秀英　**场次**：第4场
- **出处**：第4场：「外婆“啪”地点燃打火机。」
- **外观**：红色一次性打火机。
- **转面图提示词**：道具设定图（多视角转面图），打火机：红色一次性打火机。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Lighter: red disposable lighter. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P41 搬家纸箱　〔道具〕

- **英文**：Moving boxes　**归属**：周家　**场次**：第2场
- **出处**：第2场：「搬家工人搬下纸箱」；第2场：「正把一个大纸箱扛上肩」
- **外观**：牛皮纸箱、胶带。
- **转面图提示词**：道具设定图（多视角转面图），搬家纸箱：牛皮纸箱、胶带。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Moving boxes: kraft cardboard boxes with tape. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P42 搬家小货车　〔交通工具〕

- **英文**：Small moving truck　**归属**：搬家公司　**场次**：第2场
- **出处**：第2场：「一辆小货车停在对面老楼门口」
- **外观**：白蓝小型厢式货车，车身无字。
- **转面图提示词**：道具设定图（多视角转面图），搬家小货车：白蓝小型厢式货车，车身无字。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Small moving truck: small white-blue box truck, no markings. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P43 老奶奶的两大袋菜　〔道具〕

- **英文**：Old lady's two heavy grocery bags　**归属**：路人老奶奶　**场次**：第2场
- **出处**：第2场：「一个拎着两大袋菜、走得踉踉跄跄的老奶奶，顺手接过袋子」
- **外观**：两只红白条纹塑料袋装满青菜。
- **转面图提示词**：道具设定图（多视角转面图），老奶奶的两大袋菜：两只红白条纹塑料袋装满青菜。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Old lady's two heavy grocery bags: two red-white striped plastic bags stuffed with vegetables. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P44 街坊阿姨的菜篮　〔道具〕

- **英文**：Neighbour aunties' shopping baskets　**归属**：阿姨甲/阿姨乙　**场次**：第2场
- **出处**：第2场：「两个街坊阿姨挎着菜篮」
- **外观**：阿姨甲：装青菜的藤编篮；阿姨乙：装紫茄子的红色塑料菜篮（据人物卡）。
- **转面图提示词**：道具设定图（多视角转面图），街坊阿姨的菜篮：阿姨甲：装青菜的藤编篮；阿姨乙：装紫茄子的红色塑料菜篮（据人物卡）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Neighbour aunties' shopping baskets: Auntie A: rattan basket of greens; Auntie B: red plastic basket of eggplants (per cards). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P45 外卖电动车（后视镜）　〔交通工具〕

- **英文**：Delivery e-scooter (with side mirror)　**归属**：外卖骑手　**场次**：第8场
- **出处**：第8场：「一辆送外卖的电动车逆行冲进窄巷……后视镜刮破了她书包侧袋的网兜。」
- **外观**：黄色[设计补充]外卖电动车，后座保温箱（无字），大后视镜，车灯。
- **转面图提示词**：道具设定图（多视角转面图），外卖电动车（后视镜）：黄色外卖电动车，后座保温箱（无字），大后视镜，车灯。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：后视镜特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Delivery e-scooter (with side mirror): yellow delivery e-scooter with an insulated box (no text), large side mirror, headlight. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: mirror close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P46 一小袋猫粮　〔道具〕

- **英文**：Small bag of cat food　**归属**：林豆豆　**场次**：第8、21场
- **出处**：第8场：「手里捧着一小袋猫粮。」；第21场：「一小袋猫粮也不见了。」
- **外观**：巴掌大的猫粮袋，橘色包装（无字）。
- **转面图提示词**：道具设定图（多视角转面图），一小袋猫粮：巴掌大的猫粮袋，橘色包装（无字）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Small bag of cat food: palm-sized cat-food pouch, orange packaging, no text. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P47 豆豆的明黄色雨衣（崭新）　〔道具〕

- **英文**：Doudou's bright-yellow raincoat (brand new)　**归属**：林豆豆　**场次**：第8、13、15、21、22、23场
- **出处**：第8场：「一个穿着崭新明黄色雨衣的小男孩」；第21场：「门口的挂钩上，那件明黄色的小雨衣不见了」；第13场：「台风季满街小孩都穿黄雨衣」
- **外观**：儿童连帽长雨衣，明黄色有光泽PVC，按扣门襟，及膝。
- **状态变化**：第21场：本该挂在后门挂钩上，不见了；第22场：湿透
- 注：同时是服装 LDou-L2。
- **转面图提示词**：道具设定图（多视角转面图），豆豆的明黄色雨衣（崭新）：儿童连帽长雨衣，明黄色有光泽PVC，按扣门襟，及膝。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：帽子、按扣、挂在挂钩上的状态、湿透状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Doudou's bright-yellow raincoat (brand new): child's hooded long raincoat in glossy bright-yellow PVC, snap front, knee length. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: hood, snaps, hanging on the hook, soaked. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P48 后门挂钩（空）　〔道具〕

- **英文**：Back-door coat hook (empty)　**归属**：夏记面馆　**场次**：第21场
- **出处**：第21场：「“黄雨衣不见了”用空挂钩的特写。」
- **外观**：门内侧铸铁单挂钩。
- **转面图提示词**：道具设定图（多视角转面图），后门挂钩（空）：门内侧铸铁单挂钩。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：空挂钩特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Back-door coat hook (empty): single cast-iron hook on the inside of the door. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: empty hook close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P49 创可贴盒+周砚的便利贴　〔道具〕

- **英文**：Box of band-aids with Zhou Yan's sticky note　**归属**：周砚　**场次**：第9场
- **出处**：第9场：「他递过一盒创可贴」；第9场：「里面掉出一张便利贴，是周砚的字，很工整：“第4天那条巷子，以后别走了。”」
- **外观**：小纸盒创可贴（无字），一张淡黄便利贴，工整字迹（后期）。
- **转面图提示词**：道具设定图（多视角转面图），创可贴盒+周砚的便利贴：小纸盒创可贴（无字），一张淡黄便利贴，工整字迹（后期）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：便利贴特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Box of band-aids with Zhou Yan's sticky note: small paper box of band-aids (no text), one pale-yellow sticky note with neat handwriting (in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: sticky note close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P50 塑料袋　〔道具〕

- **英文**：Plastic bag　**归属**：周砚　**场次**：第9场
- **出处**：第9场：「手里拎着一个塑料袋。」
- **外观**：白色半透明塑料袋，装保鲜盒和创可贴。
- **转面图提示词**：道具设定图（多视角转面图），塑料袋：白色半透明塑料袋，装保鲜盒和创可贴。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Plastic bag: translucent white plastic bag. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P51 剥虾（虾、虾壳、小板凳）　〔道具〕

- **英文**：Peeling shrimp (shrimp, shells, small stool)　**归属**：夏知遥　**场次**：第9场
- **出处**：第9场：「知遥坐在小板凳上剥虾。」；第9场：「她剥虾时被虾壳划破的指尖正渗着血珠」
- **外观**：不锈钢盆装鲜虾、一盆虾壳，红色塑料小板凳。
- **转面图提示词**：道具设定图（多视角转面图），剥虾（虾、虾壳、小板凳）：不锈钢盆装鲜虾、一盆虾壳，红色塑料小板凳。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Peeling shrimp (shrimp, shells, small stool): steel bowls of shrimp and shells, small red plastic stool. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P52 面团、案板与湿布　〔道具〕

- **英文**：Dough, kneading board and damp cloth　**归属**：陈秀英　**场次**：第9场
- **出处**：第9场：「把面团“啪”地摔在案板上」；第9场：「外婆把面团盖上湿布」
- **外观**：大块白面团，厚木案板，白纱湿布。
- **转面图提示词**：道具设定图（多视角转面图），面团、案板与湿布：大块白面团，厚木案板，白纱湿布。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Dough, kneading board and damp cloth: large white dough, thick wooden board, white damp cloth. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P53 避风塘泊位缴费单　〔道具〕

- **英文**：Typhoon-shelter berth fee receipt　**归属**：夏红梅　**场次**：第9、21场
- **出处**：第9场：「特写缴费单：“澄港避风塘泊位年费｜船名：海生号｜缴费人：夏红梅”。日期是今年。」；第21场：「围裙口袋里露出的一角，是那张折起来的泊位缴费单」
- **外观**：三联收据式A5单据，浅粉色[设计补充]，折成小方块；文字后期。
- **状态变化**：第9场：折起塞进围裙口袋；第21场：从围裙口袋露出一角
- **转面图提示词**：道具设定图（多视角转面图），避风塘泊位缴费单：三联收据式A5单据，浅粉色，折成小方块；文字后期。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：展开与折叠特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Typhoon-shelter berth fee receipt: A5 triplicate receipt, pale pink , folded into a small square; text added in post. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: unfolded and folded close-ups. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P54 便当　〔道具〕

- **英文**：Lunch box　**归属**：夏知遥　**场次**：第10场
- **出处**：第10场：「知遥一个人坐在水箱阴影下吃便当」
- **外观**：双层便当盒，浅蓝色[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），便当：双层便当盒，浅蓝色。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：打开俯视。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Lunch box: two-tier bento box, light blue . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: open top view. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P55 宋佳怡的手机　〔道具〕

- **英文**：Song Jiayi's phone　**归属**：宋佳怡　**场次**：第10、16、17、20场
- **出处**：第10场：「掏出手机“咔嚓”拍了一张」；第16场：「手机举到一半，又犹豫着放下了」；第20场：「在班级群里发了一段自己当天在后门拍的……视频」
- **外观**：白色手机壳。
- **转面图提示词**：道具设定图（多视角转面图），宋佳怡的手机：白色手机壳。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Song Jiayi's phone: phone with a white case. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P56 天台合照（藏青外套下两人）　〔画面道具〕

- **英文**：The rooftop photo (two people under one navy jacket)　**归属**：宋佳怡拍/柯一鸣展示　**场次**：第10、17场
- **出处**：第17场：「屏幕上是一张照片：雨中天台，两个人挤在一件藏青外套底下」
- **外观**：手机屏内照片画面（雨中，水箱屋檐下两人共披外套）。
- **转面图提示词**：道具设定图（多视角转面图），天台合照（藏青外套下两人）：手机屏内照片画面（雨中，水箱屋檐下两人共披外套）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, The rooftop photo (two people under one navy jacket): photo on a phone screen: in the rain, two people under one jacket beneath the water-tank eave. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P57 后厨火灾隐患组（油锅、汤锅、燃气灶、抹布、水池）　〔道具〕

- **英文**：Kitchen fire-hazard set (fryer, soup pot, gas stove, dish rag, sink)　**归属**：夏记面馆　**场次**：第11场
- **出处**：第11场：「油锅烧得滋滋响。旁边的燃气灶上，一口汤锅的锅柄斜伸出灶台边缘，离油锅只有一拳远。灶台边的抹布垂下来，一角挨着火苗。」；第11场：「扔进水池。又把伸出灶台的汤锅柄转回来」
- **外观**：深口黑铁油锅；铝制汤锅长柄；双眼燃气灶；灰白格子抹布。
- **状态变化**：第11场：7:02危险布局→知遥处理后安全
- **转面图提示词**：道具设定图（多视角转面图），后厨火灾隐患组（油锅、汤锅、燃气灶、抹布、水池）：深口黑铁油锅；铝制汤锅长柄；双眼燃气灶；灰白格子抹布。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：危险状态（锅柄外伸、抹布挨火）与安全状态对照。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Kitchen fire-hazard set (fryer, soup pot, gas stove, dish rag, sink): deep black iron fryer; aluminium soup pot with long handle; double gas burner; grey-white checked rag. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: hazard state (handle sticking out, rag touching flame) vs safe state. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P58 挂钟（面馆后厨/客厅）　〔道具〕

- **英文**：Wall clocks (kitchen / living room)　**归属**：夏家　**场次**：第6、11、21场
- **出处**：第11场：「墙上的钟：7:15。」；第21场：「墙上的挂钟：8:52。」；第6场：「房间里只剩钟表的嘀嗒声」
- **外观**：后厨：白底黑针圆形挂钟带秒针；客厅：木框圆钟[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），挂钟（面馆后厨/客厅）：后厨：白底黑针圆形挂钟带秒针；客厅：木框圆钟。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：指针特写（时间后期可调）。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Wall clocks (kitchen / living room): kitchen: white round clock with second hand; living room: wooden round clock . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: hands close-up. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P59 红色灭火器（压力表指针在绿区）　〔道具〕

- **英文**：Red fire extinguisher (gauge in the green)　**归属**：周砚家　**场次**：第11场
- **出处**：第11场：「手里拎着一个红色的灭火器」；第11场：「灭火器的压力表——指针在绿色区域，是满的。」
- **外观**：4kg红色干粉灭火器，黑色喷管，压力表。
- **状态变化**：第11场：被放在后巷地上
- **转面图提示词**：道具设定图（多视角转面图），红色灭火器（压力表指针在绿区）：4kg红色干粉灭火器，黑色喷管，压力表。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：压力表特写（指针在绿区）。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Red fire extinguisher (gauge in the green): 4 kg red dry-powder extinguisher with black hose and pressure gauge. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: gauge close-up with needle in green. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P60 毛巾　〔道具〕

- **英文**：Hand towel　**归属**：面馆　**场次**：第11场
- **出处**：第11场：「知遥抓起一条毛巾擦了擦手」
- **外观**：白色旧毛巾。
- **转面图提示词**：道具设定图（多视角转面图），毛巾：白色旧毛巾。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Hand towel: worn white towel. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P61 虾饼　〔道具〕

- **英文**：Shrimp cakes　**归属**：陈秀英　**场次**：第11场
- **出处**：第11场：「外婆正在炸虾饼」；第11场：「这家的虾饼看着好好吃」
- **外观**：金黄圆形炸虾饼，表面嵌整只虾。
- **转面图提示词**：道具设定图（多视角转面图），虾饼：金黄圆形炸虾饼，表面嵌整只虾。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Shrimp cakes: golden round fried shrimp cakes with whole shrimp on top. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P62 水果盘（四盘，第四盘剥好的橘子）与糖水　〔道具〕

- **英文**：Fruit plates (four; the fourth peeled oranges) and sweet soup　**归属**：陈秀英　**场次**：第13场
- **出处**：第13场：「每次都端着一盘不同的水果」；第13场：「外婆端着第四盘水果，这次是一盘剥好的橘子。」；第13场：「阿婆给你们煮糖水」
- **外观**：白瓷圆盘：西瓜、葡萄、苹果[设计补充]、剥好的橘子。
- **转面图提示词**：道具设定图（多视角转面图），水果盘（四盘，第四盘剥好的橘子）与糖水：白瓷圆盘：西瓜、葡萄、苹果、剥好的橘子。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Fruit plates (four; the fourth peeled oranges) and sweet soup: white plates of watermelon, grapes, apple , peeled oranges. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P63 跑道上的碎石　〔道具〕

- **英文**：Pebble on the track　**归属**：—　**场次**：第13场
- **出处**：第13场：「他提前把跑道上的一颗碎石踢开。」
- **外观**：指甲盖大小灰色碎石。
- **转面图提示词**：道具设定图（多视角转面图），跑道上的碎石：指甲盖大小灰色碎石。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Pebble on the track: fingernail-sized grey pebble. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P64 冰箱门上的黄色便利贴（周静留言）与知遥留下的一张　〔道具〕

- **英文**：Yellow sticky notes on the fridge (Zhou Jing's) plus one from Zhiyao　**归属**：周静/夏知遥　**场次**：第14场
- **出处**：第14场：「冰箱门上贴满了黄色便利贴，全是周静的字」；第14场：「知遥回家前，在冰箱门上贴了一张自己的便利贴：“周砚的面，很好吃。第10天，镜头外。”」
- **外观**：黄色方形便利贴二十余张贴满冰箱门，手写（文字后期）；知遥那张用浅蓝便利贴[设计补充]以区分。
- 注：characters.md 周静“代表元素：便利贴、保温盒”。
- **转面图提示词**：道具设定图（多视角转面图），冰箱门上的黄色便利贴（周静留言）与知遥留下的一张：黄色方形便利贴二十余张贴满冰箱门，手写（文字后期）；知遥那张用浅蓝便利贴以区分。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Yellow sticky notes on the fridge (Zhou Jing's) plus one from Zhiyao: twenty-plus yellow square sticky notes covering the fridge door, handwritten (text in post); Zhiyao's one in light blue to stand out. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P65 周砚的围裙　〔道具〕

- **英文**：Zhou Yan's apron　**归属**：周砚　**场次**：第14场
- **出处**：第14场：「周砚系着围裙在小厨房里煎蛋。」
- **外观**：深灰色素面挂脖围裙[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），周砚的围裙：深灰色素面挂脖围裙。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhou Yan's apron: plain dark-grey bib apron . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P66 煎蛋与两碗面　〔道具〕

- **英文**：Fried eggs and two bowls of noodles　**归属**：周砚　**场次**：第14场
- **出处**：第14场：「煎蛋“滋啦”一声。他把两碗面端到小桌上」
- **外观**：两只普通白碗清汤面，各卧一只煎蛋。
- **转面图提示词**：道具设定图（多视角转面图），煎蛋与两碗面：两只普通白碗清汤面，各卧一只煎蛋。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Fried eggs and two bowls of noodles: two plain white bowls of noodle soup each topped with a fried egg. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P67 鞋盒与游泳奖牌　〔道具〕

- **英文**：Shoebox of swimming medals　**归属**：周砚　**场次**：第14场
- **出处**：第14场：「一个敞开的鞋盒里，堆着十几块游泳比赛的奖牌，最上面一块是金色的。」
- **外观**：打开的旧鞋盒，十几块金银铜奖牌带蓝色挂带，最上面一块金色。
- **转面图提示词**：道具设定图（多视角转面图），鞋盒与游泳奖牌：打开的旧鞋盒，十几块金银铜奖牌带蓝色挂带，最上面一块金色。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：俯视。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Shoebox of swimming medals: open old shoebox with a dozen gold/silver/bronze medals on blue ribbons, a gold one on top. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: top view. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P68 周砚的手写日历（9/1–9/17，17日涂黑）　〔道具〕

- **英文**：Zhou Yan's handwritten calendar (1–17 Sept, the 17th blacked out)　**归属**：周砚　**场次**：第14场
- **出处**：第14场：「每个日期旁边都用红笔圈着小字……只有17日那一格，被涂成了一整块黑色。」
- **外观**：一张A4纸手画17格日历，红笔圈注（文字后期），第17格整块黑色马克笔涂满，压在书桌玻璃下。
- **转面图提示词**：道具设定图（多视角转面图），周砚的手写日历（9/1–9/17，17日涂黑）：一张A4纸手画17格日历，红笔圈注（文字后期），第17格整块黑色马克笔涂满，压在书桌玻璃下。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：第17格黑块特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhou Yan's handwritten calendar (1–17 Sept, the 17th blacked out): an A4 sheet hand-drawn into 17 boxes with red-pen circles (text in post), box 17 filled solid black with marker, under the desk glass. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the black box. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P69 泳镜（提及）　〔道具〕

- **英文**：Swim goggles (mentioned)　**归属**：周砚　**场次**：第14场
- **出处**：第14场：「放学后我去器材室还泳镜」
- **外观**：蓝色镜片泳镜。
- 注：人物卡代表元素之一；剧本只在台词中提及。
- **转面图提示词**：道具设定图（多视角转面图），泳镜（提及）：蓝色镜片泳镜。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Swim goggles (mentioned): blue-lens swim goggles. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P70 饭卡（闪回）　〔道具〕

- **英文**：Meal card (flashback)　**归属**：许小满　**场次**：第14场
- **出处**：第14场：「他们抢他的饭卡」
- **外观**：白色塑料校园卡。
- **转面图提示词**：道具设定图（多视角转面图），饭卡（闪回）：白色塑料校园卡。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Meal card (flashback): white plastic school card. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P71 消防栓箱（闪回）　〔道具〕

- **英文**：Fire-hydrant cabinet (flashback)　**归属**：旧学校　**场次**：第14场
- **出处**：第14场：「躲在消防栓后面拍」
- **外观**：红色墙嵌消防栓箱。
- **转面图提示词**：道具设定图（多视角转面图），消防栓箱（闪回）：红色墙嵌消防栓箱。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Fire-hydrant cabinet (flashback): red wall-mounted hydrant cabinet. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P72 一袋鱼蛋　〔道具〕

- **英文**：Bag of fish balls　**归属**：—　**场次**：第15场
- **出处**：第15场：「两人坐在船头分一袋鱼蛋，周砚把最后一颗让给她。」
- **外观**：纸袋/竹签咖喱鱼蛋[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），一袋鱼蛋：纸袋/竹签咖喱鱼蛋。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Bag of fish balls: paper bag of curry fish balls on skewers . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P73 宋佳怡的纸条　〔道具〕

- **英文**：Song Jiayi's note　**归属**：宋佳怡　**场次**：第18场
- **出处**：第18场：「一张被揉皱的小纸条掉了出来，是宋佳怡的字」
- **外观**：巴掌大的横格纸，揉皱后展开。
- **转面图提示词**：道具设定图（多视角转面图），宋佳怡的纸条：巴掌大的横格纸，揉皱后展开。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Song Jiayi's note: palm-sized lined note paper, crumpled and unfolded. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P74 知遥卧室墙上的日历　〔道具〕

- **英文**：Wall calendar in Zhiyao's room　**归属**：夏知遥　**场次**：第18场
- **出处**：第18场：「看向墙上的日历：9月14日。还剩3天。」
- **外观**：挂墙月历，九月页。
- **转面图提示词**：道具设定图（多视角转面图），知遥卧室墙上的日历：挂墙月历，九月页。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Wall calendar in Zhiyao's room: hanging monthly calendar on the September page. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P75 晚饭：三碗面、排骨、筷子　〔道具〕

- **英文**：Dinner: three bowls of noodles, spare ribs, chopsticks　**归属**：夏家　**场次**：第18场
- **出处**：第18场：「往知遥碗里多夹了一块排骨。」；第18场：「她把筷子拍在桌上」
- **外观**：三只面碗、一盘红烧排骨、竹筷。
- **转面图提示词**：道具设定图（多视角转面图），晚饭：三碗面、排骨、筷子：三只面碗、一盘红烧排骨、竹筷。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Dinner: three bowls of noodles, spare ribs, chopsticks: three noodle bowls, a plate of braised ribs, bamboo chopsticks. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P76 汤勺（熬汤）　〔道具〕

- **英文**：Soup ladle　**归属**：夏红梅　**场次**：第20场
- **出处**：第20场：「夏红梅手里的汤勺停住了。」
- **外观**：长柄不锈钢汤勺，大汤锅。
- **转面图提示词**：道具设定图（多视角转面图），汤勺（熬汤）：长柄不锈钢汤勺，大汤锅。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Soup ladle: long steel ladle and a big stockpot. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P77 客厅旧电视　〔道具〕

- **英文**：Living-room TV　**归属**：夏家　**场次**：第21、24场
- **出处**：第21场：「电视里在播台风橙色预警」；第24场：「电视里播着本地新闻」
- **外观**：小尺寸平板电视放在电视柜上（画面后期）。
- **转面图提示词**：道具设定图（多视角转面图），客厅旧电视：小尺寸平板电视放在电视柜上（画面后期）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Living-room TV: small flat TV on the cabinet (screen in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P78 一大锅海鲜粥与勺子　〔道具〕

- **英文**：Big pot of seafood congee and spoons　**归属**：陈秀英　**场次**：第21场
- **出处**：第21场：「桌上是外婆煮的一大锅海鲜粥。」；第21场：「知遥攥紧了手里的勺子。」
- **外观**：砂锅/大铁锅海鲜粥，白瓷勺。
- **转面图提示词**：道具设定图（多视角转面图），一大锅海鲜粥与勺子：砂锅/大铁锅海鲜粥，白瓷勺。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Big pot of seafood congee and spoons: big clay pot of seafood congee, white porcelain spoons. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P79 海生号旧钥匙串（褪色小木牌刻“海生”）　〔道具〕

- **英文**：Old key ring of the Haisheng with a faded wooden tag　**归属**：夏红梅　**场次**：第21场
- **出处**：第21场：「抓起挂在墙上的一串旧钥匙，钥匙环上挂着一个褪色的小木牌，刻着“海生”。」
- **外观**：铜钥匙三四把串在铁环上，椭圆小木牌褪色发白，刻字（后期修字）。
- 注：挂在墙上的位置剧本未写——本表设为面馆一楼门边墙钉[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），海生号旧钥匙串（褪色小木牌刻“海生”）：铜钥匙三四把串在铁环上，椭圆小木牌褪色发白，刻字（后期修字）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：木牌刻字特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Old key ring of the Haisheng with a faded wooden tag: three or four brass keys on an iron ring with a small faded oval wooden tag with carved characters (fix text in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the carved tag. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P80 夏红梅的电动车　〔交通工具〕

- **英文**：Xia Hongmei's e-bike　**归属**：夏红梅　**场次**：第21场
- **出处**：第21场：「夏红梅推着电动车冲进雨里」
- **外观**：深蓝色[设计补充]老款电动自行车，带车篮。
- **转面图提示词**：道具设定图（多视角转面图），夏红梅的电动车：深蓝色老款电动自行车，带车篮。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Xia Hongmei's e-bike: old dark-blue electric bicycle with front basket. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P81 海生号（旧小机动渔船，船头白字“海生”）　〔交通工具〕

- **英文**：The Haisheng (old small motor fishing boat, white characters on the bow)　**归属**：夏海生→夏红梅　**场次**：第2、15、21、23、25场
- **出处**：设定（第三~六节）：「父亲的旧小机动渔船，船头漆着白字“海生”，泊在避风塘里。十年没人开过」；第15场：「船身的漆斑驳了，船头还能看清两个白字：“海生”。」；第23场：「船头的“海生”二字在雨里闪着白光。」；第25场：「海生号重新漆过的船头」
- **外观**：长约7米[设计补充]木质小机动渔船，蓝白[设计补充]船身漆斑驳，船头左右两侧白漆“海生”二字（后期修字），船尾舵柄+挂机，船舷挂旧救生圈，船尾支架装手持探照灯。
- **状态变化**：第2场：照片里：新船；第15场：十年未开，漆斑驳；第23场：台风夜开出救人；第25场：重新漆过
- 注：船体颜色剧本未写，[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），海生号（旧小机动渔船，船头白字“海生”）：长约7米木质小机动渔船，蓝白船身漆斑驳，船头左右两侧白漆“海生”二字（后期修字），船尾舵柄+挂机，船舷挂旧救生圈，船尾支架装手持探照灯。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：船头漆字、船尾舵位、救生圈、斑驳漆面/重漆两种状态。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, The Haisheng (old small motor fishing boat, white characters on the bow): about 7 m wooden small motor fishing boat with weathered blue-and-white paint , white painted name on both sides of the bow (fix text in post), tiller and outboard at the stern, old life ring on the gunwale, handheld searchlight at the stern. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: bow lettering, stern helm, life ring, weathered vs repainted. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P82 海生号手持探照灯　〔道具〕

- **英文**：Handheld searchlight on the Haisheng　**归属**：夏红梅　**场次**：第23场
- **出处**：第23场：「一只手握着探照灯」；第23场：「一道雪白的探照灯光柱，像一把剑，劈开了雨幕。」
- **外观**：黄色[设计补充]手持船用探照灯，圆形大灯头。
- **转面图提示词**：道具设定图（多视角转面图），海生号手持探照灯：黄色手持船用探照灯，圆形大灯头。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：灯头特写/开灯光柱。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Handheld searchlight on the Haisheng: yellow handheld marine searchlight with a large round head. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: head close-up / beam on. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P83 旧救生圈（印褪色“海生”）　〔道具〕

- **英文**：Old life ring printed with a faded 'Haisheng'　**归属**：海生号　**场次**：第23场
- **出处**：第23场：「一个旧救生圈被扔了过来，圈上印着褪色的“海生”。」
- **外观**：橙红白相间旧救生圈，带绳，字迹褪色（后期）。
- **转面图提示词**：道具设定图（多视角转面图），旧救生圈（印褪色“海生”）：橙红白相间旧救生圈，带绳，字迹褪色（后期）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Old life ring printed with a faded 'Haisheng': old orange-and-white life ring with rope, faded lettering (in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P84 毯子　〔道具〕

- **英文**：Blanket　**归属**：夏红梅　**场次**：第23场
- **出处**：第23场：「知遥（裹着母亲递来的毯子」；第23场：「在毯子底下找到他冰凉的手」
- **外观**：灰色旧毛毯[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），毯子：灰色旧毛毯。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Blanket: old grey wool blanket . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P85 海上救援橙色救生艇　〔交通工具〕

- **英文**：Orange sea-rescue boat　**归属**：海上救援　**场次**：第23场
- **出处**：第23场：「海上救援的橙色救生艇亮着警灯驶进避风塘。」
- **外观**：橙色硬壳充气救生艇，顶灯蓝红警灯（无字）。
- **转面图提示词**：道具设定图（多视角转面图），海上救援橙色救生艇：橙色硬壳充气救生艇，顶灯蓝红警灯（无字）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Orange sea-rescue boat: orange rigid inflatable rescue boat with flashing warning lights (no text). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P86 漂浮物：断缆绳与泡沫箱　〔道具〕

- **英文**：Floating debris: broken ropes and foam boxes　**归属**：—　**场次**：第23场
- **出处**：第23场：「漂满了断掉的缆绳和泡沫箱。」；第23场：「扫过一个泡沫箱，扫过一段断缆」
- **外观**：白色泡沫鱼箱、断裂的蓝色/黄色尼龙缆绳。
- **转面图提示词**：道具设定图（多视角转面图），漂浮物：断缆绳与泡沫箱：白色泡沫鱼箱、断裂的蓝色/黄色尼龙缆绳。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Floating debris: broken ropes and foam boxes: white styrofoam fish boxes, snapped blue/yellow nylon ropes. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P87 一个月后的饭菜：红烧鱼、周静带的一锅汤、瓜子　〔道具〕

- **英文**：Dinner a month later: braised fish, Zhou Jing's pot of soup, sunflower seeds　**归属**：夏家/周静/朵朵　**场次**：第24场
- **出处**：第24场：「外婆端上一大盆红烧鱼。周静带来了一锅汤。」；第24场：「朵朵塞给他一大把瓜子。」
- **外观**：大瓷盆红烧鱼、带盖汤锅、一捧瓜子。
- 注：characters.md 周静代表元素“保温盒”：汤锅可做成保温桶[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），一个月后的饭菜：红烧鱼、周静带的一锅汤、瓜子：大瓷盆红烧鱼、带盖汤锅、一捧瓜子。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Dinner a month later: braised fish, Zhou Jing's pot of soup, sunflower seeds: big bowl of red-braised fish, lidded soup pot, a handful of sunflower seeds. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P88 写着“砚”字的新碗（蓝边白瓷）　〔道具〕

- **英文**：New bowl with 砚 painted inside (blue-rimmed white porcelain)　**归属**：夏红梅送周砚　**场次**：第24场
- **出处**：第24场：「拿出一只新碗，蓝边白瓷，碗底用红漆写了一个小小的“砚”字」
- **外观**：蓝边白瓷饭碗，碗底中央红漆小字（后期修字）。
- **转面图提示词**：道具设定图（多视角转面图），写着“砚”字的新碗（蓝边白瓷）：蓝边白瓷饭碗，碗底中央红漆小字（后期修字）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：碗底红字特写。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, New bowl with 砚 painted inside (blue-rimmed white porcelain): blue-rimmed white porcelain rice bowl, a small red-painted character at the bottom center (fix in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: close-up of the bowl bottom. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P89 “澄港少年游泳队”训练包　〔道具〕

- **英文**：Chenggang Youth Swim Team training bag　**归属**：周砚　**场次**：第24场
- **出处**：第24场：「手里提着一个印着“澄港少年游泳队”的训练包」
- **外观**：藏青色手提运动包，侧面白色印字（后期）、浪花标志与徽章一致。
- **转面图提示词**：道具设定图（多视角转面图），“澄港少年游泳队”训练包：藏青色手提运动包，侧面白色印字（后期）、浪花标志与徽章一致。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Chenggang Youth Swim Team training bag: navy duffel bag with white side print (in post) and the same wave emblem as the badge. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P90 校报剪报相框（征文一等奖）　〔道具〕

- **英文**：Framed newspaper clipping (essay first prize)　**归属**：夏家　**场次**：第24场
- **出处**：第24场：「旁边多了一个相框，是第七中学校报的剪报：征文一等奖《港口的早晨》，作者夏知遥。相框底下压着那半根烧剩的数字蜡烛“17”。」
- **外观**：简洁木框，内为泛黄校报剪报（文字后期）。
- **转面图提示词**：道具设定图（多视角转面图），校报剪报相框（征文一等奖）：简洁木框，内为泛黄校报剪报（文字后期）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Framed newspaper clipping (essay first prize): simple wooden frame holding a school-newspaper clipping (text in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P91 黑白老照片：年轻外婆与穿海魂衫的小伙子在渔船前　〔道具〕

- **英文**：Old B&W photo: young Grandma and a young man in a striped sailor shirt before a fishing boat　**归属**：陈秀英　**场次**：第25场
- **出处**：第25场：「墙上挂着一张很旧的黑白照片：年轻的外婆和一个穿海魂衫的小伙子，站在一条渔船前。」
- **外观**：小幅黑白照片，白边，钉在后厨墙上，四角发黄。
- **转面图提示词**：道具设定图（多视角转面图），黑白老照片：年轻外婆与穿海魂衫的小伙子在渔船前：小幅黑白照片，白边，钉在后厨墙上，四角发黄。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：照片画面单独出一张。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Old B&W photo: young Grandma and a young man in a striped sailor shirt before a fishing boat: small black-and-white photo with white border pinned to the kitchen wall, yellowed corners. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: make the photo image itself. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P92 碗架与洗碗　〔道具〕

- **英文**：Dish rack and washing up　**归属**：陈秀英　**场次**：第25场
- **出处**：第25场：「她把碗放进碗架」
- **外观**：不锈钢碗架，叠放面碗。
- **转面图提示词**：道具设定图（多视角转面图），碗架与洗碗：不锈钢碗架，叠放面碗。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Dish rack and washing up: steel dish rack with stacked bowls. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P93 许小满的手写纸牌（看台）　〔道具〕

- **英文**：Xu Xiaoman's handmade sign (in the stands)　**归属**：许小满　**场次**：第25场
- **出处**：第25场：「看台上一个举着纸牌而不是手机的许小满」
- **外观**：A3白卡纸，手写加油字（后期）。
- **转面图提示词**：道具设定图（多视角转面图），许小满的手写纸牌（看台）：A3白卡纸，手写加油字（后期）。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Xu Xiaoman's handmade sign (in the stands): A3 white card with handwritten cheer (text in post). Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P94 剪刀（OP意象）　〔意象道具〕

- **英文**：Scissors (opening-title motif)　**归属**：—　**场次**：第6场
- **出处**：第6场：「一个画面被剪刀“咔嚓”剪成两半，又被一双手拼回去。」
- **外观**：银色大剪刀。
- **转面图提示词**：道具设定图（多视角转面图），剪刀（OP意象）：银色大剪刀。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Scissors (opening-title motif): large silver scissors. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P95 知遥书桌台灯　〔道具〕

- **英文**：Zhiyao's desk lamp　**归属**：夏知遥　**场次**：第6、13场
- **出处**：第6场：「深夜，台灯下。」；第13场：「书桌上的台灯开着暖光。」
- **外观**：奶油色金属摇臂台灯，暖光。
- **转面图提示词**：道具设定图（多视角转面图），知遥书桌台灯：奶油色金属摇臂台灯，暖光。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhiyao's desk lamp: cream metal arm desk lamp with warm light. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P96 周砚的手机　〔道具〕

- **英文**：Zhou Yan's phone　**归属**：周砚　**场次**：第14、17、20场
- **出处**：第14场：「电话响了，是周静打来的。周砚开了免提。」；第17场：「是周砚发来的消息」；第20场：「手机屏幕的光照着他的脸」
- **外观**：黑色手机壳。
- **转面图提示词**：道具设定图（多视角转面图），周砚的手机：黑色手机壳。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Zhou Yan's phone: phone with a black case. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P97 外婆的手机　〔道具〕

- **英文**：Grandma's phone　**归属**：陈秀英　**场次**：第20场
- **出处**：第20场：「外婆举着手机给每个食客看」
- **外观**：大字老人机/大屏手机，红色壳[设计补充]。
- **转面图提示词**：道具设定图（多视角转面图），外婆的手机：大字老人机/大屏手机，红色壳。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Grandma's phone: big-screen phone with a red case . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P98 避风塘小渔船群（背景船）　〔交通工具〕

- **英文**：Fleet of small fishing boats in the shelter (background boats)　**归属**：—　**场次**：第1、12、15、25场
- **出处**：第12场：「右边是平静的避风塘，停着十几条小渔船。」；第15场：「渔船一条条回港，海鸥在桅杆间盘旋。」
- **外观**：各色小木渔船，桅杆、渔网、旗。
- **转面图提示词**：道具设定图（多视角转面图），避风塘小渔船群（背景船）：各色小木渔船，桅杆、渔网、旗。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, Fleet of small fishing boats in the shelter (background boats): assorted small wooden fishing boats with masts, nets and flags. Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

### P99 公交车（仅提及）　〔交通工具〕

- **英文**：City bus (mentioned only)　**归属**：—　**场次**：第19场
- **出处**：第19场：「知遥坐了四十分钟的公交，穿过半个澄港」
- **外观**：剧本未出画；如需过场可做浅绿色城市公交[设计补充]。
- 注：仅台词/动作描述，未明确出画。
- **转面图提示词**：道具设定图（多视角转面图），公交车（仅提及）：剧本未出画；如需过场可做浅绿色城市公交。白色纯背景，同一物体的正视图、侧视图、背视图、俯视图四个视角整齐横向并排，比例一致，下方一排局部特写：主要材质与磨损细节。日式剧场版动画美术设定风格，干净线条，赛璐珞上色，均匀平光，无文字，无标注，无水印，无人物
- **Turnaround (EN)**: prop turnaround sheet, City bus (mentioned only): not shown in script; optional light-green city bus . Plain white background, the same object shown in front, side, back and top views in one row at consistent scale, a row of detail close-ups below: material and wear details. Japanese theatrical anime design-sheet style, clean lines, cel shading, flat even lighting, no text, no labels, no watermark, no people

## 三、服装／造型

### 夏知遥

#### ZY-L1　校服（白衬衫红领结+奶油开衫+格纹百褶裙+过膝袜）

- **场次**：第2、3、6、7、8、10、12、13、15、16、17、19、20场　**参考图**：`cards/xiazhiyao_card1.jpg`
- **出处**：第2场：「白衬衫、红领结、奶油色开衫、深色格纹裙。长发散着，手里捏着那个红蝴蝶结。」；设定（第三~六节）：「深色过膝袜和小皮鞋」；第20场：「知遥换好校服下楼」
- **服装**：白色长袖衬衫，领口红色领结；奶油色V领针织开衫（扣好）；深色格纹百褶裙；深色过膝袜（袜口在膝上大腿处，裙摆下只露一小截皮肤）；棕色小皮鞋。
- **发型**：及腰黑长直发，中分微空气刘海；后脑稍高处红色双环蝴蝶结（P01），正面双环对称探出头顶，绝不偏一侧、不盖耳朵　**配饰**：红蝴蝶结（P01）、书包（P11）（关联道具 P01, P11）
- **变体 A 第2场开场：长发散着未系蝴蝶结**（第2场）：同上，蝴蝶结拿在手里
- **变体 B 第10场雨中：外套罩头、裙摆与袜子溅湿**（第10场）：头上罩藏青外套，开衫肩部和裙摆湿
- **变体 C 第16场：蝴蝶结被扯歪**（第16场）：蝴蝶结歪向一侧（仅此场例外）
- **变体 D 第19场深夜外出[设计补充]**（第19场）：同校服，外加开衫扣好，雨后发梢微湿
- 注：第8场“补习班下课”、第12/15/16场“放学后”、第17场听证会（上学日上午）剧本未写服装，按校服[设计补充]。
- 注：第19场深夜去便利店服装未写，[设计补充]用校服。
- **三视图提示词**：服装设定图，夏知遥的造型「校服（白衬衫红领结+奶油开衫+格纹百褶裙+过膝袜）」：白色长袖衬衫，领口红色领结；奶油色V领针织开衫（扣好）；深色格纹百褶裙；深色过膝袜（袜口在膝上大腿处，裙摆下只露一小截皮肤）；棕色小皮鞋；发型：及腰黑长直发，中分微空气刘海；后脑稍高处红色双环蝴蝶结，正面双环对称探出头顶，绝不偏一侧、不盖耳朵；配饰：红蝴蝶结、书包。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiazhiyao_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Zhiyao (17, girl), look 'ZY-L1': white long-sleeve blouse with a red neck bow; cream V-neck knit cardigan buttoned; dark plaid pleated skirt; dark over-the-knee socks ending above the knee leaving only a small gap of skin below the hem; brown leather loafers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiazhiyao_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZY-L2　居家（摘下领结，白衬衫+奶油开衫袖子挽到手肘）

- **场次**：第4、5、9、11、13、14、18、24场　**参考图**：`cards/xiazhiyao_card1.jpg`
- **出处**：第4场：「知遥换下了领结，穿着白衬衫和奶油色开衫，袖子挽到手肘」；设定（第三~六节）：「在家会把开衫袖子挽到手肘。」；第24场：「知遥穿着奶油色开衫，袖子挽到手肘，头上系着红蝴蝶结」
- **服装**：白色衬衫（无领结，领口解开第一颗扣）；奶油色V领开衫，袖子挽到手肘；深色格纹百褶裙；家中穿白色短袜+室内拖鞋[设计补充]。
- **发型**：同 ZY-L1，红蝴蝶结　**配饰**：红蝴蝶结（P01）（关联道具 P01）
- **变体 A 第9场剥虾：指尖划破渗血**（第9场）：同上，指尖一点血珠
- **变体 B 第18场：哭泣、坐地**（第18场）：眼眶红肿[妆效]，后自己重新系紧蝴蝶结
- 注：第9、11、13、14、18场剧本未写服装，沿用居家装[设计补充]。
- **三视图提示词**：服装设定图，夏知遥的造型「居家（摘下领结，白衬衫+奶油开衫袖子挽到手肘）」：白色衬衫（无领结，领口解开第一颗扣）；奶油色V领开衫，袖子挽到手肘；深色格纹百褶裙；家中穿白色短袜+室内拖鞋；发型：同 ZY-L1，红蝴蝶结；配饰：红蝴蝶结。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiazhiyao_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Zhiyao, look 'ZY-L2': white blouse without the neck bow, top button open; cream V-neck cardigan with sleeves rolled to the elbows; dark plaid pleated skirt; at home white ankle socks and slippers . Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiazhiyao_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZY-L3　睡衣（深夜规则试探）　[设计补充]

- **场次**：第6场　**参考图**：`cards/xiazhiyao_card1.jpg`
- **出处**：第6场：「深夜，台灯下。知遥穿着睡衣，抱着浅蓝色作文本」
- **服装**：[设计补充] 浅蓝白细格纹棉质长袖睡衣套装（翻领衬衫式上衣+长裤），白色室内拖鞋。
- **发型**：及腰黑长直发散开，蝴蝶结摘下（睡前）[设计补充]　**配饰**：无
- 注：剧本只写“睡衣”，款式颜色为[设计补充]。
- 注：OP画面二（站在坡道上捂耳朵）用 ZY-L1 校服[设计补充]。
- **三视图提示词**：服装设定图，夏知遥的造型「睡衣（深夜规则试探）」：浅蓝白细格纹棉质长袖睡衣套装（翻领衬衫式上衣+长裤），白色室内拖鞋；发型：及腰黑长直发散开，蝴蝶结摘下（睡前）；配饰：无。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiazhiyao_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Zhiyao, look 'ZY-L3': light blue-and-white fine-check cotton pajama set, notch-collar button top and long pants, white slippers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiazhiyao_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZY-L4　台风夜外出（第17天）　[设计补充]

- **场次**：第1、21、22、23场　**参考图**：`cards/xiazhiyao_card1.jpg`
- **出处**：第21场：「知遥抓起门口外卖用的防水手机袋，把手机装进去，挂在胸前。」；第21场：「她摸了摸头上的蝴蝶结」；第23场：「知遥冻得嘴唇发紫」；第23场：「裹着母亲递来的毯子」
- **服装**：[设计补充] 居家装（白衬衫+奶油色开衫）外加深色长裤与白色运动鞋便于奔跑；胸前挂透明防水手机袋（P13）；红蝴蝶结系紧。
- **发型**：黑长直发，红蝴蝶结（第20场母亲系紧）　**配饰**：防水手机袋（P13）、手机（P12）、红蝴蝶结（关联道具 P01, P13, P12, P84）
- **变体 A 冲上堤：暴雨中全身湿透**（第22场）：衣服贴身湿透，头发贴脸
- **变体 B 落水后：浸透、嘴唇发紫**（第23、1场）：浸透，脸色苍白，嘴唇发紫[妆效]
- **变体 C 船上：裹灰色毯子**（第23场）：外裹毯子
- 注：剧本未写第17天夜里知遥穿什么，需用户确认（是否仍穿校服？学校停课）。
- 注：第1场原本未来只露手腕和蝴蝶结，用变体B。
- **三视图提示词**：服装设定图，夏知遥的造型「台风夜外出（第17天）」：居家装（白衬衫+奶油色开衫）外加深色长裤与白色运动鞋便于奔跑；胸前挂透明防水手机袋；红蝴蝶结系紧；发型：黑长直发，红蝴蝶结（第20场母亲系紧）；配饰：防水手机袋、手机、红蝴蝶结。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiazhiyao_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Zhiyao, look 'ZY-L4': home look (white blouse + cream cardigan) with dark long pants and white sneakers for running; clear waterproof phone pouch on the chest; red bow tied tight. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiazhiyao_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 夏知遥（10岁）

#### ZY-C　童年（照片/相册/片尾静帧）　[设计补充]

- **场次**：第2、5、25场　**参考图**：`cards/xiazhiyao_card1.jpg（参照五官幼化）`
- **出处**：第2场：「男人怀里抱着一个系着红蝴蝶结的小女孩。」；第5场：「她十岁生日的照片：同一个蝴蝶结」；第25场：「十岁的知遥骑在爸爸肩上，头上的红蝴蝶结」
- **服装**：[设计补充] 白色短袖连衣裙，白袜红色小皮鞋。
- **发型**：齐肩黑发，同一个红蝴蝶结（对小孩显得更大）　**配饰**：红蝴蝶结（关联道具 P01）
- 注：第2场照片中年龄未写（“小女孩”），与十岁照片可统一为同一形象[设计补充]。
- **三视图提示词**：服装设定图，夏知遥（10岁）的造型「童年（照片/相册/片尾静帧）」：白色短袖连衣裙，白袜红色小皮鞋；发型：齐肩黑发，同一个红蝴蝶结（对小孩显得更大）；配饰：红蝴蝶结。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiazhiyao_card1.jpg（参照五官幼化），不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Zhiyao age 10, look 'ZY-C': white short-sleeve dress, white socks, little red shoes. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiazhiyao_card1.jpg（参照五官幼化）; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 周砚

#### ZYN-L1　外出（藏青夹克+白T+深色长裤+白运动鞋+单肩背黑双肩包）

- **场次**：第1、2、3、7、8、9、10、11、12、13、15、16、17、21、22场　**参考图**：`cards/zhouyan_card1.jpg`
- **出处**：设定（第三~六节）：「藏青色夹克外套里面是白色 T 恤，深色长裤，白色运动鞋，单肩背黑色双肩包。」；第7场：「手插在藏青外套口袋里」；第21场：「周砚把藏青外套拉链拉到顶，单肩包扔在门口」
- **服装**：藏青色立领拉链夹克（P02，左胸小圆徽章），内搭白色圆领T恤，藏青色长裤，白色运动鞋；黑色双肩包单肩背（P10），书包带上别褪色蓝色游泳队徽章（P09）。
- **发型**：黑色短发，刘海略长微遮眉　**配饰**：双肩包、徽章；右手指节一道旧疤（第12场）（关联道具 P02, P10, P09）
- **变体 A 第10场：脱外套后半边湿透**（第10场）：只穿白T，一侧肩膀到手臂湿透透肉色
- **变体 B 第21场：拉链拉到顶，不背包**（第21场）：夹克拉链拉到顶，无书包
- 注：characters.md 写“左肩斜挎”，剧本写“单肩背”“从左肩换到右肩”——默认左肩，标志动作时换右肩。
- 注：第9、11场服装未写，[设计补充]沿用本装。
- **三视图提示词**：服装设定图，周砚的造型「外出（藏青夹克+白T+深色长裤+白运动鞋+单肩背黑双肩包）」：藏青色立领拉链夹克（左胸小圆徽章），内搭白色圆领T恤，藏青色长裤，白色运动鞋；黑色双肩包单肩背，书包带上别褪色蓝色游泳队徽章；发型：黑色短发，刘海略长微遮眉；配饰：双肩包、徽章；右手指节一道旧疤（第12场）。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhouyan_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Yan (17, boy), look 'ZYN-L1': navy stand-collar zip jacket (small round badge on left chest) over a white crew-neck T-shirt, navy trousers, white sneakers; black backpack slung on one shoulder with a faded blue swim badge on the strap . Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhouyan_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZYN-L2　居家白T（外套搭椅背）

- **场次**：第4、5、13、20、24场　**参考图**：`cards/zhouyan_card1.jpg`
- **出处**：第4场：「他已经脱了外套，只穿白 T。」；第13场：「周砚的外套搭在椅背上，只穿白 T。」；第24场：「周砚只穿白 T，藏青外套搭在椅背上，手里提着一个印着“澄港少年游泳队”的训练包。」
- **服装**：白色圆领短袖T恤，藏青色长裤，白色运动鞋（室内可穿袜子[设计补充]）。
- **发型**：同上　**配饰**：第24场手提训练包（关联道具 P89）
- 注：第20场在家不开灯看视频，服装未写，[设计补充]。
- **三视图提示词**：服装设定图，周砚的造型「居家白T（外套搭椅背）」：白色圆领短袖T恤，藏青色长裤，白色运动鞋（室内可穿袜子）；发型：同上；配饰：第24场手提训练包。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhouyan_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Yan, look 'ZYN-L2': white crew-neck short-sleeve T-shirt, navy trousers, white sneakers (socks indoors, design). Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhouyan_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZYN-L3　居家下厨（白T+围裙）

- **场次**：第14场　**参考图**：`cards/zhouyan_card1.jpg`
- **出处**：第14场：「周砚系着围裙在小厨房里煎蛋。」
- **服装**：白色T恤+藏青长裤，外系深灰色挂脖围裙。
- **发型**：同上　**配饰**：围裙（关联道具 P65）
- 注：围裙颜色为[设计补充]。
- **三视图提示词**：服装设定图，周砚的造型「居家下厨（白T+围裙）」：白色T恤+藏青长裤，外系深灰色挂脖围裙；发型：同上；配饰：围裙。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhouyan_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Yan, look 'ZYN-L3': white T-shirt and navy trousers with a dark-grey bib apron. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhouyan_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZYN-L4　台风夜白T湿透（外套给了豆豆）

- **场次**：第22、23场　**参考图**：`cards/zhouyan_card1.jpg`
- **出处**：第22场：「脱下自己的藏青外套裹住孩子」；第22场：「只看见一个穿白T的男生朝女生扑过去」；第23场：「周砚躺在甲板上，雨打在脸上。」
- **服装**：白色T恤浸透贴身，藏青长裤湿透，白运动鞋。
- **发型**：湿发贴额　**配饰**：无
- 注：与第1场“一只穿藏青色袖子的手”冲突，见歧义清单。
- **三视图提示词**：服装设定图，周砚的造型「台风夜白T湿透（外套给了豆豆）」：白色T恤浸透贴身，藏青长裤湿透，白运动鞋；发型：湿发贴额；配饰：无。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhouyan_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Yan, look 'ZYN-L4': soaked white T-shirt clinging to the body, drenched navy trousers, white sneakers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhouyan_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 周砚（一年前·旧学校）

#### ZYN-L5　旧学校闪回　[设计补充]

- **场次**：第14场　**参考图**：`cards/zhouyan_card1.jpg`
- **出处**：第14场：「少年周砚挡在小满前面，被推了一把，又站回去」
- **服装**：[设计补充] 旧学校校服：白色短袖衬衫+深灰长裤，与第七中学不同；整体褪色蓝灰滤镜。
- **发型**：同发型略短[设计补充]　**配饰**：无
- 注：剧本未写旧校校服。
- **三视图提示词**：服装设定图，周砚（一年前·旧学校）的造型「旧学校闪回」：旧学校校服：白色短袖衬衫+深灰长裤，与第七中学不同；整体褪色蓝灰滤镜；发型：同发型略短；配饰：无。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhouyan_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Yan one year earlier, look 'ZYN-L5': old-school uniform: white short-sleeve shirt with dark-grey trousers, distinct from No.7; faded blue-grey grade. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhouyan_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 周砚

#### ZYN-L6　泳装（OP泳池底/片尾跳台）　[设计补充]

- **场次**：第6、25场　**参考图**：`cards/zhouyan_card1.jpg`
- **出处**：第6场：「周砚在泳池底仰望水面」；第25场：「周砚站在跳台上」
- **服装**：[设计补充] 藏青色及膝竞技泳裤，蓝色泳镜，黑色泳帽可选。
- **发型**：湿发或泳帽　**配饰**：泳镜（关联道具 P69）
- 注：剧本未写泳装细节。
- **三视图提示词**：服装设定图，周砚的造型「泳装（OP泳池底/片尾跳台）」：藏青色及膝竞技泳裤，蓝色泳镜，黑色泳帽可选；发型：湿发或泳帽；配饰：泳镜。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhouyan_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Yan, look 'ZYN-L6': navy knee-length racing jammers, blue goggles, optional black swim cap. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhouyan_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 夏红梅

#### XHM-L1　面馆日常（米色短袖+深蓝围裙）

- **场次**：第2、4、5、9、11、18、20、21、24、25场　**参考图**：`cards/xiahongmei_card1.jpg`
- **出处**：设定（第三~六节）：「短发用夹子别起，系深蓝围裙，手背有烫伤旧疤。」；第9场：「迅速把单子折起来塞进围裙口袋」；第21场：「她猛地解下围裙」
- **服装**：米色短袖上衣，深蓝色过膝围裙（腰后系带、前方口袋），深灰色长裤，黑色平底鞋。
- **发型**：黑色短发用夹子别起成低髻，额前碎发　**配饰**：手背烫伤旧疤（左手，人物卡）；围裙口袋里折起的缴费单（关联道具 P53）
- **变体 A 第18场：手背被围裙磨得通红、哭**（第18场）：手背发红[妆效]，泪痕
- **变体 B 第20场清晨：眼睛还肿着**（第20场）：眼睑红肿[妆效]
- 注：第24场服装未写，[设计补充]沿用本装。
- **三视图提示词**：服装设定图，夏红梅的造型「面馆日常（米色短袖+深蓝围裙）」：米色短袖上衣，深蓝色过膝围裙（腰后系带、前方口袋），深灰色长裤，黑色平底鞋；发型：黑色短发用夹子别起成低髻，额前碎发；配饰：手背烫伤旧疤（左手，人物卡）；围裙口袋里折起的缴费单。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiahongmei_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Hongmei (42, mother), look 'XHM-L1': beige short-sleeve top, dark-blue knee-length apron with back ties and front pocket, dark-grey trousers, black flats. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiahongmei_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### XHM-L2　听证会（摘下围裙外出）　[设计补充]

- **场次**：第17场　**参考图**：`cards/xiahongmei_card1.jpg`
- **出处**：第17场：「夏红梅在桌子底下抓住了女儿的手。」
- **服装**：[设计补充] 米色短袖上衣外加深灰色薄开衫，深灰长裤，黑平底鞋，不系围裙。
- **发型**：同 L1　**配饰**：无
- 注：剧本未写。
- **三视图提示词**：服装设定图，夏红梅的造型「听证会（摘下围裙外出）」：米色短袖上衣外加深灰色薄开衫，深灰长裤，黑平底鞋，不系围裙；发型：同 L1；配饰：无。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiahongmei_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Hongmei, look 'XHM-L2': beige short-sleeve top with a thin dark-grey cardigan, dark-grey trousers, black flats, no apron. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiahongmei_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### XHM-L3　台风夜出船（解下围裙·浑身湿透）

- **场次**：第21、23场　**参考图**：`cards/xiahongmei_card1.jpg`
- **出处**：第21场：「她猛地解下围裙，抓起挂在墙上的一串旧钥匙」；第23场：「船尾，夏红梅浑身湿透，一只手死死握着舵柄」
- **服装**：米色短袖上衣（湿透变深）、深灰长裤湿透、黑平底鞋；无围裙、无雨衣。
- **发型**：夹子别起的短发被雨打散，贴在脸上　**配饰**：钥匙串、探照灯（关联道具 P79, P82）
- 注：剧本未提雨衣，本条不加雨衣。
- **三视图提示词**：服装设定图，夏红梅的造型「台风夜出船（解下围裙·浑身湿透）」：米色短袖上衣（湿透变深）、深灰长裤湿透、黑平底鞋；无围裙、无雨衣；发型：夹子别起的短发被雨打散，贴在脸上；配饰：钥匙串、探照灯。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiahongmei_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Hongmei, look 'XHM-L3': beige short-sleeve top soaked darker, drenched dark-grey trousers, black flats; no apron, no raincoat. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiahongmei_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 陈秀英（外婆）

#### CXY-L1　掌勺日常（罩衫围裙+碎花袖套+老花镜挂胸前）

- **场次**：第2、4、5、9、11、13、18、20、21、23、24、25场　**参考图**：`cards/chenxiuying_card1.jpg`
- **出处**：设定（第三~六节）：「花白卷发，碎花袖套，老花镜挂在胸前。」
- **服装**：米色长袖罩衫式围裙（胸前两只口袋），手臂套米色碎花袖套，深色宽松长裤，米色浅口鞋。
- **发型**：花白短卷发　**配饰**：老花镜挂在胸前
- **变体 A 第23场末：码头雨中等待**（第23场）：[设计补充] 外披透明雨衣
- **三视图提示词**：服装设定图，陈秀英（外婆）的造型「掌勺日常（罩衫围裙+碎花袖套+老花镜挂胸前）」：米色长袖罩衫式围裙（胸前两只口袋），手臂套米色碎花袖套，深色宽松长裤，米色浅口鞋；发型：花白短卷发；配饰：老花镜挂在胸前。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/chenxiuying_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Chen Xiuying (68, grandma), look 'CXY-L1': beige long-sleeve smock apron with two chest pockets, beige floral sleeve covers on the forearms, loose dark trousers, beige slip-on shoes. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/chenxiuying_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### CXY-L2　广场舞T恤（片尾静帧）

- **场次**：第25场　**参考图**：`cards/chenxiuying_card1.jpg`
- **出处**：第25场：「外婆在面馆门口跳广场舞，T恤上印着“自己的碗，端稳了”」；第9场：「印！印了我穿着去跳广场舞。」
- **服装**：白色短袖T恤，胸前一行大字（文字后期），深色宽松长裤，白色运动鞋[设计补充]。
- **发型**：花白短卷发　**配饰**：老花镜挂胸前
- **三视图提示词**：服装设定图，陈秀英（外婆）的造型「广场舞T恤（片尾静帧）」：白色短袖T恤，胸前一行大字（文字后期），深色宽松长裤，白色运动鞋；发型：花白短卷发；配饰：老花镜挂胸前。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/chenxiuying_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Chen Xiuying, look 'CXY-L2': white short-sleeve T-shirt with a line of big characters on the chest (text in post), loose dark trousers, white sneakers . Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/chenxiuying_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 陈秀英（17岁）

#### CXY-L3　黑白老照片里的年轻外婆　[设计补充]

- **场次**：第25场　**参考图**：`cards/chenxiuying_card1.jpg（五官年轻化）`
- **出处**：第25场：「年轻的外婆和一个穿海魂衫的小伙子，站在一条渔船前。」
- **服装**：[设计补充] 浅色短袖碎花布衫、深色长裤，黑白照片质感。
- **发型**：黑色及肩卷发[设计补充]　**配饰**：无
- **三视图提示词**：服装设定图，陈秀英（17岁）的造型「黑白老照片里的年轻外婆」：浅色短袖碎花布衫、深色长裤，黑白照片质感；发型：黑色及肩卷发；配饰：无。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/chenxiuying_card1.jpg（五官年轻化），不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for young Chen Xiuying age 17, look 'CXY-L3': light short-sleeve floral cotton blouse, dark trousers, rendered as a black-and-white photo. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/chenxiuying_card1.jpg（五官年轻化）; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 夏海生

#### XHS-L1　船长装（照片/片尾静帧/声音）

- **场次**：第2、23、25场　**参考图**：`cards/xiahaisheng_card1.jpg`
- **出处**：第2场：「一个皮肤黝黑的男人站在一条小渔船船头」；设定（第三~六节）：「晒黑短发、船长外套、橡胶雨靴」；第25场：「十岁的知遥骑在爸爸肩上」
- **服装**：深蓝色船长外套（领口与内衬橙色），米色毛衣，深蓝工装裤，黑色橡胶雨靴；可手持白顶深蓝船长帽。
- **发型**：晒黑皮肤，短发略乱，浅胡茬　**配饰**：船长帽
- 注：只出现在照片、回忆和声音里（第23场为声音叠加）。
- **三视图提示词**：服装设定图，夏海生的造型「船长装（照片/片尾静帧/声音）」：深蓝色船长外套（领口与内衬橙色），米色毛衣，深蓝工装裤，黑色橡胶雨靴；可手持白顶深蓝船长帽；发型：晒黑皮肤，短发略乱，浅胡茬；配饰：船长帽。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xiahaisheng_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xia Haisheng (father, deceased), look 'XHS-L1': navy captain's coat with orange collar and lining, beige sweater, navy work pants, black rubber boots; may hold a white-topped navy captain's cap. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xiahaisheng_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 周静

#### ZJ-L1　护士服（浅绿护士套装+工作证）

- **场次**：第2、23场　**参考图**：`cards/zhoujing_card1.jpg`
- **出处**：第2场：「他母亲周静穿着护士外套，跟在后面道谢。」；第23场：「还有接到电话从医院赶来的周静」
- **服装**：浅绿色V领短袖护士套装，胸前蓝色挂绳工作证，左手腕表，白色运动鞋。
- **发型**：黑发低盘，额前碎发；淡淡黑眼圈　**配饰**：工作证、腕表
- **变体 A 第23场：从医院赶来淋雨**（第23场）：[设计补充] 外披透明雨衣，护士服淋湿
- 注：第2场原文是“护士外套”：是否另有一件外套（如白色护士外套）需确认；默认用卡面护士服。
- **三视图提示词**：服装设定图，周静的造型「护士服（浅绿护士套装+工作证）」：浅绿色V领短袖护士套装，胸前蓝色挂绳工作证，左手腕表，白色运动鞋；发型：黑发低盘，额前碎发；淡淡黑眼圈；配饰：工作证、腕表。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhoujing_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Jing (44, nurse), look 'ZJ-L1': light-green V-neck short-sleeve scrubs, blue lanyard ID badge, watch on left wrist, white sneakers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhoujing_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZJ-L2　刚下夜班（护士服外套开衫）

- **场次**：第17场　**参考图**：`cards/zhoujing_card1.jpg`
- **出处**：第17场：「刚下夜班，护士服外面套着一件开衫，眼睛里全是血丝。」
- **服装**：浅绿护士服外套一件[设计补充：灰色]针织开衫，工作证收进口袋[设计补充]。
- **发型**：低盘发微乱　**配饰**：眼睛血丝[妆效]
- **三视图提示词**：服装设定图，周静的造型「刚下夜班（护士服外套开衫）」：浅绿护士服外套一件针织开衫，工作证收进口袋；发型：低盘发微乱；配饰：眼睛血丝。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhoujing_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Jing, look 'ZJ-L2': light-green scrubs under a grey knit cardigan, ID tucked in pocket . Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhoujing_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### ZJ-L3　居家便装　[设计补充]

- **场次**：第20、24场　**参考图**：`cards/zhoujing_card1.jpg`
- **出处**：第20场：「周静坐在他旁边，紧紧握着他的手，泪流满面。」；第24场：「周静带来了一锅汤。」
- **服装**：[设计补充] 浅灰色针织开衫+白色内搭+深色长裤。
- **发型**：低盘发　**配饰**：第24场手提汤锅（关联道具 P87）
- 注：剧本未写。
- **三视图提示词**：服装设定图，周静的造型「居家便装」：浅灰色针织开衫+白色内搭+深色长裤；发型：低盘发；配饰：第24场手提汤锅。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/zhoujing_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Zhou Jing, look 'ZJ-L3': light-grey knit cardigan over a white top, dark trousers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/zhoujing_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 林朵朵

#### LDD-L1　校服（校服外套绑腰）

- **场次**：第2、3、4、5、7、11、13、16、20场　**参考图**：`cards/linduoduo_card1.jpg`
- **出处**：设定（第三~六节）：「齐肩短发，两边别彩色发夹，校服外套绑在腰上。」；第2场：「从门口探头，齐肩短发，彩色发夹」
- **服装**：白色长袖衬衫，深蓝色校服外套袖子绑在腰间，深色格纹短裙，白色中筒袜，棕色乐福鞋。
- **发型**：齐肩棕色短发，两侧粉色和浅绿色花朵发夹　**配饰**：手机（关联道具 P14）
- 注：第4、5场（开学日晚上）、第11场服装未写，[设计补充]沿用校服。
- **三视图提示词**：服装设定图，林朵朵的造型「校服（校服外套绑腰）」：白色长袖衬衫，深蓝色校服外套袖子绑在腰间，深色格纹短裙，白色中筒袜，棕色乐福鞋；发型：齐肩棕色短发，两侧粉色和浅绿色花朵发夹；配饰：手机。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/linduoduo_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Lin Duoduo (17, girl), look 'LDD-L1': white long-sleeve shirt, navy school blazer tied around the waist by its sleeves, dark plaid short skirt, white mid-calf socks, brown loafers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/linduoduo_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### LDD-L2　非上学日/过夜便装　[设计补充]

- **场次**：第21、23、24场　**参考图**：`cards/linduoduo_card1.jpg`
- **出处**：第21场：「朵朵的爸妈都在港务局值台风班，姐弟俩被托付在夏家过夜。」
- **服装**：[设计补充] 浅黄色连帽卫衣，深色短裤配白色中筒袜，白色运动鞋；第23场码头外披透明雨衣。
- **发型**：同卡面发型与发夹　**配饰**：发夹不可省略
- 注：剧本未写，如用户希望全片只用卡面造型，可改为 LDD-L1。
- **三视图提示词**：服装设定图，林朵朵的造型「非上学日/过夜便装」：浅黄色连帽卫衣，深色短裤配白色中筒袜，白色运动鞋；第23场码头外披透明雨衣；发型：同卡面发型与发夹；配饰：发夹不可省略。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/linduoduo_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Lin Duoduo, look 'LDD-L2': pale-yellow hoodie, dark shorts with white mid-calf socks, white sneakers; clear raincoat at the pier in scene 23. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/linduoduo_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 林豆豆

#### LDou-L1　日常（条纹T，无雨衣）

- **场次**：第4、5、24、25场　**参考图**：`cards/lindoudou_card1.jpg`
- **出处**：设定（第三~六节）：「圆脸，第3天起穿一件崭新的明黄色雨衣。」；第4场：「豆豆（八岁，圆脸，天真）」
- **服装**：白底蓝色细条纹T恤，深蓝色长裤，白色运动鞋。
- **发型**：圆脸黑色短发　**配饰**：无
- 注：第4–5场为第1天，雨衣尚未出现（第3天起），因此不穿雨衣。第24场室内[设计补充]。
- **三视图提示词**：服装设定图，林豆豆的造型「日常（条纹T，无雨衣）」：白底蓝色细条纹T恤，深蓝色长裤，白色运动鞋；发型：圆脸黑色短发；配饰：无。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/lindoudou_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Lin Doudou (8, boy), look 'LDou-L1': white T-shirt with thin blue stripes, navy trousers, white sneakers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/lindoudou_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### LDou-L2　明黄色雨衣

- **场次**：第8、15、21、22、23场　**参考图**：`cards/lindoudou_card1.jpg`
- **出处**：第8场：「一个穿着崭新明黄色雨衣的小男孩」；第22场：「豆豆穿着黄雨衣，蜷在那里，怀里紧紧抱着湿透的橘猫」
- **服装**：有光泽的明黄色连帽长雨衣，内搭白底蓝细条纹T恤，深蓝长裤，白运动鞋。
- **发型**：圆脸黑短发（帽子可戴可摘）　**配饰**：一小袋猫粮（关联道具 P47, P46, P02）
- **变体 A 台风夜：湿透+裹着藏青外套**（第22、23场）：雨衣湿透，外裹周砚的藏青外套，抱着湿猫
- **三视图提示词**：服装设定图，林豆豆的造型「明黄色雨衣」：有光泽的明黄色连帽长雨衣，内搭白底蓝细条纹T恤，深蓝长裤，白运动鞋；发型：圆脸黑短发（帽子可戴可摘）；配饰：一小袋猫粮。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/lindoudou_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Lin Doudou, look 'LDou-L2': glossy bright-yellow hooded long raincoat over the striped T-shirt, navy trousers, white sneakers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/lindoudou_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 柯一鸣

#### KYM-L1　潮牌冲锋衣+稳定器+无线耳机

- **场次**：第14、16、17、20场　**参考图**：`cards/keyiming_card1.jpg`
- **出处**：设定（第三~六节）：「潮牌冲锋衣，手持稳定器，总戴一只无线耳麦。」；第14场：「一个穿冲锋衣的年轻男人举着手机」
- **服装**：黑色潮牌连帽冲锋衣（橙色拉链饰线，左臂口袋），黑色内搭，黑色工装裤，黑白灰运动鞋。
- **发型**：黑色短发，微胡茬　**配饰**：手机稳定器、左耳无线耳机（关联道具 P16, P17）
- **变体 A 第16场：摔倒后蹭脏**（第16场）：裤腿与袖子蹭上坡道灰土
- **变体 B 第17场：揉手腕**（第17场）：仅上半身出镜（视频连线）
- **三视图提示词**：服装设定图，柯一鸣的造型「潮牌冲锋衣+稳定器+无线耳机」：黑色潮牌连帽冲锋衣（橙色拉链饰线，左臂口袋），黑色内搭，黑色工装裤，黑白灰运动鞋；发型：黑色短发，微胡茬；配饰：手机稳定器、左耳无线耳机。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/keyiming_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Ke Yiming (29, influencer), look 'KYM-L1': black streetwear hooded shell jacket with orange zipper trim and left-arm pocket, black top, black cargo pants, black-white-grey sneakers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/keyiming_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

#### KYM-L2　台风夜雨衣直播

- **场次**：第22场　**参考图**：`cards/keyiming_card1.jpg`
- **出处**：第22场：「柯一鸣穿着雨衣站在车顶，戴着耳麦，举着稳定器直播」
- **服装**：[设计补充] 半透明灰色连帽雨衣套在黑色冲锋衣外，雨靴。
- **发型**：雨帽下湿发　**配饰**：稳定器、耳麦（关联道具 P16, P17）
- 注：雨衣颜色剧本未写。
- **三视图提示词**：服装设定图，柯一鸣的造型「台风夜雨衣直播」：半透明灰色连帽雨衣套在黑色冲锋衣外，雨靴；发型：雨帽下湿发；配饰：稳定器、耳麦。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/keyiming_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Ke Yiming, look 'KYM-L2': translucent grey hooded raincoat over the black shell jacket, rain boots. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/keyiming_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 宋佳怡

#### SJY-L1　整齐校服+红色“班长”袖章

- **场次**：第3、7、10、16、17、20场　**参考图**：`cards/songjiayi_card1.jpg`
- **出处**：设定（第三~六节）：「利落高马尾、校服穿得整齐、班长袖章」
- **服装**：深蓝色校服西装外套，白色衬衫，深色格纹百褶裙，左臂红色“班长”袖章（文字后期），深色中筒袜，棕色乐福鞋。
- **发型**：黑色长发利落高马尾，额前刘海　**配饰**：手机、纸条（关联道具 P55, P73）
- **三视图提示词**：服装设定图，宋佳怡的造型「整齐校服+红色“班长”袖章」：深蓝色校服西装外套，白色衬衫，深色格纹百褶裙，左臂红色“班长”袖章（文字后期），深色中筒袜，棕色乐福鞋；发型：黑色长发利落高马尾，额前刘海；配饰：手机、纸条。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/songjiayi_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Song Jiayi (17, class monitor), look 'SJY-L1': navy school blazer, white shirt, dark plaid pleated skirt, red armband on the left arm (text in post), dark mid-calf socks, brown loafers. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/songjiayi_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 许小满

#### XXM-L1　便利店夜班工服

- **场次**：第19、20场　**参考图**：`cards/xuxiaoman_card1.jpg`
- **出处**：第19场：「圆框眼镜，穿着便利店的条纹制服」；设定（第三~六节）：「瘦小，戴圆框眼镜，在便利店上夜班。」
- **服装**：浅蓝色短袖便利店工服（剧本写“条纹制服”，[设计补充]做成浅蓝白细竖条纹以兼顾人物卡），米色围裙（胸前名牌，文字后期），黑色长裤，黑色帆布鞋。
- **发型**：黑色短发，瘦小黑色圆框眼镜　**配饰**：眼镜、旧手机（关联道具 P22, P21）
- 注：人物卡为浅蓝短袖+米色围裙，剧本为“条纹制服”，需确认。
- **三视图提示词**：服装设定图，许小满的造型「便利店夜班工服」：浅蓝色短袖便利店工服（剧本写“条纹制服”，做成浅蓝白细竖条纹以兼顾人物卡），米色围裙（胸前名牌，文字后期），黑色长裤，黑色帆布鞋；发型：黑色短发，瘦小黑色圆框眼镜；配饰：眼镜、旧手机。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xuxiaoman_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xu Xiaoman (17, boy), look 'XXM-L1': light-blue short-sleeve store uniform with fine vertical white stripes , beige apron with a name tag (text in post), black trousers, black canvas shoes. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xuxiaoman_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 许小满（一年前）

#### XXM-L2　旧学校闪回　[设计补充]

- **场次**：第14场　**参考图**：`cards/xuxiaoman_card1.jpg`
- **出处**：第14场：「一个瘦小的男生。」；第14场：「他们抢他的饭卡，扯他的书包」
- **服装**：[设计补充] 与 ZYN-L5 同款旧学校校服（白短袖衬衫+深灰长裤），背书包。
- **发型**：黑短发、圆框眼镜　**配饰**：眼镜、饭卡、书包（侧袋手机在录像）（关联道具 P22, P70）
- **三视图提示词**：服装设定图，许小满（一年前）的造型「旧学校闪回」：与 ZYN-L5 同款旧学校校服（白短袖衬衫+深灰长裤），背书包；发型：黑短发、圆框眼镜；配饰：眼镜、饭卡、书包（侧袋手机在录像）。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xuxiaoman_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xu Xiaoman one year earlier, look 'XXM-L2': same old-school uniform as ZYN-L5, with a backpack. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xuxiaoman_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 许小满

#### XXM-L3　便装（一个月后/片尾看台）　[设计补充]

- **场次**：第24、25场　**参考图**：`cards/xuxiaoman_card1.jpg`
- **出处**：第24场：「许小满拘谨地坐在角落」；第25场：「看台上一个举着纸牌而不是手机的许小满」
- **服装**：[设计补充] 灰色连帽卫衣，深色长裤，帆布鞋。
- **发型**：黑短发、圆框眼镜　**配饰**：纸牌（第25场）（关联道具 P22, P93）
- **三视图提示词**：服装设定图，许小满的造型「便装（一个月后/片尾看台）」：灰色连帽卫衣，深色长裤，帆布鞋；发型：黑短发、圆框眼镜；配饰：纸牌（第25场）。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/xuxiaoman_card1.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Xu Xiaoman, look 'XXM-L3': grey hoodie, dark trousers, canvas shoes. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/xuxiaoman_card1.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 街坊阿姨甲

#### AJ-L1　据设定图

- **场次**：第2场　**参考图**：`cards/aunt_jia_card.jpg`
- **出处**：第2场：「两个街坊阿姨挎着菜篮，在面馆门口压低声音。」
- **服装**：粉色小碎花七分袖盘扣衬衫，深褐色长裤，棕色平底鞋。
- **发型**：深棕色自然齐耳卷发　**配饰**：藤编菜篮装青菜
- **三视图提示词**：服装设定图，街坊阿姨甲的造型「据设定图」：粉色小碎花七分袖盘扣衬衫，深褐色长裤，棕色平底鞋；发型：深棕色自然齐耳卷发；配饰：藤编菜篮装青菜。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/aunt_jia_card.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Neighbour Auntie A, look 'AJ-L1': pink small-floral three-quarter-sleeve frog-button blouse, dark brown trousers, brown flats. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/aunt_jia_card.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 街坊阿姨乙

#### AY-L1　据设定图

- **场次**：第2场　**参考图**：`cards/aunt_yi_card.jpg`
- **出处**：第2场：「街坊阿姨乙：“哎哟，长得倒挺周正……”」
- **服装**：橄榄绿七分袖盘扣上衣，米色长裤，深棕色平底鞋。
- **发型**：花白头发盘成后髻　**配饰**：红色塑料菜篮装紫茄子
- **三视图提示词**：服装设定图，街坊阿姨乙的造型「据设定图」：橄榄绿七分袖盘扣上衣，米色长裤，深棕色平底鞋；发型：花白头发盘成后髻；配饰：红色塑料菜篮装紫茄子。同一人物全身三视图（正面、侧面、背面）横向并排，自然站姿，白色纯背景，日式剧场版动画角色设定风格，赛璐珞上色，均匀平光。面部严格按参考图 cards/aunt_yi_card.jpg，不改五官，不重新设计脸，只表现服装、发型与配饰。无文字，无标注，无水印
- **Turnaround (EN)**: costume turnaround sheet for Neighbour Auntie B, look 'AY-L1': olive-green three-quarter-sleeve frog-button top, beige trousers, dark brown flats. Full-body front, side and back views side by side, neutral standing pose, plain white background, Japanese theatrical anime character design-sheet style, cel shading, flat even lighting. Keep the face exactly as in reference image cards/aunt_yi_card.jpg; do not redesign the face, depict clothing, hairstyle and accessories only. No text, no labels, no watermark

### 无人物卡的配角与群演

| ID | 角色 | 场次 | 出处 | 服装（[设计补充]） |
|---|---|---|---|---|
| EX01 | 班主任老何 | 3、17 | 第3场：「班主任老何领着周砚进来。」；第17场：「对面坐着钱主任和老何。」 | [设计补充] 50岁左右男性教师，微秃，浅灰短袖衬衫，深色西裤，干笑表情。 |
| EX02 | 教导主任钱主任 | 17 | 第17场：「教导主任钱主任」；第17场：「钱主任（翻着打印出来的网络截图）」 | [设计补充] 50多岁，深色西装外套，眼镜，严肃。 |
| EX03 | 高二（3）班同学（同学甲乙/若干） | 3、7、13、20 | 第3场：「同学甲：“真的是他？”」；第7场：「教室后排，一个同学正举着手机拍窗外的晚霞」 | [设计补充] 第七中学校服：男生白衬衫+深蓝校服外套+深色长裤；女生白衬衫+红领结+深色格纹裙。 |
| EX04 | 故意伸脚的男生（课间蒙太奇） | 13 | 第13场：「她提前把楼梯口那个故意伸脚的男生叫走问作业。」 | 同 EX03 男生校服。 |
| EX05 | 围观学生（后门） | 16 | 第16场：「后门口的几个学生纷纷举起手机。」 | 同 EX03 校服，举手机。 |
| EX06 | 搬家工人 | 2 | 第2场：「搬家工人搬下纸箱。」 | [设计补充] 蓝色工装T恤、深色工装裤。 |
| EX07 | 拎菜的老奶奶 | 2 | 第2场：「一个拎着两大袋菜、走得踉踉跄跄的老奶奶」 | [设计补充] 驼背，灰白短发，深蓝布衫。 |
| EX08 | 外卖电动车骑手（只露背影） | 8 | 第8场：「外卖电动车骑手（只露背影）」；第8场：「骑手低头看着手机」 | [设计补充] 黄色外卖服、头盔（无字）。 |
| EX09 | 面馆食客 | 11、20 | 第11场：「晚饭高峰，面馆坐满了人。」；第20场：「食客们举起手机」 | [设计补充] 街坊、渔民、上班族混合。 |
| EX10 | 三个霸凌者（闪回） | 14 | 第14场：「三个高大的身影围着一个瘦小的男生。」 | [设计补充] 同 ZYN-L5 旧学校校服，高大，面部处于阴影。 |
| EX11 | 海上救援人员 | 23 | 第23场：「海上救援（远景）」 | [设计补充] 橙色救生衣、头盔（远景）。 |
| EX12 | 穿海魂衫的小伙子（年轻外公） | 25 | 第25场：「一个穿海魂衫的小伙子」；第13场：「我十七岁那年，跟你外公也是这么‘学习’的。」 | 蓝白横条海魂衫、深色长裤，黑白照片质感。 |
| EX13 | 新闻主播/广播（仅声音或电视画面） | 1、21、24 | 第1场：「广播声：“今天是9月1日，各中小学正式开学……”」；第24场：「电视里播着本地新闻」 | 如需出画：电视新闻主播半身，正装。 |

## 四、其他

### 4.1 界面UI与画面设计（只做版式，文字后期）
| ID | 名称 | 场次 | 设计 | 出处 |
|---|---|---|---|---|
| U01 | 弹幕A（知遥所见，视频A评论） | 1、5、6、7、8、10、11、12、15、17、18 | 半透明白字（透明度20%→80%），字体圆润，从画面右侧飘入向左移动，带轻微RGB色散；高情绪弹幕变红、变大、抖动；“前方高能”类横贯全屏。 | 七、1. 弹幕是从画面右侧飘入的半透明白字，字体圆润。高情绪弹幕变红、变大、抖动。 |
| U02 | 弹幕B（周砚所见，视频B评论） | 5、12、20、21、22、23 | 样式同U01；在第21–22场越来越密，第22场21:46全部变红横贯视野；第23场最后变成慢速白字后熄灭。 | 22场：周砚的弹幕B突然全部变成红色，横贯整个视野 |
| U03 | 视频A字幕卡（左上角冷灰色小框） | 5、7、8、10、11、12、17、18 | 左上角冷灰色圆角小框，内含“第N天｜日期｜描述”（文字后期）。 | 视频 A 的字幕卡是左上角的冷灰色小框。 |
| U04 | 视频B字幕卡（右上角暖黄色） | 5、12、20、23 | 右上角偏暖黄色框；第5场只闪0.5秒看不清；标题在第20场、第23场两次重组。 | 视频 B 的字幕卡在右上角，偏暖黄色。 |
| U05 | 观看人数角标（右上角） | 5、7、11、13、20、23 | 右上角小字“观看 X亿”，数字会跳变（3.1亿→3.0→2.8→2.5→2.1→1.2亿→消失）。[设计补充] 视频B同为右上角时，观看人数放在字幕卡下方。 | 右上角是一行小字：“观看 3.1亿”。 |
| U06 | 弹幕重组特效（像素碎裂+“嘶”电流声） | 7、11、17、20、23 | 文字先碎成像素再拼回，闪烁、乱码。 | 弹幕重组时，文字先碎成像素，再拼回去，配“嘶”的电流声。 |
| U07 | 弹幕淹没房间（全CG文字粒子）与退潮 | 18 | 弹幕从墙、天花板、地板涌出淹没房间；“闭嘴”后从中间裂开、像灰被吹散、像水汽消失。 | 卧室里弹幕淹没房间用全 CG 的文字粒子 |
| U08 | 弹幕熄灭（萤火虫式粒子消散） | 23 | 弹幕一颗颗熄灭，像萤火虫飞向夜空。 | 弹幕熄灭用粒子消散，像萤火虫飞向夜空。 |
| U09 | “直播已结束｜感谢观看”字幕卡 | 23 | 视频B字幕卡最终形态，小字。 | 字幕卡最后变成一行小字：“直播已结束｜感谢观看”。 |
| U10 | 周砚视野右上角红色倒计时（21:41） | 22、23 | 红色数字时钟，跳动。 | 右上角一个红色数字在跳——21:41。 |
| U11 | 柯一鸣竖屏直播画框（LIVE红点+账号名） | 1、16、22 | 手机竖屏画框，左上角红点闪“LIVE”，账号名，剧烈晃动；第22场为车顶高处背后视角。 | 左上角红点闪着“LIVE”，账号名是“一鸣惊瓜”。 |
| U12 | 柯一鸣直播间评论区 | 22 | 直播间评论刷屏（？？？、小孩说是救人、快看另一个直播间）。 | 柯一鸣的直播间里，评论区瞬间刷满 |
| U13 | 9秒打人视频（竖屏小框，画质粗糙，水印） | 3、16 | 模糊走廊竖屏视频，标题条+账号水印，刻意粗糙。 | 手机屏幕上的 9 秒视频用竖屏小框插入，画质刻意做得粗糙。 |
| U14 | “潮声”App（热搜榜/视频/评论区/播放量） | 16、18、20 | 虚构短视频App界面：热搜榜、视频流、评论区上刷；第20场词条翻动。 | 她打开“潮声”App，热搜第三条 |
| U15 | 手机推送通知（台风路径） | 3、19 | 系统推送横幅。 | 知遥的手机推送弹出：“台风‘青鸾’路径更新……” |
| U16 | 知遥直播界面（账号“镜头外”，在线人数，浸水黑屏） | 22 | 胸前视角直播，正面剧烈晃动；结尾屏幕全黑只剩右上角在线人数“1.2万”往上跳。 | 只剩下直播间右上角的在线人数，从“1.2万”一路往上跳。 |
| U17 | 视频发布界面《我看清了：完整版》/许小满《一年前那三分钟》03:12 | 19、20 | 发布按钮、标题、时长03:12特写。 | 视频时长“03:12”用特写。 |
| U18 | 聊天消息界面（周砚↔知遥） | 17、20 | 即时消息气泡。 | 是周砚发来的消息 |
| U19 | 班级群界面（宋佳怡发视频） | 20 | 群聊+视频气泡。 | 宋佳怡在班级群里发了一段 |
| U20 | 前置摄像头自拍录像界面（红点） | 18、20 | 录像红点、自拍画面。 | 手机的前置摄像头还开着，红点亮着 |
| U21 | 视频连线界面（笔记本） | 17 | 笔记本屏幕里的视频通话。 | 屏幕里是柯一鸣的视频连线 |
| U22 | 电视画面：台风橙色预警/本地新闻 | 21、24 | 电视新闻图文。 | 电视里在播台风橙色预警 |
| U23 | 监控画面（黑白俯拍） | 8 | 粗颗粒黑白监控视角，带时间码[设计补充]。 | 监控的俯拍黑白画面里，男生显得粗暴 |
| U24 | 柯一鸣手机镜头仰拍画面 | 16 | 稳定器摔地后朝上拍到周砚“居高临下”的脸。 | 同时插入他手机镜头里的仰拍画面 |
| U25 | 分屏：视频A（冷灰）/视频B（暖黄）对撞合成“双双身亡” | 12 | 左右分屏冷暖对撞，中间竖线合拢。 | 分屏是全片最重要的视觉设计 |
| U26 | 三屏并列（柯一鸣直播/知遥直播/真实画面） | 22 | 同一瞬间三种角度。 | 三屏并列是全片第二个关键视觉设计 |
| U27 | 漫画分格分屏蒙太奇 | 13 | 分格漫画式，最后一格两人的“耶”合成一画。 | 喜剧蒙太奇用分格漫画式的分屏 |
| U28 | 片中字幕/片名/手写字幕/演职员表 | 1、6、24、25 | “17天前”黑底白字；片名浮现；晚霞上白色手写字幕；演职员表滚动。 | 00:55 字幕：黑底白字——“17天前。” |
| U29 | 外婆的弹幕“外婆yyds” | 25 | 单条半透明白字，无字幕卡[设计补充]，被外婆一挥散开。 | 外婆头顶上方，飘过一行半透明的白字 |
| U30 | “镜头外”画面规则 | 9、12、13、14、15 | 无弹幕时去掉画面边框的轻微暗角，色温变暖。 | “镜头外”的时刻会把画面边框的轻微暗角去掉，色温变暖 |
| U31 | 柯一鸣电脑满屏差评 | 20 | 电脑屏幕满屏“摆拍”“道歉”“举报”。 | 他对着电脑屏幕上满屏的“摆拍”“道歉”“举报” |

### 4.2 母题与符号
| ID | 母题 | 场次 | 出处 |
|---|---|---|---|
| M01 | 红蝴蝶结（顺从→自我→救命） | 1、2、3、7、15、16、18、20、23、24、25 | 六、1. |
| M02 | 蜡烛被吹灭的“噗”声（首尾闭环） | 1、4、21、25 | 和第1场结尾的那一声完全相同 |
| M03 | 白烟拧成“∞” | 4 | 一缕白烟升起来，在黑暗里慢慢拧成一个极淡的“∞”形 |
| M04 | 老灯塔的光（停电前闪一下/亮起第一束光/雨中一明一灭/真实的灯塔光） | 1、4、12、19、22、23、24 | 灯一亮，窗外远处的老灯塔闪了一下 |
| M05 | 手机=鱼群/探照灯/黑洞/眼睛 | 3、6、7、16、20 | 全班手机“齐刷刷翻面”的动作，像一片鱼群 |
| M06 | 数字“17”/倒计时 | 1、4、5、6、13、14、21、22 | 倒计时数字“17”从海面升起 |
| M07 | 剪刀与拼回的画面（剪辑=偏见） | 6 | 一个画面被剪刀“咔嚓”剪成两半 |
| M08 | 有人看见、有人没看见的构图（前景模糊的围观者，焦点在真相） | 2、8 | “有人看见、有人没看见”的构图从这里就开始了 |
| M09 | 码头上的等待（十年前没等到/这一次等到了/笑着挥手） | 18、23、25 | 这一次，码头上有人在等，等到了。 |
| M10 | 碗筷（多一双筷子→“砚”字碗） | 4、24 | 最后桌上多了一副他的碗筷 |
| M11 | 便利贴（周静→周砚→知遥） | 9、13、14 | 冰箱上贴满给儿子的便利贴 |
| M12 | “看全了再说”/前面那三分钟 | 6、10、19、24 | 口头禅：“看全了再说。” |
| M13 | 黄色小点/黄雨衣 | 8、13、15、21、22 | 远处堤上，一个黄色的小点在灯塔下面蹲着 |
| M14 | 冷暖对撞：视频A冷灰 vs 视频B暖黄；会议室冷/家暖 | 12、14、17 | 冷暖两套色调对撞 |
| M15 | 水下镜头对称（第1场下沉/第23场一只手抓住） | 1、23 | 水下镜头与第1场完全对称 |
| M16 | 客厅矮桌构图复刻（第4/21/24场） | 4、21、24 | 客厅全景完全复刻第4场和第21场的构图 |

### 4.3 招牌与画面文字（出图留白，后期加字；剧本要求全部为虚构中文店名）
| ID | 元素 | 设计 | 场次 | 出处 |
|---|---|---|---|---|
| G01 | 夏记面馆招牌 | 木质招牌，后期加“夏记”二字 | 2、5、21、25 | 面馆「夏记」招牌（人物卡代表元素） |
| G02 | 骑楼铁皮招牌（台风中哐哐响） | 铁皮挂牌，内容空白 | 21 | 骑楼的铁皮招牌被吹得哐哐响 |
| G03 | 巷口小超市招牌 | 空白招牌，虚构中文店名后期 | 8 | 巷口一家小超市门口装着监控 |
| G04 | 24小时便利店招牌/自动门 | 虚构店名后期，“欢迎光临”电子音 | 19 | 便利店自动门的“欢迎光临”电子音 |
| G05 | 第七中学校门/校名、校报 | 校名、校报版头后期 | 3、16、17、24 | 澄港第七中学 |
| G06 | “一鸣惊瓜”霓虹灯牌、账号水印 | 粉紫霓虹灯管 | 3、14、17、20 | 他背后挂着“一鸣惊瓜”的霓虹灯牌 |
| G07 | “海生”船名、钥匙木牌、救生圈字 | 白漆字/刻字/印字 | 2、15、21、23、25 | 船头漆着白字“海生” |
| G08 | 泊位缴费单文字 | “澄港避风塘泊位年费｜船名：海生号｜缴费人：夏红梅” | 9 | 特写缴费单 |
| G09 | “澄港少年游泳队”训练包印字 | 白色印字 | 24 | 印着“澄港少年游泳队”的训练包 |
| G10 | 游泳队徽章“少年队”字样 | 徽章字带 | 3 | 图案是浪花和“少年队”字样 |
| G11 | “班长”袖章 | 红底字 | 3、7 | 红色「班长」袖章 |
| G12 | “自己的碗，端稳了”T恤印字 | 胸前大字 | 25 | T恤上印着“自己的碗，端稳了” |
| G13 | “砚”字碗底红漆、“遥”字刺绣 | 手写/刺绣小字 | 1、3、24 | 碗底用红漆写了一个小小的“砚”字 |

### 4.4 交通工具（详见道具）
P18 白色面包车（车顶架补光灯）（第22场）；P42 搬家小货车（第2场）；P45 外卖电动车（后视镜）（第8场）；P80 夏红梅的电动车（第21场）；P81 海生号（旧小机动渔船，船头白字“海生”）（第2、15、21、23、25场）；P85 海上救援橙色救生艇（第23场）；P98 避风塘小渔船群（背景船）（第1、12、15、25场）；P99 公交车（仅提及）（第19场）

### 4.5 动物
| ID | 名称 | 设计 | 场次 | 出处 |
|---|---|---|---|---|
| A01 | 橘猫“灯泡” | 胖橘猫，住灯塔底石缝；第22场湿透被豆豆抱着；第24场被豆豆收养趴窗台晒夕阳打呼噜。 | 8、12、22、23、24、25 | 它是只橘猫，可胖了，住在灯塔底下的石头缝里。 |
| A02 | 海鸥 | 港口海鸥群。 | 1、15、24 | 海鸥在桅杆间盘旋。 |

群演类型见 3. 无人物卡配角（EX01–EX13）。

### 4.6 天气与特效
| ID | 元素 | 场次 |
|---|---|---|
| W01 | 清晨金色晨光+薄雾 | 1、2 |
| W02 | 台风“青鸾”远景：窗外极淡云带 | 3 |
| W03 | 烛光/停电十秒/灯塔闪一下 | 4、5 |
| W04 | 厨房蒸汽、热气颗粒感；面粉在光柱里飘 | 2、9、11 |
| W05 | 夕阳长影（骑楼柱） | 8 |
| W06 | 积雨云压境，突降瓢泼大雨，雨停 | 10 |
| W07 | 日落、海风、浪拍消波块溅湿鞋、灯塔亮起第一束光 | 12 |
| W08 | 黄昏高饱和天空+体积云+碎金海面 | 15 |
| W09 | 细雨，灯塔光在雨里一明一灭 | 19 |
| W10 | 越来越大的雨（第16天夜） | 20 |
| W11 | 台风夜：钢针般暴雨、三四层楼高浪墙、白沫、闪电白/冷蓝/墨绿、多层合成雨丝、1/4速浪头 | 1、21、22 |
| W12 | 水下：墨黑、气泡上翻、闪电照亮的碎玻璃水面 | 1、23 |
| W13 | 探照灯体积光柱劈开雨幕 | 23 |
| W14 | 台风后洗净的天空与晚霞 | 24 |
| W15 | 弹幕VFX（见UI：RGB色散、像素碎裂、文字粒子、萤火虫消散） | 5、7、18、23 |
| W16 | 闪回滤镜：褪色蓝灰+颗粒噪点 | 14 |

### 4.7 声音与音乐要点（剧本原文）
| ID | 声音/音乐 | 场次 |
|---|---|---|
| A01 | 弹幕“叮”提示音（越密越像暴雨砸铁皮屋顶） | 1、5、6、7、10、11、15、17、18、25 |
| A02 | 弹幕重组“嘶”电流声 | 7、11、17 |
| A03 | 吹蜡烛“噗”（同一声，首尾闭环） | 1、4、21、25 |
| A04 | “关掉弹幕”：抽掉所有提示音只剩海浪和呼吸 | 18、19、20 |
| A05 | 广播：开学与台风“暂不会对本市造成影响” | 1 |
| A06 | 外婆哼老港歌 | 2、25 |
| A07 | 锅铲声、熬汤咕嘟声、远处汽笛、轻快木吉他 | 2、20 |
| A08 | 手机外放刺耳音乐戛然而止→蝉鸣、风吹窗帘 | 3 |
| A09 | 生日歌（豆豆五音不全）→风声→噗 | 4 |
| A10 | 瓷盘摔碎，音乐骤停 | 5 |
| A11 | 片头曲《看全了再说》（疾走日系摇滚男女对唱） | 6 |
| A12 | 钟表嘀嗒+远处海浪 | 6、21 |
| A13 | “这次，不可以”音乐全停→弦乐拨奏 | 7 |
| A14 | 电动车喇叭延迟响起 | 8 |
| A15 | 揉面闷响、虾壳脆响、上楼脚步放大、单簧管独奏 | 9 |
| A16 | 暴雨压过一切→雨声退远，钢琴单音 | 10 |
| A17 | 油锅滋滋→秒针一跳全场静一拍→长长松气 | 11 |
| A18 | “说你会害死我”后3秒静音只有浪声；灯塔亮起“嗡”接弦乐主题 | 12 |
| A19 | 外婆进门“叮咚”滑稽音效；口哨+尤克里里 | 13 |
| A20 | 煎蛋、碗筷、冰箱嗡嗡；闪回只剩心跳和模糊叫骂 | 14 |
| A21 | 海浪、海鸥、缆绳吱呀；插曲①《镜头外》（钢琴+弦乐女声） | 15 |
| A22 | 柯一鸣摔倒“嘎吱”刹车音；耳鸣高频 | 16 |
| A23 | 会议室空调低频嗡鸣；失真罐头笑声般的“叮” | 17 |
| A24 | 争吵无配乐；“叮”汇成轰鸣；大提琴低音 | 18 |
| A25 | 便利店“欢迎光临”、冷柜压缩机嗡鸣、店内广播轻流行歌 | 19 |
| A26 | 缎带摩擦声；插曲②《这次，不可以》（鼓点燃系女声） | 20 |
| A27 | 风雨+挂钟嘀嗒；第1场叮叮叮+第4场吹蜡烛声混合闪回 | 21 |
| A28 | 21:47：只剩心跳“咚——咚——”，落水闷响，交响低音 | 22 |
| A29 | 水下低频嗡鸣→探照灯长弦→交响合唱推到最高→一把钢琴→雨声 | 23 |
| A30 | 碗筷、笑声、电视、猫呼噜；海风海鸥；片尾曲前奏钢琴 | 24 |
| A31 | 片尾曲《红色在海上最显眼》（民谣转交响，母女和声）；洗碗水声 | 25 |
| A32 | 门铃 | 4 |

## 五、分场索引（25场）
| 场 | 标题 | 时间 | 场景变体 | 人物/造型 | 道具 |
|---|---|---|---|---|---|
| 1 | 序幕·第十七天，21:47 | 9月17日 21:47（原本未来）→ 9月1日清晨空镜 | S21-C 澄港老灯塔防波堤·堤面全段·台风夜（第17天 21:38–21:47）<br>S27-B 避风塘水面与水下·水下·墨黑<br>S01-A 澄港城市空镜·清晨金色晨光（9月1日）<br>S24-B 渔港·清晨回港 | 夏知遥：ZY-L4(B，仅手腕/蝴蝶结)<br>周砚：ZYN-L1(仅藏青袖子的手，见歧义1)<br>柯一鸣：仅声音 | P01、P02、P16、P98 |
| 2 | 都可以的早晨 | 9月1日 6:40 | S02-A 夏记面馆一楼·堂食区·清晨开张（9月1日 6:40）<br>S03-A 夏记面馆一楼·后厨·清晨开火<br>S05-A 夏记面馆门口街道·清晨（9月1日） | 夏知遥：ZY-L1(A)<br>夏红梅：XHM-L1<br>陈秀英：CXY-L1<br>林朵朵：LDD-L1<br>街坊阿姨甲：AJ-L1<br>街坊阿姨乙：AY-L1<br>周砚：ZYN-L1(远景)<br>周静：ZJ-L1(远景)<br>夏海生：XHS-L1(照片)<br>夏知遥(幼)：ZY-C(照片) | P01、P34、P36、P35、P30、P42、P41、P43、P44、P14、P10、P02、P81 |
| 3 | 转校生与红蝴蝶结 | 9月1日 上午 | S12-A 澄港第七中学·高二·上午日光（开学日） | 夏知遥：ZY-L1<br>周砚：ZYN-L1<br>林朵朵：LDD-L1<br>宋佳怡：SJY-L1 | P15、P01、P10、P09、P06、P12、P02 |
| 4 | 一起吹灭的蜡烛 | 9月1日 19:30 | S07-A 夏家二楼客厅·生日夜·暖灯（第1天 19:30）<br>S07-B 夏家二楼客厅·生日夜·关灯烛光/停电 | 夏知遥：ZY-L2<br>周砚：ZYN-L2<br>陈秀英：CXY-L1<br>夏红梅：XHM-L1<br>林朵朵：LDD-L1<br>林豆豆：LDou-L1 | P04、P03、P40、P39、P38、P33、P32、P31、P35、P02 |
| 5 | 第一条弹幕 | 9月1日 19:52 | S07-B 夏家二楼客厅·生日夜·关灯烛光/停电<br>S07-A 夏家二楼客厅·生日夜·暖灯（第1天 19:30）<br>S09-A 知遥卧室·深夜台灯<br>S11-A 两楼之间的窄巷·夜·两窗对望 | 夏知遥：ZY-L2<br>周砚：ZYN-L2<br>陈秀英：CXY-L1<br>夏红梅：XHM-L1<br>林朵朵：LDD-L1<br>林豆豆：LDou-L1<br>夏知遥(幼)：ZY-C(相册照片) | P37、P31、P03、P04、P32、P33 |
| 6 | 片头曲《看全了再说》与深夜规则试探 | 9月1日深夜→9月2日凌晨 | S32-A 片头OP抽象空间：海面上游动的手机屏幕·OP·白天<br>S01-B 澄港城市空镜·白天（OP画面二）<br>S33-A 游泳馆·水下仰望（OP）<br>S09-A 知遥卧室·深夜台灯<br>S06-A 夏家楼梯·深夜（规则试探） | 夏知遥：ZY-L3（OP画面二用ZY-L1[设计补充]）<br>周砚：ZYN-L6(OP泳池底) | P05、P95、P24、P01、P02、P94、P15、P58 |
| 7 | 第2天·这次，不可以 | 9月2日 下午第二节课后 | S12-B 澄港第七中学·高二·下午课后·窗外晚霞<br>S13-A 第七中学·教学楼走廊·下午课后斜阳 | 夏知遥：ZY-L1<br>宋佳怡：SJY-L1<br>周砚：ZYN-L1<br>林朵朵：LDD-L1 | P06、P07、P08、P15、P01、P05、P02、P11 |
| 8 | 第4天·巷子里的拉扯 | 9月4日 18:10 | S19-A 骑楼小巷·傍晚6:10夕阳<br>S19-B 骑楼小巷·监控俯拍黑白画面<br>S20-A 通往海边的坡道／灯塔堤路口·黄昏 | 夏知遥：ZY-L1<br>周砚：ZYN-L1<br>林豆豆：LDou-L2 | P11、P25、P45、P46、P47、P10 |
| 9 | 外婆的面 | 9月5日 夜 | S03-B 夏记面馆一楼·后厨·打烊夜·揉面<br>S02-B 夏记面馆一楼·堂食区·打烊夜（卷帘门半拉）<br>S06-B 夏家楼梯·夜/清晨日常<br>S07-C 夏家二楼客厅·夜·窗边逆光（缴费单）/晚饭争吵<br>S09-A 知遥卧室·深夜台灯 | 夏知遥：ZY-L2(A)<br>陈秀英：CXY-L1<br>夏红梅：XHM-L1<br>周砚：ZYN-L1[设计补充] | P52、P51、P50、P39、P49、P53 |
| 10 | 第6天·天台、雨与藏青外套 | 9月6日 午休 | S14-A 第七中学·教学楼天台·正午烈日<br>S14-B 第七中学·教学楼天台·突降暴雨<br>S14-C 第七中学·教学楼天台·雨停 | 夏知遥：ZY-L1(B)<br>周砚：ZYN-L1→(A)<br>宋佳怡：SJY-L1(场末) | P54、P05、P02、P09、P26、P55、P56、P01 |
| 11 | 第8天·没有发生的火 | 9月8日 19:00–19:40 | S02-C 夏记面馆一楼·堂食区·晚饭高峰（夜 7:00）<br>S03-C 夏记面馆一楼·后厨·晚高峰·油锅（倒计时）<br>S04-A 面馆后门外·后巷·夜·昏黄路灯 | 夏知遥：ZY-L2<br>陈秀英：CXY-L1<br>夏红梅：XHM-L1<br>周砚：ZYN-L1<br>林朵朵：LDD-L1 | P24、P58、P57、P61、P59、P60、P34、P35 |
| 12 | 中点·你的弹幕说什么 | 9月9日 17:40 | S21-A 澄港老灯塔防波堤·堤面全段·日落前（第9天 17:40）<br>S22-A 老灯塔底部·日落前 | 夏知遥：ZY-L1<br>周砚：ZYN-L1 | P10、P01、P98 |
| 13 | 第9天夜·作弊同盟 | 9月9日 21:00（+第10–11天蒙太奇） | S09-A 知遥卧室·深夜台灯<br>S11-A 两楼之间的窄巷·夜·两窗对望<br>S15-A 第七中学·操场跑道·白天体育课<br>S16-A 第七中学·楼梯口·白天课间<br>S12-A 澄港第七中学·高二·上午日光（开学日） | 夏知遥：ZY-L2（蒙太奇校服ZY-L1）<br>周砚：ZYN-L2（蒙太奇ZYN-L1）<br>陈秀英：CXY-L1<br>林朵朵：LDD-L1(蒙太奇) | P05、P95、P62、P63、P10、P02、P47 |
| 14 | 第10天·镜头外的他 | 9月10日 夜（含一年前闪回） | S10-A 周砚家·夜·冷白日光灯<br>S30-A 旧学校走廊尽头·闪回·褪色蓝灰 | 夏知遥：ZY-L2<br>周砚：ZYN-L3；闪回ZYN-L5<br>周静：仅电话声<br>许小满：XXM-L2(闪回)<br>柯一鸣：KYM-L1(闪回) | P64、P65、P66、P67、P68、P96、P69、P70、P22、P71、P16、P21、P09、P35 |
| 15 | 第12天·红色在海上最显眼 | 9月12日 黄昏 | S24-A 渔港·黄昏橘红<br>S25-A 避风塘码头·黄昏→入夜路灯<br>S26-A 海生号船上·黄昏泊位<br>S21-B 澄港老灯塔防波堤·堤面全段·黄昏远景（从码头看） | 夏知遥：ZY-L1<br>周砚：ZYN-L1<br>林豆豆：LDou-L2(远景黄点) | P81、P98、P72、P06、P01、P09、P28、P05、P47 |
| 16 | 第13天·躲开了地点，躲不开人 | 9月13日 17:10 | S18-A 第七中学后门与门外长坡道·放学·下午5:10<br>S09-A 知遥卧室·深夜台灯 | 夏知遥：ZY-L1(C)<br>周砚：ZYN-L1<br>柯一鸣：KYM-L1(A)<br>宋佳怡：SJY-L1<br>林朵朵：LDD-L1 | P16、P17、P01、P10、P15、P55、P12 |
| 17 | 第14天·我没看清 | 9月14日 10:00 | S17-A 第七中学会议室·上午10点·冷色对称<br>S13-B 第七中学·教学楼走廊·上午·冷色<br>S18-B 第七中学后门与门外长坡道·正门（仅提及）<br>S31-A 柯一鸣工作室·视频连线背景 | 夏知遥：ZY-L1<br>周砚：ZYN-L1<br>周静：ZJ-L2<br>夏红梅：XHM-L2<br>柯一鸣：KYM-L1(B，视频连线)<br>宋佳怡：SJY-L1(门外) | P19、P20、P27、P56、P01、P12、P02、P55、P96 |
| 18 | 第14天夜·闭嘴 | 9月14日 夜 | S07-C 夏家二楼客厅·夜·窗边逆光（缴费单）/晚饭争吵<br>S09-A 知遥卧室·深夜台灯<br>S09-B 知遥卧室·深夜·关灯月光（弹幕退潮后）<br>S11-A 两楼之间的窄巷·夜·两窗对望 | 夏知遥：ZY-L2(B)<br>夏红梅：XHM-L1(A)<br>陈秀英：CXY-L1 | P75、P33、P12、P05、P73、P11、P74、P01、P35 |
| 19 | 第15天·许小满 | 9月15日 23:30 | S28-A 旧城区24小时便利店·深夜11:30冷白<br>S28-B 旧城区24小时便利店·门外·细雨 | 夏知遥：ZY-L1(D)<br>许小满：XXM-L1 | P23、P21、P22、P29、P12、P99 |
| 20 | 第16天·这次镜头在我手里 | 9月16日 6:30→20:00 | S03-A 夏记面馆一楼·后厨·清晨开火<br>S06-B 夏家楼梯·夜/清晨日常<br>S09-C 知遥卧室·白天（录视频）<br>S02-C 夏记面馆一楼·堂食区·晚饭高峰（夜 7:00）<br>S12-B 澄港第七中学·高二·下午课后·窗外晚霞<br>S29-A 便利店员工休息室·白天/傍晚<br>S31-B 柯一鸣工作室·夜·满屏差评<br>S10-B 周砚家·夜·不开灯，仅手机屏光<br>S11-A 两楼之间的窄巷·夜·两窗对望 | 夏知遥：ZY-L1<br>夏红梅：XHM-L1(B)<br>陈秀英：CXY-L1<br>周砚：ZYN-L2<br>周静：ZJ-L3<br>许小满：XXM-L1<br>林朵朵：LDD-L1<br>宋佳怡：SJY-L1<br>柯一鸣：KYM-L1 | P76、P01、P12、P21、P97、P14、P55、P17、P96、P15 |
| 21 | 第17天·把选择还给我 | 9月17日 20:30→21:28 | S07-D 夏家二楼客厅·台风夜（第17天）<br>S06-C 夏家楼梯·台风夜<br>S02-E 夏记面馆一楼·堂食区·台风夜（第17天）<br>S04-B 面馆后门外·后巷·台风夜·风雨灌入后门（从门内看）<br>S05-B 夏记面馆门口街道·台风夜 | 夏知遥：ZY-L4<br>周砚：ZYN-L1(B)<br>夏红梅：XHM-L1→XHM-L3<br>陈秀英：CXY-L1<br>林朵朵：LDD-L2<br>林豆豆：（离场，仅雨衣缺失） | P78、P33、P58、P77、P48、P47、P46、P13、P12、P14、P10、P53、P79、P80、P02、P01、P32、P81 |
| 22 | 21:47·第三道浪 | 9月17日 21:38–21:47 | S21-C 澄港老灯塔防波堤·堤面全段·台风夜（第17天 21:38–21:47）<br>S22-B 老灯塔底部·台风夜·被浪淹半<br>S23-A 灯塔高处观景平台·台风夜 | 夏知遥：ZY-L4(A)<br>周砚：ZYN-L1→ZYN-L4<br>林豆豆：LDou-L2(A)<br>柯一鸣：KYM-L2 | P18、P16、P17、P13、P12、P02、P47、P01、P09 |
| 23 | 海生号 | 9月17日 21:48–22:05 | S27-B 避风塘水面与水下·水下·墨黑<br>S27-A 避风塘水面与水下·水面·台风夜<br>S26-B 海生号船上·台风夜·探照灯<br>S25-B 避风塘码头·台风夜·雨中等待 | 夏知遥：ZY-L4(B→C)<br>周砚：ZYN-L4<br>夏红梅：XHM-L3<br>林朵朵：LDD-L2(场末，雨衣)<br>陈秀英：CXY-L1(A)<br>林豆豆：LDou-L2(A)<br>周静：ZJ-L1(A)<br>夏海生：仅声音叠加 | P01、P81、P82、P83、P86、P84、P85、P02、P47 |
| 24 | 一个月后·镜头外的日子 | 10月17日 傍晚 | S07-E 夏家二楼客厅·一个月后·傍晚最暖<br>S08-A 夏家二楼阳台·台风后晚霞·逆光<br>S01-C 澄港城市空镜·台风后傍晚晚霞（一个月后） | 夏知遥：ZY-L2<br>周砚：ZYN-L2<br>夏红梅：XHM-L1<br>陈秀英：CXY-L1<br>周静：ZJ-L3<br>林朵朵：LDD-L2<br>林豆豆：LDou-L1<br>许小满：XXM-L3 | P87、P88、P89、P90、P03、P30、P77、P02、P01、P33、P35、P06、P22、P32 |
| 25 | 片尾曲与彩蛋 | 片尾静帧 + 深夜彩蛋 | S05-C 夏记面馆门口街道·片尾手绘静帧·白天<br>S26-C 海生号船上·片尾·重新漆过<br>S33-B 游泳馆·片尾手绘静帧<br>S22-C 老灯塔底部·片尾手绘静帧<br>S25-C 避风塘码头·片尾手绘静帧·晴<br>S03-D 夏记面馆一楼·后厨·深夜彩蛋·洗碗 | 夏知遥(10岁)：ZY-C<br>夏海生：XHS-L1<br>周砚：ZYN-L6<br>许小满：XXM-L3<br>林豆豆：LDou-L1<br>陈秀英：CXY-L2；彩蛋CXY-L1；照片CXY-L3<br>夏红梅：XHM-L1 | P81、P93、P91、P92、P35、P01、P22、P98 |

## 六、第二遍逐场核对新增项

- S02 厕所门（第21场“厕所门开着，没人”）
- S02 “三号桌”（第11场外婆喊“三号桌加个蛋”），堂食桌编号
- S17 会议室门上的玻璃小窗（第17场宋佳怡的脸一闪）
- S01 晾衣竿、S24 桅杆（第1、15场空镜元素）
- S12 窗外“极淡的云带”变体（第3场场末）
- S07 碗柜/柜子（第24场“从柜子里拿出一只新碗”）
- P 碗架与洗碗（第25场“她把碗放进碗架”）
- P 公交车（第19场“坐了四十分钟的公交”，仅提及）
- P 泳镜、饭卡、消防栓（第14场闪回台词/画面细节）
- P 海上救援橙色救生艇的警灯（第23场）
- 声音：门铃（第4场“门铃响”）
- 歧义：插曲①歌词里的“伞”没有对应画面（见歧义清单）
- P 周砚的手机、外婆的手机（第14场免提、第20场外婆举着手机给食客看）

自动交叉核对（道具/场景/造型清单与分场索引双向比对）结果：
- 索引补入 P02 周砚的藏青外套（拉链夹克） → 第3场
- 索引补入 P02 周砚的藏青外套（拉链夹克） → 第4场
- 索引补入 P02 周砚的藏青外套（拉链夹克） → 第17场
- 索引补入 P05 浅蓝色作文本（规则笔记本《弹幕法则》） → 第15场
- 索引补入 P06 《港口的早晨》稿纸（被涂改液改名） → 第24场
- 索引补入 P09 褪色的蓝色游泳队徽章（浪花+“少年队”） → 第14场
- 索引补入 P09 褪色的蓝色游泳队徽章（浪花+“少年队”） → 第22场
- 索引补入 P11 知遥的书包（侧袋网兜被刮破） → 第7场
- 索引补入 P22 许小满的圆框眼镜 → 第24场
- 索引补入 P22 许小满的圆框眼镜 → 第25场
- 索引补入 P32 客厅置物架陈设（腌菜罐、渔网结装饰） → 第21场
- 索引补入 P32 客厅置物架陈设（腌菜罐、渔网结装饰） → 第24场
- 索引补入 P35 面馆面碗（虾仁面） → 第18场
- 索引补入 P35 面馆面碗（虾仁面） → 第14场
- 索引补入 P47 豆豆的明黄色雨衣（崭新） → 第15场
- 索引补入 P47 豆豆的明黄色雨衣（崭新） → 第23场
- 索引补入 P47 豆豆的明黄色雨衣（崭新） → 第13场
- 索引补入 P55 宋佳怡的手机 → 第17场
- 索引补入 P81 海生号（旧小机动渔船，船头白字“海生”） → 第21场
- 索引补入 P96 周砚的手机 → 第17场
- 索引补入 P98 避风塘小渔船群（背景船） → 第25场
- S01 列出第25场，但索引未用其变体（为远景/窗外关系，保留）
- S10 列出第5场，但索引未用其变体（为远景/窗外关系，保留）
- S10 列出第13场，但索引未用其变体（为远景/窗外关系，保留）
- S10 列出第18场，但索引未用其变体（为远景/窗外关系，保留）
- S23 列出第12场，但索引未用其变体（为远景/窗外关系，保留）
- S33 列出第14场，但索引未用其变体（为远景/窗外关系，保留）
- XHS-L1 列出第23场，但索引未写该造型
- LDou-L2 列出第21场，但索引未写该造型

## 七、需要用户决定的歧义

1. 【第1场 vs 第22场】第1场原本未来里画面是“一只穿藏青色袖子的手伸向画面深处”，第22场新时间线周砚已把藏青外套裹给豆豆、柯一鸣机位只看见“穿白T的男生”。原本未来里他是否也把外套给了豆豆？第1场的手要画藏青袖子还是白T手臂？
2. 【知遥台风夜服装】第21–23场（及第1场）剧本未写她穿什么（学校已停课、在家吃粥）。本表暂定：居家白衬衫+奶油开衫+深色长裤+白运动鞋，胸前防水袋。是否改为校服或别的？
3. 【许小满工服】人物卡是“浅蓝短袖便利店工服+米色围裙”，剧本第19场写“便利店的条纹制服”。本表暂定浅蓝白细竖条纹+米色围裙，需确认。
4. 【周砚徽章】剧本只写书包带上一枚褪色蓝色游泳队徽章；characters.md 的周砚提示词另有“夹克左胸小圆形徽章”。是一枚还是两枚？
5. 【周砚家位置】第2场“对面老楼”、第5场“隔壁楼二层……隔着一条窄巷”、人物小传“隔壁老楼”。本表暂定：斜对面，两楼侧面隔一条窄巷，二楼窗口相对。
6. 【旧照片位置】第2场“海生号”父女旧照片挂在一楼面馆墙上；第24场“旧照片旁边多了一个相框”在二楼客厅。同一张还是两张？本表暂定两处各一张。
7. 【数字蜡烛】“17”是连体一根还是“1”“7”两根？本表暂定连体一根。
8. 【周静第2场“护士外套”】是卡面浅绿护士服，还是另有一件外套？
9. 【第7场光线】时间是“下午第二节课后”，但同学在拍“窗外的晚霞”。本表暂定下午偏晚的暖橙光。
10. 【弹幕B右上角】视频B字幕卡和“观看人数”都在右上角，第22场周砚视野右上角还有红色倒计时。本表暂定上下堆叠：字幕卡→观看人数→倒计时。
11. 【无人物卡角色】老何、钱主任、三个霸凌者、搬家工人、老奶奶、外卖骑手、救援人员、年轻外公都没有人物卡，本表只给了[设计补充]服装描述。要不要先出他们的定妆图？
12. 【非校服造型】林朵朵、周静、许小满、周砚旧校、泳装、外婆年轻时等造型剧本都没写，均为[设计补充]。如果希望全片只用人物卡造型，告诉我就改回卡面造型。
13. 【第16场结尾、第19场公交、学校正门】看潮声App的地点，以及公交、正门，剧本都没写画面。本表把看App放在卧室，公交和正门列为可选，不出图。
14. 【蝴蝶结“遥”字、船名等文字】AI出图容易写错字。本表的出图提示词一律不画文字（no text），文字都放到后期贴上。
15. 【插曲①歌词“你偷偷把伞往我这边倒”】第15场画面里没有伞，第10场天台也只是用外套罩头。本表没有把伞列为道具，需要的话可以加上。